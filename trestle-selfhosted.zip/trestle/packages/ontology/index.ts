import type { ActionDef } from './action';
import type { ObjectDef } from './object';

/** Every business object in the app. Import each area's objects and list them here. */
export const objects: ObjectDef[] = [];

/** Every business action in the app. Import each area's actions and list them here. */
export const actions: ActionDef[] = [];
