/**
 * Every SQL read the app runs. The backend's /data/query route runs only these exact strings (see ALLOWED_QUERIES),
 * as the signed-in user under row level security. Add a read here, never inline in a page.
 */
export const queries = {
  memberships: `select m.org_id, m.role, m.approval_limit, o.name, o.is_demo
       from org_members m join orgs o on o.id = m.org_id
      where m.user_id = $1 and m.active order by o.is_demo, o.name`,
  intakePending: `select i.id, i.upload_id, i.file_name, u.size_bytes, u.mime_type from invoices i left join bourne_uploads u on u.id = i.upload_id
      where i.org_id = $1 and i.created_by = $2 and i.extraction_status = 'pending' and i.status = 'needs_review'
        and i.upload_id is not null and i.agent_session_id is null order by i.created_at limit 20`,
  lookups: `
select
  (select row_to_json(o) from (select id, name, legal_entity, is_demo from orgs where id = $1) o) as org,
  (select row_to_json(s) from org_settings s where s.org_id = $1) as settings,
  (select coalesce(json_agg(v order by v.name), '[]') from (select id, code, name, status, tax_id, email, phone, address, payment_terms, default_gl_account_id, default_cost_type_id, external_id from vendors where org_id = $1) v) as vendors,
  (select coalesce(json_agg(p order by p.code), '[]') from (select id, code, name, status, project_manager_user_id, legal_entity, address, external_id from projects where org_id = $1) p) as projects,
  (select coalesce(json_agg(c order by c.code), '[]') from (select id, code, name, project_id, budget_amount from cost_codes where org_id = $1) c) as cost_codes,
  (select coalesce(json_agg(t order by t.code), '[]') from (select id, code, name from cost_types where org_id = $1) t) as cost_types,
  (select coalesce(json_agg(g order by g.code), '[]') from (select id, code, name, account_type, active from gl_accounts where org_id = $1) g) as gl_accounts,
  (select coalesce(json_agg(m order by m.email), '[]') from (select user_id, email, display_name, role, approval_limit, active from org_members where org_id = $1) m) as members,
  (select coalesce(json_agg(c order by c.number), '[]') from (select id, kind, number, vendor_id, project_id, description, status, original_amount, retainage_pct, external_id from commitments where org_id = $1) c) as commitments
`,
  agentRuns: `
    select r.*, i.invoice_number from agent_runs r left join invoices i on i.id = r.invoice_id
    where r.org_id = $1 and ($2 = 'all' or r.agent = $2) order by r.started_at desc limit 300`,
  auditEvents: `
    select e.*, i.invoice_number from audit_events e left join invoices i on i.id = e.invoice_id
    where e.org_id = $1 and ($2 = 'all' or e.actor_kind = $2) order by e.created_at desc, e.id desc limit 1000`,
  approvalQueue: `
select s.id step_id, i.id invoice_id, i.invoice_number, coalesce(v.name, i.vendor_name_extracted) vendor, i.total_amount, i.currency,
  s.step_order, s.approver_user_id, s.approver_role, s.reason, i.submitted_at, i.submitted_by,
  (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) projects,
  (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status in ('open', 'acknowledged') and x.severity = 'warning') warnings,
  (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'overridden') overridden,
  s.step_order = (select min(step_order) from approval_steps o where o.invoice_id = i.id and o.round = i.approval_round and o.status = 'pending') is_next
from approval_steps s join invoices i on i.id = s.invoice_id left join vendors v on v.id = i.vendor_id
where s.org_id = $1 and s.status = 'pending' and i.status = 'pending_approval' and s.round = i.approval_round
order by i.submitted_at limit 500`,
  syncBatches: `
select b.*, (select count(*)::int from sync_records r where r.batch_id = b.id and r.status = 'synced') synced,
  (select count(*)::int from sync_records r where r.batch_id = b.id and r.status = 'failed') failed,
  (select count(*)::int from sync_records r where r.batch_id = b.id and r.status = 'exported') exported
from export_batches b where b.org_id = $1 order by b.batch_number desc limit 200`,
  syncReady: `select count(*) filter (where sync_status = 'ready')::int n, coalesce(sum(total_amount) filter (where sync_status = 'ready'), 0) amount,
  count(*) filter (where sync_status = 'failed')::int failed, coalesce(sum(total_amount) filter (where sync_status = 'failed'), 0) failed_amount
from invoices where org_id = $1 and status = 'approved'`,
  syncRecords: `select r.id, r.invoice_id, r.idempotency_key, r.attempt, r.status, r.external_id, r.error, r.payload ->> 'invoice_number' invoice_number, r.payload ->> 'vendor_name' vendor, r.payload ->> 'total_amount' total,
       exists (select 1 from sync_records o where o.invoice_id = r.invoice_id and o.attempt > r.attempt) newer
     from sync_records r where r.batch_id = $1 order by r.idempotency_key`,
  invoiceDetail: `
select row_to_json(i) as invoice,
  (select coalesce(json_agg(a order by a.created_at, a.id), '[]') from invoice_allocations a where a.invoice_id = i.id) as allocations,
  (select coalesce(json_agg(l order by l.line_no), '[]') from invoice_lines l where l.invoice_id = i.id) as lines,
  (select coalesce(json_agg(x order by case x.status when 'open' then 0 else 1 end, case x.severity when 'blocking' then 0 when 'warning' then 1 else 2 end, x.created_at), '[]')
     from invoice_exceptions x where x.invoice_id = i.id) as exceptions,
  (select coalesce(json_agg(s order by s.round desc, s.step_order, s.created_at), '[]') from approval_steps s where s.invoice_id = i.id) as steps,
  (select coalesce(json_agg(e order by e.created_at desc, e.id desc), '[]') from (select * from audit_events where invoice_id = i.id order by created_at desc, id desc limit 300) e) as audit,
  (select coalesce(json_agg(r order by r.attempt desc), '[]') from (select r.id, r.attempt, r.status, r.external_id, r.error, r.idempotency_key, r.created_at, r.updated_at, b.batch_number
     from sync_records r join export_batches b on b.id = r.batch_id where r.invoice_id = i.id) r) as sync,
  (select json_build_object('id', c.id, 'number', c.number, 'kind', c.kind, 'status', c.status, 'original', c.original_amount, 'retainage_pct', c.retainage_pct,
      'description', c.description, 'vendor_id', c.vendor_id, 'project_id', c.project_id,
      'approved_cos', (select coalesce(sum(amount), 0) from change_orders where commitment_id = c.id and status = 'approved'),
      'pending_cos', (select coalesce(sum(amount), 0) from change_orders where commitment_id = c.id and status = 'pending'),
      'billed_other', (select coalesce(sum(total_amount), 0) from invoices o where o.commitment_id = c.id and o.id <> i.id and o.status in ('pending_approval', 'approved')),
      'lines', (select coalesce(json_agg(cl order by cl.line_no), '[]') from commitment_lines cl where cl.commitment_id = c.id))
     from commitments c where c.id = i.commitment_id) as commitment
from invoices i where i.id = $1 and i.org_id = $2`,
  overviewStats: `
with i as (select * from invoices where org_id = $1),
openx as (select x.invoice_id, x.code, x.severity from invoice_exceptions x join i on i.id = x.invoice_id where x.status = 'open' and i.status = 'needs_review')
select
  (select count(*)::int from i where status = 'needs_review') in_review,
  (select count(distinct invoice_id)::int from openx where severity = 'blocking') blocked,
  (select count(distinct invoice_id)::int from openx where code = 'low_confidence') flagged,
  (select count(distinct invoice_id)::int from openx where code in ('duplicate', 'possible_duplicate')) duplicates,
  (select count(*)::int from i where status = 'needs_review' and extraction_status in ('pending', 'running')) extracting,
  (select count(*)::int from i where status = 'needs_review' and extraction_status = 'failed') extraction_failed,
  (select count(*)::int from i where status = 'pending_approval') awaiting_approval,
  (select coalesce(sum(total_amount), 0) from i where status = 'pending_approval') awaiting_amount,
  (select round(extract(epoch from now() - min(submitted_at)) / 3600)::int from i where status = 'pending_approval') oldest_awaiting_hours,
  (select count(*)::int from i where status = 'approved' and sync_status in ('ready')) ready_count,
  (select coalesce(sum(total_amount), 0) from i where status = 'approved' and sync_status = 'ready') ready_amount,
  (select count(*)::int from i where sync_status = 'exported') exported_count,
  (select count(*)::int from i where sync_status = 'failed') sync_failed,
  (select count(*)::int from i where created_at > now() - interval '30 days') received_30d,
  (select count(*)::int from i where approved_at > now() - interval '30 days') approved_30d,
  (select coalesce(sum(total_amount), 0) from i where approved_at > now() - interval '30 days') approved_amount_30d,
  (select round((percentile_cont(0.5) within group (order by extract(epoch from approved_at - created_at)) / 3600)::numeric, 1)::float from i where approved_at > now() - interval '30 days') median_hours_to_approve,
  (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(field_confidence, '{}')))), 0)::int from i where extraction_status = 'succeeded' and created_at > now() - interval '30 days') fields_extracted_30d,
  (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(details -> 'changes', '{}')))), 0)::int from audit_events where org_id = $1 and action = 'field_corrected' and created_at > now() - interval '30 days') fields_corrected_30d`,
  commitments: `
    select c.*, (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'approved') approved_cos,
      (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'pending') pending_cos,
      (select coalesce(sum(total_amount), 0) from invoices i where i.commitment_id = c.id and i.status in ('pending_approval', 'approved')) billed,
      (select coalesce(json_agg(l order by l.line_no), '[]') from commitment_lines l where l.commitment_id = c.id) lines
    from commitments c where c.org_id = $1 order by c.number limit 2000`,
  changeOrders: 'select id, commitment_id, number, description, amount, status, approved_date from change_orders where org_id = $1 order by created_at desc limit 1000',
  invoiceRegister: `
    select i.invoice_number, coalesce(v.code, '') vendor_code, coalesce(v.name, i.vendor_name_extracted) vendor, i.invoice_date, i.due_date, i.total_amount, i.retainage_amount, i.currency,
      c.number commitment, i.status, i.sync_status, i.created_at::date received, i.approved_at::date approved,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) jobs, i.id invoice_id
    from invoices i left join vendors v on v.id = i.vendor_id left join commitments c on c.id = i.commitment_id
    where i.org_id = $1 and i.created_at >= $2::date and i.created_at < $3::date + 1 and ($4 = 'all' or i.status = $4)
    order by i.created_at desc limit 5000`,
  jobCost: `
    select p.code job, p.name job_name, cc.code cost_code, cc.name cost_code_name, ct.code cost_type, sum(a.amount) amount, count(distinct i.id)::int invoices, max(cc.budget_amount) budget
    from invoice_allocations a join invoices i on i.id = a.invoice_id
      left join projects p on p.id = a.project_id left join cost_codes cc on cc.id = a.cost_code_id left join cost_types ct on ct.id = a.cost_type_id
    where i.org_id = $1 and i.created_at >= $2::date and i.created_at < $3::date + 1
      and (case when $4 = 'approved' then i.status = 'approved' else i.status in ('needs_review', 'pending_approval', 'approved') end)
    group by p.code, p.name, cc.code, cc.name, ct.code order by p.code nulls last, cc.code nulls last, ct.code limit 5000`,
  commitmentStatus: `
    select c.number, c.kind, v.name vendor, p.code job, c.status, c.original_amount original,
      (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'approved') approved_cos,
      (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'pending') pending_cos,
      (select coalesce(sum(total_amount), 0) from invoices i where i.commitment_id = c.id and i.status = 'approved') billed_approved,
      (select coalesce(sum(total_amount), 0) from invoices i where i.commitment_id = c.id and i.status = 'pending_approval') billed_pending,
      (select coalesce(sum(retainage_amount), 0) from invoices i where i.commitment_id = c.id and i.status = 'approved') retainage_held
    from commitments c join vendors v on v.id = c.vendor_id join projects p on p.id = c.project_id
    where c.org_id = $1 order by p.code, c.number limit 5000`,
  cycleMetrics: `
    with i as (select * from invoices where org_id = $1 and created_at >= $2::date and created_at < $3::date + 1)
    select (select count(*)::int from i) received, (select count(*)::int from i where approved_at is not null) approved,
      (select round((percentile_cont(0.5) within group (order by extract(epoch from submitted_at - created_at)) / 3600)::numeric, 1)::float from i where submitted_at is not null) median_receipt_to_submit_h,
      (select round((percentile_cont(0.5) within group (order by extract(epoch from approved_at - submitted_at)) / 3600)::numeric, 1)::float from i where approved_at is not null) median_submit_to_approve_h,
      (select round((percentile_cont(0.9) within group (order by extract(epoch from approved_at - created_at)) / 3600)::numeric, 1)::float from i where approved_at is not null) p90_receipt_to_approve_h,
      (select count(*)::int from i where extraction_status = 'succeeded') ai_extracted, (select count(*)::int from i where extraction_status = 'failed') ai_failed,
      (select count(*)::int from i where extraction_status = 'manual') manual,
      (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(ai_extraction -> 'confidence', field_confidence, '{}')))), 0)::int from i where extraction_status = 'succeeded') fields_extracted,
      (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(e.details -> 'changes', '{}')))), 0)::int from audit_events e join i on i.id = e.invoice_id where e.action = 'field_corrected') fields_corrected,
      (select count(*)::int from i where approved_at is not null and extraction_status = 'succeeded'
         and not exists (select 1 from audit_events e where e.invoice_id = i.id and e.action = 'field_corrected')
         and not exists (select 1 from invoice_allocations a where a.invoice_id = i.id and a.source = 'user')) touchless`,
  invites: 'select id, email, role, approval_limit, accepted_at, created_at from org_invites where org_id = $1 and accepted_at is null order by created_at desc',
  approvalRules: 'select id, name, active, step_order, min_amount, approver_kind, approver_user_id, approver_role, vendor_id, project_id from approval_rules where org_id = $1 order by step_order, min_amount',
  vendorAliases: 'select id, alias, vendor_id, learned_from_invoice_id, created_at from vendor_aliases where org_id = $1 order by created_at desc limit 500',
  waitingApprovals: `select count(*)::int n from approval_steps s join invoices i on i.id = s.invoice_id
      where s.org_id = $1 and s.status = 'pending' and i.status = 'pending_approval' and s.round = i.approval_round
        and (s.approver_user_id = $2 or (s.approver_user_id is null and (s.approver_role = $3 or (s.approver_role = 'controller' and $3 = 'owner'))))`,
} as const;

export const INVOICE_FILTERS: { id: string; label: string; where: string }[] = [
  { id: 'open', label: 'All open', where: `i.status in ('needs_review','pending_approval')` },
  { id: 'needs_review', label: 'In review', where: `i.status = 'needs_review'` },
  { id: 'blocked', label: 'Blocked by exceptions', where: `i.status = 'needs_review' and exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking')` },
  { id: 'duplicates', label: 'Possible duplicates', where: `exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.code in ('duplicate','possible_duplicate'))` },
  { id: 'discrepancies', label: 'Commitment discrepancies', where: `exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status in ('open','overridden') and x.code in ('overbilling','po_vendor_mismatch','po_not_found','po_required','cost_code_outside_commitment','project_outside_commitment'))` },
  { id: 'pending_approval', label: 'Awaiting approval', where: `i.status = 'pending_approval'` },
  { id: 'approved', label: 'Approved', where: `i.status = 'approved'` },
  { id: 'sync_failed', label: 'Sync failed', where: `i.sync_status = 'failed'` },
  { id: 'rejected', label: 'Rejected', where: `i.status = 'rejected'` },
  { id: 'void', label: 'Void', where: `i.status = 'void'` },
  { id: 'all', label: 'All', where: 'true' },
];

export function invoiceListSql(where: string) {
  return `select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = $1 and (${where})
      and ($2 = '' or i.invoice_number ilike '%' || $2 || '%' or v.name ilike '%' || $2 || '%' or i.vendor_name_extracted ilike '%' || $2 || '%'
           or i.po_number ilike '%' || $2 || '%' or i.file_name ilike '%' || $2 || '%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%' || $2 || '%' or p.name ilike '%' || $2 || '%')))
    order by i.created_at desc limit 500`;
}

export const ATTENTION_WHERE = `i.status = 'needs_review' and (i.extraction_status = 'failed' or exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity in ('blocking','warning')))`;

export type ExceptionGroup = 'code' | 'vendor' | 'job';

export function exceptionReportSql(group: ExceptionGroup): string {
  const groupSql = group === 'code' ? 'x.title' : group === 'vendor' ? `coalesce(v.name, i.vendor_name_extracted, '(unmatched vendor)')` : `coalesce((select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id), '(uncoded)')`;
  return `
    select ${groupSql} grp, count(*)::int total, count(*) filter (where x.status = 'open')::int open, count(*) filter (where x.status = 'overridden')::int overridden,
      count(*) filter (where x.status = 'acknowledged')::int acknowledged, count(*) filter (where x.status = 'resolved')::int resolved,
      count(*) filter (where x.severity = 'blocking')::int blocking, coalesce(sum(distinct i.total_amount), 0) amount
    from invoice_exceptions x join invoices i on i.id = x.invoice_id left join vendors v on v.id = i.vendor_id
    where x.org_id = $1 and x.created_at >= $2::date and x.created_at < $3::date + 1 and i.status <> 'void'
    group by 1 order by total desc limit 500`;
}

/** Every exact SQL string the app may ask the backend to run. */
export const ALLOWED_QUERIES: readonly string[] = [
  ...Object.values(queries),
  ...INVOICE_FILTERS.map(f => invoiceListSql(f.where)),
  invoiceListSql(ATTENTION_WHERE),
  ...(['code', 'vendor', 'job'] as const).map(exceptionReportSql),
];
