export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      _prisma_migrations: {
        Row: {
          applied_steps_count: number
          checksum: string
          finished_at: string | null
          id: string
          logs: string | null
          migration_name: string
          rolled_back_at: string | null
          started_at: string
        }
        Insert: {
          applied_steps_count?: number
          checksum: string
          finished_at?: string | null
          id: string
          logs?: string | null
          migration_name: string
          rolled_back_at?: string | null
          started_at?: string
        }
        Update: {
          applied_steps_count?: number
          checksum?: string
          finished_at?: string | null
          id?: string
          logs?: string | null
          migration_name?: string
          rolled_back_at?: string | null
          started_at?: string
        }
        Relationships: []
      }
      agent_runs: {
        Row: {
          agent: string
          error: string | null
          finished_at: string | null
          id: string
          input: Json
          invoice_id: string | null
          kind: string
          org_id: string
          output: Json
          session_id: string | null
          started_at: string
          status: string
          summary: string | null
          triggered_by: string | null
        }
        Insert: {
          agent: string
          error?: string | null
          finished_at?: string | null
          id?: string
          input?: Json
          invoice_id?: string | null
          kind?: string
          org_id: string
          output?: Json
          session_id?: string | null
          started_at?: string
          status: string
          summary?: string | null
          triggered_by?: string | null
        }
        Update: {
          agent?: string
          error?: string | null
          finished_at?: string | null
          id?: string
          input?: Json
          invoice_id?: string | null
          kind?: string
          org_id?: string
          output?: Json
          session_id?: string | null
          started_at?: string
          status?: string
          summary?: string | null
          triggered_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agent_runs_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agent_runs_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      approval_rules: {
        Row: {
          active: boolean
          approver_kind: string
          approver_role: string | null
          approver_user_id: string | null
          created_at: string
          id: string
          min_amount: number
          name: string
          org_id: string
          project_id: string | null
          step_order: number
          vendor_id: string | null
        }
        Insert: {
          active?: boolean
          approver_kind: string
          approver_role?: string | null
          approver_user_id?: string | null
          created_at?: string
          id?: string
          min_amount?: number
          name: string
          org_id: string
          project_id?: string | null
          step_order?: number
          vendor_id?: string | null
        }
        Update: {
          active?: boolean
          approver_kind?: string
          approver_role?: string | null
          approver_user_id?: string | null
          created_at?: string
          id?: string
          min_amount?: number
          name?: string
          org_id?: string
          project_id?: string | null
          step_order?: number
          vendor_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "approval_rules_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "approval_rules_org_id_project_id_fkey"
            columns: ["org_id", "project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "approval_rules_org_id_vendor_id_fkey"
            columns: ["org_id", "vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "approval_rules_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "approval_rules_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["id"]
          },
        ]
      }
      approval_steps: {
        Row: {
          approver_role: string | null
          approver_user_id: string | null
          comment: string | null
          created_at: string
          decided_at: string | null
          decided_by: string | null
          id: string
          invoice_id: string
          org_id: string
          reason: string
          round: number
          rule_id: string | null
          status: string
          step_order: number
        }
        Insert: {
          approver_role?: string | null
          approver_user_id?: string | null
          comment?: string | null
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          id?: string
          invoice_id: string
          org_id: string
          reason: string
          round: number
          rule_id?: string | null
          status?: string
          step_order: number
        }
        Update: {
          approver_role?: string | null
          approver_user_id?: string | null
          comment?: string | null
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          id?: string
          invoice_id?: string
          org_id?: string
          reason?: string
          round?: number
          rule_id?: string | null
          status?: string
          step_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "approval_steps_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "approval_steps_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "approval_steps_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "approval_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_events: {
        Row: {
          action: string
          actor_kind: string
          actor_user_id: string | null
          created_at: string
          details: Json
          entity_id: string | null
          entity_type: string
          id: number
          invoice_id: string | null
          org_id: string
          summary: string
        }
        Insert: {
          action: string
          actor_kind?: string
          actor_user_id?: string | null
          created_at?: string
          details?: Json
          entity_id?: string | null
          entity_type: string
          id?: never
          invoice_id?: string | null
          org_id: string
          summary: string
        }
        Update: {
          action?: string
          actor_kind?: string
          actor_user_id?: string | null
          created_at?: string
          details?: Json
          entity_id?: string | null
          entity_type?: string
          id?: never
          invoice_id?: string | null
          org_id?: string
          summary?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_events_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      bourne_agent_messages: {
        Row: {
          message: string
          message_id: string
          message_type: string
          metadata: Json
          session_id: string
          timestamp: string
          turn_id: string
        }
        Insert: {
          message?: string
          message_id: string
          message_type: string
          metadata?: Json
          session_id: string
          timestamp?: string
          turn_id: string
        }
        Update: {
          message?: string
          message_id?: string
          message_type?: string
          metadata?: Json
          session_id?: string
          timestamp?: string
          turn_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bourne_agent_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "bourne_agent_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      bourne_agent_sessions: {
        Row: {
          agent_name: string
          build_id: string
          created_at: string
          id: string
          organization_id: string | null
          runtime: string
          runtime_resume_token: string | null
          runtime_session_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          agent_name: string
          build_id: string
          created_at?: string
          id: string
          organization_id?: string | null
          runtime: string
          runtime_resume_token?: string | null
          runtime_session_id?: string | null
          status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          agent_name?: string
          build_id?: string
          created_at?: string
          id?: string
          organization_id?: string | null
          runtime?: string
          runtime_resume_token?: string | null
          runtime_session_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      bourne_artifact_revisions: {
        Row: {
          artifact_id: string
          content: string | null
          created_at: string
          function_name: string
          id: string
          mime_type: string
          name: string
          run_id: string
          size_bytes: number
        }
        Insert: {
          artifact_id: string
          content?: string | null
          created_at?: string
          function_name: string
          id: string
          mime_type: string
          name: string
          run_id: string
          size_bytes: number
        }
        Update: {
          artifact_id?: string
          content?: string | null
          created_at?: string
          function_name?: string
          id?: string
          mime_type?: string
          name?: string
          run_id?: string
          size_bytes?: number
        }
        Relationships: [
          {
            foreignKeyName: "bourne_artifact_revisions_artifact_id_fkey"
            columns: ["artifact_id"]
            isOneToOne: false
            referencedRelation: "bourne_artifacts"
            referencedColumns: ["id"]
          },
        ]
      }
      bourne_artifacts: {
        Row: {
          created_at: string
          description: string
          id: string
          organization_id: string | null
          title: string
          type: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          description?: string
          id: string
          organization_id?: string | null
          title: string
          type: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          organization_id?: string | null
          title?: string
          type?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      bourne_uploads: {
        Row: {
          created_at: string
          id: string
          mime_type: string
          name: string
          organization_id: string | null
          size_bytes: number
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id: string
          mime_type: string
          name: string
          organization_id?: string | null
          size_bytes: number
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          mime_type?: string
          name?: string
          organization_id?: string | null
          size_bytes?: number
          user_id?: string | null
        }
        Relationships: []
      }
      change_orders: {
        Row: {
          amount: number
          approved_date: string | null
          commitment_id: string
          created_at: string
          description: string | null
          id: string
          number: string
          org_id: string
          status: string
        }
        Insert: {
          amount: number
          approved_date?: string | null
          commitment_id: string
          created_at?: string
          description?: string | null
          id?: string
          number: string
          org_id: string
          status?: string
        }
        Update: {
          amount?: number
          approved_date?: string | null
          commitment_id?: string
          created_at?: string
          description?: string | null
          id?: string
          number?: string
          org_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "change_orders_commitment_id_fkey"
            columns: ["commitment_id"]
            isOneToOne: false
            referencedRelation: "commitments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "change_orders_org_id_commitment_id_fkey"
            columns: ["org_id", "commitment_id"]
            isOneToOne: false
            referencedRelation: "commitments"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "change_orders_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      commitment_lines: {
        Row: {
          amount: number
          commitment_id: string
          cost_code_id: string | null
          cost_type_id: string | null
          description: string | null
          id: string
          line_no: number
          org_id: string
        }
        Insert: {
          amount?: number
          commitment_id: string
          cost_code_id?: string | null
          cost_type_id?: string | null
          description?: string | null
          id?: string
          line_no: number
          org_id: string
        }
        Update: {
          amount?: number
          commitment_id?: string
          cost_code_id?: string | null
          cost_type_id?: string | null
          description?: string | null
          id?: string
          line_no?: number
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "commitment_lines_commitment_id_fkey"
            columns: ["commitment_id"]
            isOneToOne: false
            referencedRelation: "commitments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commitment_lines_cost_code_id_fkey"
            columns: ["cost_code_id"]
            isOneToOne: false
            referencedRelation: "cost_codes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commitment_lines_cost_type_id_fkey"
            columns: ["cost_type_id"]
            isOneToOne: false
            referencedRelation: "cost_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commitment_lines_org_id_commitment_id_fkey"
            columns: ["org_id", "commitment_id"]
            isOneToOne: false
            referencedRelation: "commitments"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "commitment_lines_org_id_cost_code_id_fkey"
            columns: ["org_id", "cost_code_id"]
            isOneToOne: false
            referencedRelation: "cost_codes"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "commitment_lines_org_id_cost_type_id_fkey"
            columns: ["org_id", "cost_type_id"]
            isOneToOne: false
            referencedRelation: "cost_types"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "commitment_lines_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      commitments: {
        Row: {
          created_at: string
          description: string | null
          external_id: string | null
          id: string
          kind: string
          number: string
          org_id: string
          original_amount: number
          project_id: string
          retainage_pct: number
          status: string
          vendor_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          external_id?: string | null
          id?: string
          kind: string
          number: string
          org_id: string
          original_amount?: number
          project_id: string
          retainage_pct?: number
          status?: string
          vendor_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          external_id?: string | null
          id?: string
          kind?: string
          number?: string
          org_id?: string
          original_amount?: number
          project_id?: string
          retainage_pct?: number
          status?: string
          vendor_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "commitments_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commitments_org_id_project_id_fkey"
            columns: ["org_id", "project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "commitments_org_id_vendor_id_fkey"
            columns: ["org_id", "vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "commitments_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commitments_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["id"]
          },
        ]
      }
      cost_codes: {
        Row: {
          budget_amount: number | null
          code: string
          created_at: string
          id: string
          name: string
          org_id: string
          project_id: string | null
        }
        Insert: {
          budget_amount?: number | null
          code: string
          created_at?: string
          id?: string
          name: string
          org_id: string
          project_id?: string | null
        }
        Update: {
          budget_amount?: number | null
          code?: string
          created_at?: string
          id?: string
          name?: string
          org_id?: string
          project_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "cost_codes_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cost_codes_org_id_project_id_fkey"
            columns: ["org_id", "project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "cost_codes_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      cost_types: {
        Row: {
          code: string
          created_at: string
          id: string
          name: string
          org_id: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          name: string
          org_id: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          name?: string
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cost_types_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      export_batches: {
        Row: {
          allocation_total: number
          batch_number: number
          created_at: string
          created_by: string
          id: string
          invoice_count: number
          invoice_total: number
          org_id: string
          status: string
          target: string
        }
        Insert: {
          allocation_total: number
          batch_number: number
          created_at?: string
          created_by: string
          id?: string
          invoice_count: number
          invoice_total: number
          org_id: string
          status?: string
          target?: string
        }
        Update: {
          allocation_total?: number
          batch_number?: number
          created_at?: string
          created_by?: string
          id?: string
          invoice_count?: number
          invoice_total?: number
          org_id?: string
          status?: string
          target?: string
        }
        Relationships: [
          {
            foreignKeyName: "export_batches_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      gl_accounts: {
        Row: {
          account_type: string
          active: boolean
          code: string
          created_at: string
          id: string
          name: string
          org_id: string
        }
        Insert: {
          account_type?: string
          active?: boolean
          code: string
          created_at?: string
          id?: string
          name: string
          org_id: string
        }
        Update: {
          account_type?: string
          active?: boolean
          code?: string
          created_at?: string
          id?: string
          name?: string
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "gl_accounts_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_allocations: {
        Row: {
          amount: number
          commitment_line_id: string | null
          confidence: number | null
          cost_code_id: string | null
          cost_type_id: string | null
          created_at: string
          description: string | null
          gl_account_id: string | null
          id: string
          invoice_id: string
          org_id: string
          project_id: string | null
          rationale: string | null
          source: string
        }
        Insert: {
          amount?: number
          commitment_line_id?: string | null
          confidence?: number | null
          cost_code_id?: string | null
          cost_type_id?: string | null
          created_at?: string
          description?: string | null
          gl_account_id?: string | null
          id?: string
          invoice_id: string
          org_id: string
          project_id?: string | null
          rationale?: string | null
          source?: string
        }
        Update: {
          amount?: number
          commitment_line_id?: string | null
          confidence?: number | null
          cost_code_id?: string | null
          cost_type_id?: string | null
          created_at?: string
          description?: string | null
          gl_account_id?: string | null
          id?: string
          invoice_id?: string
          org_id?: string
          project_id?: string | null
          rationale?: string | null
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoice_allocations_commitment_line_id_fkey"
            columns: ["commitment_line_id"]
            isOneToOne: false
            referencedRelation: "commitment_lines"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_allocations_cost_code_id_fkey"
            columns: ["cost_code_id"]
            isOneToOne: false
            referencedRelation: "cost_codes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_allocations_cost_type_id_fkey"
            columns: ["cost_type_id"]
            isOneToOne: false
            referencedRelation: "cost_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_allocations_gl_account_id_fkey"
            columns: ["gl_account_id"]
            isOneToOne: false
            referencedRelation: "gl_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_allocations_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_commitment_line_id_fkey"
            columns: ["org_id", "commitment_line_id"]
            isOneToOne: false
            referencedRelation: "commitment_lines"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_cost_code_id_fkey"
            columns: ["org_id", "cost_code_id"]
            isOneToOne: false
            referencedRelation: "cost_codes"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_cost_type_id_fkey"
            columns: ["org_id", "cost_type_id"]
            isOneToOne: false
            referencedRelation: "cost_types"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_gl_account_id_fkey"
            columns: ["org_id", "gl_account_id"]
            isOneToOne: false
            referencedRelation: "gl_accounts"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_invoice_id_fkey"
            columns: ["org_id", "invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoice_allocations_org_id_project_id_fkey"
            columns: ["org_id", "project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoice_allocations_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_exceptions: {
        Row: {
          code: string
          created_at: string
          detail: string
          evidence: Json
          fingerprint: string
          id: string
          invoice_id: string
          org_id: string
          overridable: boolean
          resolution_note: string | null
          resolved_at: string | null
          resolved_by: string | null
          resolver: string
          severity: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          detail: string
          evidence?: Json
          fingerprint: string
          id?: string
          invoice_id: string
          org_id: string
          overridable?: boolean
          resolution_note?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          resolver?: string
          severity: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          detail?: string
          evidence?: Json
          fingerprint?: string
          id?: string
          invoice_id?: string
          org_id?: string
          overridable?: boolean
          resolution_note?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          resolver?: string
          severity?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoice_exceptions_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_exceptions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      invoice_lines: {
        Row: {
          amount: number | null
          description: string | null
          id: string
          invoice_id: string
          line_no: number
          org_id: string
          quantity: number | null
          unit_price: number | null
        }
        Insert: {
          amount?: number | null
          description?: string | null
          id?: string
          invoice_id: string
          line_no: number
          org_id: string
          quantity?: number | null
          unit_price?: number | null
        }
        Update: {
          amount?: number | null
          description?: string | null
          id?: string
          invoice_id?: string
          line_no?: number
          org_id?: string
          quantity?: number | null
          unit_price?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "invoice_lines_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_lines_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoice_lines_org_id_invoice_id_fkey"
            columns: ["org_id", "invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["org_id", "id"]
          },
        ]
      }
      invoices: {
        Row: {
          agent_session_id: string | null
          ai_extraction: Json | null
          ai_summary: string | null
          approval_round: number
          approved_at: string | null
          approved_snapshot: Json | null
          commitment_id: string | null
          created_at: string
          created_by: string
          currency: string
          description: string | null
          due_date: string | null
          extraction_error: string | null
          extraction_started_at: string | null
          extraction_status: string
          field_confidence: Json
          file_name: string | null
          id: string
          invoice_date: string | null
          invoice_number: string | null
          org_id: string
          payment_terms: string | null
          po_number: string | null
          project_reference: string | null
          rejected_reason: string | null
          retainage_amount: number | null
          source: string
          status: string
          submitted_at: string | null
          submitted_by: string | null
          subtotal: number | null
          sync_status: string
          tax_amount: number | null
          total_amount: number | null
          updated_at: string
          upload_id: string | null
          vendor_id: string | null
          vendor_name_extracted: string | null
        }
        Insert: {
          agent_session_id?: string | null
          ai_extraction?: Json | null
          ai_summary?: string | null
          approval_round?: number
          approved_at?: string | null
          approved_snapshot?: Json | null
          commitment_id?: string | null
          created_at?: string
          created_by?: string
          currency?: string
          description?: string | null
          due_date?: string | null
          extraction_error?: string | null
          extraction_started_at?: string | null
          extraction_status?: string
          field_confidence?: Json
          file_name?: string | null
          id?: string
          invoice_date?: string | null
          invoice_number?: string | null
          org_id: string
          payment_terms?: string | null
          po_number?: string | null
          project_reference?: string | null
          rejected_reason?: string | null
          retainage_amount?: number | null
          source?: string
          status?: string
          submitted_at?: string | null
          submitted_by?: string | null
          subtotal?: number | null
          sync_status?: string
          tax_amount?: number | null
          total_amount?: number | null
          updated_at?: string
          upload_id?: string | null
          vendor_id?: string | null
          vendor_name_extracted?: string | null
        }
        Update: {
          agent_session_id?: string | null
          ai_extraction?: Json | null
          ai_summary?: string | null
          approval_round?: number
          approved_at?: string | null
          approved_snapshot?: Json | null
          commitment_id?: string | null
          created_at?: string
          created_by?: string
          currency?: string
          description?: string | null
          due_date?: string | null
          extraction_error?: string | null
          extraction_started_at?: string | null
          extraction_status?: string
          field_confidence?: Json
          file_name?: string | null
          id?: string
          invoice_date?: string | null
          invoice_number?: string | null
          org_id?: string
          payment_terms?: string | null
          po_number?: string | null
          project_reference?: string | null
          rejected_reason?: string | null
          retainage_amount?: number | null
          source?: string
          status?: string
          submitted_at?: string | null
          submitted_by?: string | null
          subtotal?: number | null
          sync_status?: string
          tax_amount?: number | null
          total_amount?: number | null
          updated_at?: string
          upload_id?: string | null
          vendor_id?: string | null
          vendor_name_extracted?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invoices_commitment_id_fkey"
            columns: ["commitment_id"]
            isOneToOne: false
            referencedRelation: "commitments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_org_id_commitment_id_fkey"
            columns: ["org_id", "commitment_id"]
            isOneToOne: false
            referencedRelation: "commitments"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoices_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_org_id_vendor_id_fkey"
            columns: ["org_id", "vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "invoices_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["id"]
          },
        ]
      }
      org_invites: {
        Row: {
          accepted_at: string | null
          approval_limit: number | null
          created_at: string
          email: string
          id: string
          invited_by: string
          org_id: string
          role: string
        }
        Insert: {
          accepted_at?: string | null
          approval_limit?: number | null
          created_at?: string
          email: string
          id?: string
          invited_by: string
          org_id: string
          role: string
        }
        Update: {
          accepted_at?: string | null
          approval_limit?: number | null
          created_at?: string
          email?: string
          id?: string
          invited_by?: string
          org_id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_invites_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      org_members: {
        Row: {
          active: boolean
          approval_limit: number | null
          created_at: string
          display_name: string
          email: string
          org_id: string
          role: string
          user_id: string
        }
        Insert: {
          active?: boolean
          approval_limit?: number | null
          created_at?: string
          display_name?: string
          email: string
          org_id: string
          role: string
          user_id: string
        }
        Update: {
          active?: boolean
          approval_limit?: number | null
          created_at?: string
          display_name?: string
          email?: string
          org_id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_members_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      org_settings: {
        Row: {
          allow_self_approval: boolean
          ap_can_sync: boolean
          approval_reminder_hours: number
          export_target: string
          low_confidence_threshold: number
          org_id: string
          possible_duplicate_days: number
          require_po: boolean
          require_po_over_amount: number
          updated_at: string
          variance_amount: number
          variance_pct: number
        }
        Insert: {
          allow_self_approval?: boolean
          ap_can_sync?: boolean
          approval_reminder_hours?: number
          export_target?: string
          low_confidence_threshold?: number
          org_id: string
          possible_duplicate_days?: number
          require_po?: boolean
          require_po_over_amount?: number
          updated_at?: string
          variance_amount?: number
          variance_pct?: number
        }
        Update: {
          allow_self_approval?: boolean
          ap_can_sync?: boolean
          approval_reminder_hours?: number
          export_target?: string
          low_confidence_threshold?: number
          org_id?: string
          possible_duplicate_days?: number
          require_po?: boolean
          require_po_over_amount?: number
          updated_at?: string
          variance_amount?: number
          variance_pct?: number
        }
        Relationships: [
          {
            foreignKeyName: "org_settings_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: true
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      orgs: {
        Row: {
          created_at: string
          created_by: string
          id: string
          is_demo: boolean
          legal_entity: string | null
          name: string
        }
        Insert: {
          created_at?: string
          created_by?: string
          id?: string
          is_demo?: boolean
          legal_entity?: string | null
          name: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          is_demo?: boolean
          legal_entity?: string | null
          name?: string
        }
        Relationships: []
      }
      projects: {
        Row: {
          address: string | null
          code: string
          created_at: string
          external_id: string | null
          id: string
          legal_entity: string | null
          name: string
          org_id: string
          project_manager_user_id: string | null
          status: string
        }
        Insert: {
          address?: string | null
          code: string
          created_at?: string
          external_id?: string | null
          id?: string
          legal_entity?: string | null
          name: string
          org_id: string
          project_manager_user_id?: string | null
          status?: string
        }
        Update: {
          address?: string | null
          code?: string
          created_at?: string
          external_id?: string | null
          id?: string
          legal_entity?: string | null
          name?: string
          org_id?: string
          project_manager_user_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "projects_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
      sync_records: {
        Row: {
          attempt: number
          batch_id: string
          created_at: string
          error: string | null
          external_id: string | null
          id: string
          idempotency_key: string
          invoice_id: string
          org_id: string
          payload: Json
          status: string
          target: string
          updated_at: string
        }
        Insert: {
          attempt: number
          batch_id: string
          created_at?: string
          error?: string | null
          external_id?: string | null
          id?: string
          idempotency_key: string
          invoice_id: string
          org_id: string
          payload: Json
          status?: string
          target: string
          updated_at?: string
        }
        Update: {
          attempt?: number
          batch_id?: string
          created_at?: string
          error?: string | null
          external_id?: string | null
          id?: string
          idempotency_key?: string
          invoice_id?: string
          org_id?: string
          payload?: Json
          status?: string
          target?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sync_records_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "export_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sync_records_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sync_records_org_id_batch_id_fkey"
            columns: ["org_id", "batch_id"]
            isOneToOne: false
            referencedRelation: "export_batches"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "sync_records_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sync_records_org_id_invoice_id_fkey"
            columns: ["org_id", "invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["org_id", "id"]
          },
        ]
      }
      vendor_aliases: {
        Row: {
          alias: string
          created_at: string
          id: string
          learned_from_invoice_id: string | null
          org_id: string
          vendor_id: string
        }
        Insert: {
          alias: string
          created_at?: string
          id?: string
          learned_from_invoice_id?: string | null
          org_id: string
          vendor_id: string
        }
        Update: {
          alias?: string
          created_at?: string
          id?: string
          learned_from_invoice_id?: string | null
          org_id?: string
          vendor_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vendor_aliases_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vendor_aliases_org_id_vendor_id_fkey"
            columns: ["org_id", "vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "vendor_aliases_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "vendors"
            referencedColumns: ["id"]
          },
        ]
      }
      vendors: {
        Row: {
          address: string | null
          code: string
          created_at: string
          default_cost_type_id: string | null
          default_gl_account_id: string | null
          email: string | null
          external_id: string | null
          id: string
          name: string
          org_id: string
          payment_terms: string | null
          phone: string | null
          status: string
          tax_id: string | null
        }
        Insert: {
          address?: string | null
          code: string
          created_at?: string
          default_cost_type_id?: string | null
          default_gl_account_id?: string | null
          email?: string | null
          external_id?: string | null
          id?: string
          name: string
          org_id: string
          payment_terms?: string | null
          phone?: string | null
          status?: string
          tax_id?: string | null
        }
        Update: {
          address?: string | null
          code?: string
          created_at?: string
          default_cost_type_id?: string | null
          default_gl_account_id?: string | null
          email?: string | null
          external_id?: string | null
          id?: string
          name?: string
          org_id?: string
          payment_terms?: string | null
          phone?: string | null
          status?: string
          tax_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vendors_org_id_default_cost_type_id_fkey"
            columns: ["org_id", "default_cost_type_id"]
            isOneToOne: false
            referencedRelation: "cost_types"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "vendors_org_id_default_gl_account_id_fkey"
            columns: ["org_id", "default_gl_account_id"]
            isOneToOne: false
            referencedRelation: "gl_accounts"
            referencedColumns: ["org_id", "id"]
          },
          {
            foreignKeyName: "vendors_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "orgs"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      _actor_kind: { Args: never; Returns: string }
      _audit: {
        Args: {
          p_action: string
          p_details?: Json
          p_entity: string
          p_entity_id: string
          p_invoice: string
          p_org: string
          p_summary: string
        }
        Returns: undefined
      }
      _can_decide_step: {
        Args: {
          inv: Database["public"]["Tables"]["invoices"]["Row"]
          s: Database["public"]["Tables"]["approval_steps"]["Row"]
          st: Database["public"]["Tables"]["org_settings"]["Row"]
        }
        Returns: string
      }
      _can_sync: { Args: { p_org: string }; Returns: boolean }
      _create_demo_base_v2: { Args: never; Returns: string }
      _current_user_identity: {
        Args: never
        Returns: {
          email: string
          name: string
          verified: boolean
        }[]
      }
      _date: { Args: { p: string }; Returns: string }
      _invoice_checks: {
        Args: { p_invoice: string; p_log?: boolean }
        Returns: Json
      }
      _invoice_snapshot: { Args: { p_invoice: string }; Returns: Json }
      _num: { Args: { p: string }; Returns: number }
      _require: {
        Args: { p_message: string; p_ok: boolean }
        Returns: undefined
      }
      _seed_org: { Args: { p_org: string }; Returns: undefined }
      _uuid_in_org: {
        Args: { p_org: string; p_table: string; p_value: string }
        Returns: string
      }
      accept_invitations: { Args: never; Returns: Json }
      agent_begin_extraction: {
        Args: { p_invoice: string; p_session_id?: string }
        Returns: Json
      }
      agent_fail_extraction: {
        Args: { p_error: string; p_invoice: string }
        Returns: undefined
      }
      agent_submit_extraction: {
        Args: { p: Json; p_invoice: string }
        Returns: Json
      }
      app_can: { Args: { p_org: string; p_perm: string }; Returns: boolean }
      app_invoice_editable: { Args: { p_invoice: string }; Returns: boolean }
      app_invoice_visible: { Args: { p_invoice: string }; Returns: boolean }
      app_norm_name: { Args: { p: string }; Returns: string }
      app_norm_ref: { Args: { p: string }; Returns: string }
      app_pm_linked: { Args: { p_invoice: string }; Returns: boolean }
      app_role: { Args: { p_org: string }; Returns: string }
      app_uid: { Args: never; Returns: string }
      create_demo_organization: { Args: never; Returns: string }
      create_export_batch: { Args: { p_org: string }; Returns: Json }
      create_organization: {
        Args: { p_legal_entity?: string; p_name: string }
        Returns: string
      }
      decide_invoice: {
        Args: { p_comment?: string; p_decision: string; p_invoice: string }
        Returns: Json
      }
      invite_member: {
        Args: {
          p_approval_limit?: number
          p_email: string
          p_org: string
          p_role: string
        }
        Returns: Json
      }
      reassign_approval: {
        Args: { p_reason: string; p_step: string; p_user: string }
        Returns: undefined
      }
      record_sync_results: {
        Args: { p_batch: string; p_results: Json }
        Returns: Json
      }
      recover_extraction: {
        Args: { p_invoice: string; p_reason: string; p_session: string }
        Returns: boolean
      }
      reopen_invoice: {
        Args: { p_invoice: string; p_reason: string }
        Returns: undefined
      }
      resolve_exception: {
        Args: { p_action: string; p_exception: string; p_note: string }
        Returns: undefined
      }
      retry_extraction: { Args: { p_invoice: string }; Returns: undefined }
      revoke_invite: { Args: { p_invite: string }; Returns: undefined }
      run_invoice_checks: { Args: { p_invoice: string }; Returns: Json }
      start_manual_entry: { Args: { p_invoice: string }; Returns: Json }
      submit_invoice: { Args: { p_invoice: string }; Returns: Json }
      trestle_read: { Args: { p_key: string; p_params?: Json }; Returns: Json }
      update_member: {
        Args: {
          p_active: boolean
          p_approval_limit: number
          p_org: string
          p_role: string
          p_user: string
        }
        Returns: undefined
      }
      void_invoice: {
        Args: { p_invoice: string; p_reason: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
