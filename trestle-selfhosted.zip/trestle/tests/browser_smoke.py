"""Draft-only browser acceptance checks. Set APP_URL, TEST_EMAIL and TEST_PASSWORD.
Uses the test account's isolated demo; never run against production or an account with important demo edits.
"""
import os, json, csv, io
from decimal import Decimal
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
URL=os.environ['APP_URL']; EMAIL=os.environ['TEST_EMAIL']; PASSWORD=os.environ['TEST_PASSWORD']
OUT=Path(os.environ.get('TEST_OUTPUT','/tmp/trestle-final'));OUT.mkdir(parents=True,exist_ok=True)
results=[]
def passed(name):results.append({'check':name,'result':'PASS'});print('PASS',name,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=False)
 ctx=b.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
 page=ctx.new_page();errors=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 try:
  page.goto(URL);page.get_by_label('Work email',exact=True).fill(EMAIL);page.get_by_label('Password',exact=True).fill(PASSWORD)
  page.get_by_role('button',name='Sign in',exact=True).click()
  page.get_by_role('button',name='Open demo company',exact=True).wait_for(timeout=60000)
  page.get_by_role('button',name='Open demo company',exact=True).click()
  expect(page.get_by_text('Try the complete workflow',exact=True)).to_be_visible(timeout=60000)
  passed('Create/open isolated demo from existing company')
  demo=page.get_by_label('Company',exact=True).input_value();options=page.get_by_label('Company',exact=True).locator('option').all_text_contents()
  page.screenshot(path=str(OUT/'overview-desktop.png'),full_page=True)
  page.goto(URL+'/#/invoices?filter=all');expect(page.locator('tbody tr')).to_have_count(15,timeout=30000)
  passed('Demo has 15 invoices across workflow states')
  page.get_by_role('link',name='GSR-88214',exact=True).click()
  expect(page.get_by_label('Synthetic invoice source')).to_be_visible(timeout=30000)
  expect(page.get_by_role('button',name='Submit for approval',exact=True)).to_be_enabled(timeout=30000)
  page.screenshot(path=str(OUT/'review-desktop.png'),full_page=False)
  passed('Source preview and clean invoice review')
  page.get_by_role('button',name='Submit for approval',exact=True).click()
  expect(page.get_by_role('button',name='Approve',exact=True)).to_be_visible(timeout=30000)
  page.reload();expect(page.get_by_role('button',name='Approve',exact=True)).to_be_visible(timeout=30000)
  passed('Submission persists across reload')
  page.get_by_role('button',name='Approve',exact=True).click()
  expect(page.get_by_text('Approved. Prepare a CSV batch in Accounting exports.',exact=False)).to_be_visible(timeout=30000)
  passed('Demo approval completes without a second account')
  page.goto(URL+'/#/integrations');expect(page.get_by_role('button',name='Create export batch',exact=True)).to_be_enabled(timeout=30000)
  with page.expect_download() as download:
   page.get_by_role('button',name='Create export batch',exact=True).click()
  path=OUT/'export.csv';download.value.save_as(path)
  records=list(csv.DictReader(path.open())); unique={r['idempotency_key']:Decimal(r['invoice_total']) for r in records}
  assert len(unique)==3 and sum(unique.values())==Decimal('4850'),unique
  assert sum(Decimal(r['line_amount']) for r in records)==Decimal('4850')
  passed('CSV export reconciles: 3 invoices, $4,850 including failed-import retry')
  row=page.get_by_role('row').filter(has_text='#4');expect(row).to_be_visible(timeout=30000);row.get_by_role('button',name='Results',exact=True).click()
  dlg=page.get_by_role('dialog');r=dlg.get_by_role('row').filter(has_text='GSR-88214')
  r.get_by_label('External ID',exact=True).fill('SIMULATED-UI-650');r.get_by_role('button',name='Save',exact=True).click()
  expect(r.get_by_text('SIMULATED-UI-650',exact=True)).to_be_visible(timeout=30000)
  dlg.get_by_label('Close',exact=True).first.click();page.reload();expect(page.get_by_role('row').filter(has_text='#4')).to_contain_text('1 posted',timeout=30000)
  passed('Accounting confirmation saves and survives reload')
  page.goto(URL+'/#/invoices?filter=duplicates');page.get_by_role('link',name='GSR-88120',exact=True).first.click()
  expect(page.get_by_role('button',name='Submit for approval',exact=True)).to_be_disabled(timeout=30000)
  passed('Duplicate invoice cannot be submitted')
  page.goto(URL+'/#/reports');expect(page.get_by_role('heading',name='Reports',exact=True)).to_be_visible(timeout=30000)
  for tab in ['Invoice register','Job cost by cost code','Commitments vs billed','Exceptions','Processing time']:
   page.get_by_role('tab',name=tab,exact=True).click();page.wait_for_timeout(1100)
   assert 'Could not refresh data:' not in page.inner_text('main'),tab
  passed('All five report views load')
  for route,title in [('vendors','Vendors'),('projects','Projects & cost codes'),('activity','Agent activity'),('approvals','Approvals'),('settings','Settings'),('assistant','AI assistant')]:
   page.goto(URL+'/#/'+route);page.wait_for_timeout(1400)
   assert 'Could not refresh data:' not in page.inner_text('main'),route
  passed('Core navigation renders without read errors')
  page.goto(URL+'/#/settings');page.get_by_role('tab',name='Company',exact=True).click()
  expect(page.get_by_label('Company name',exact=True)).to_have_value('Summit Ridge Builders · Demo',timeout=30000)
  real=next(o for o in options if 'Demo' not in o)
  page.get_by_label('Company',exact=True).select_option(label=real)
  expect(page.get_by_role('heading',name='Overview',exact=True)).to_be_visible(timeout=30000)
  expect(page.get_by_text('Try the complete workflow',exact=True)).to_have_count(0)
  page.goto(URL+'/#/settings');page.get_by_role('tab',name='Company',exact=True).click()
  expect(page.get_by_label('Company name',exact=True)).to_have_value(real,timeout=30000)
  passed('Switching companies resets route and form state; demo does not leak')
  page.get_by_role('button',name='Open demo company',exact=True).click()
  expect(page.get_by_text('Try the complete workflow',exact=True)).to_be_visible(timeout=30000)
  assert page.get_by_label('Company',exact=True).input_value()==demo
  assert page.get_by_label('Company',exact=True).locator('option').count()==len(options)
  passed('Reopening demo is idempotent and preserves changes')
  # Read failure is visible and recovers without signing out.
  page.route('**/data/query',lambda route:route.fulfill(status=503,content_type='application/json',body='{"error":"Test connection interrupted"}'))
  page.goto(URL+'/#/invoices');expect(page.get_by_role('button',name='Refresh now',exact=True)).to_be_visible(timeout=20000)
  page.unroute('**/data/query');page.get_by_role('button',name='Refresh now',exact=True).click()
  expect(page.get_by_role('button',name='Refresh now',exact=True)).to_have_count(0,timeout=30000)
  passed('Visible read-error recovery without data loss')
  page.goto(URL+'/#/');page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(1200)
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
  page.screenshot(path=str(OUT/'overview-mobile.png'),full_page=False)
  page.get_by_role('button',name='Open menu',exact=True).click();expect(page.get_by_role('button',name='Close menu',exact=True)).to_be_visible()
  page.get_by_role('button',name='Close menu',exact=True).click()
  passed('Mobile overview fits 390px and navigation opens/closes')
  page.set_viewport_size({'width':1440,'height':1000});ctx.storage_state(path=str(OUT/'session.json'))
  (OUT/'demo.json').write_text(json.dumps({'org':demo,'email':EMAIL}))
  assert not errors,errors
  passed('No browser JavaScript errors')
 finally:
  page.screenshot(path=str(OUT/'last-screen.png'),full_page=False)
  (OUT/'results.json').write_text(json.dumps(results,indent=2));b.close()
