\set ON_ERROR_STOP on
BEGIN;
-- Pass a real test user's id from the draft database, never run on production.
SELECT set_config('request.jwt.claims', json_build_object('sub', :'test_user')::text, true);
SELECT create_demo_organization() AS demo_org \gset
SELECT set_config('test.demo_org', :'demo_org', true);
DO $$
DECLARE o uuid := current_setting('test.demo_org')::uuid;
BEGIN
 IF (SELECT count(*) FROM invoices WHERE org_id=o) <> 15 THEN RAISE EXCEPTION 'Expected 15 invoices'; END IF;
 IF (SELECT count(*) FROM vendors WHERE org_id=o) <> 6 THEN RAISE EXCEPTION 'Expected 6 vendors'; END IF;
 IF (SELECT count(*) FROM projects WHERE org_id=o) <> 3 THEN RAISE EXCEPTION 'Expected 3 jobs'; END IF;
 IF (SELECT count(*) FROM commitments WHERE org_id=o) <> 6 THEN RAISE EXCEPTION 'Expected 6 commitments'; END IF;
 IF create_demo_organization() <> o THEN RAISE EXCEPTION 'Demo creation must be idempotent'; END IF;
 IF EXISTS(SELECT 1 FROM invoices i WHERE org_id=o AND status='approved' AND (approved_snapshot IS NULL OR total_amount<>(SELECT sum((a->>'amount')::numeric) FROM jsonb_array_elements(approved_snapshot->'allocations') a))) THEN RAISE EXCEPTION 'Broken approved snapshot'; END IF;
 IF EXISTS(SELECT 1 FROM export_batches b WHERE b.org_id=o AND (b.invoice_total<>b.allocation_total OR b.invoice_count<>(SELECT count(*) FROM sync_records WHERE batch_id=b.id))) THEN RAISE EXCEPTION 'Broken export totals'; END IF;
 IF NOT EXISTS(SELECT 1 FROM invoice_exceptions e JOIN invoices i ON i.id=e.invoice_id WHERE e.org_id=o AND invoice_number='GSR-88120' AND e.code='duplicate' AND e.severity='blocking') THEN RAISE EXCEPTION 'Duplicate not detected'; END IF;
 IF NOT EXISTS(SELECT 1 FROM invoice_exceptions e JOIN invoices i ON i.id=e.invoice_id WHERE e.org_id=o AND invoice_number='GSR-88219' AND e.code='overbilling' AND e.severity='blocking') THEN RAISE EXCEPTION 'Overbilling not detected'; END IF;
 IF NOT EXISTS(SELECT 1 FROM invoices WHERE org_id=o AND invoice_number='CSS-1184' AND vendor_id IS NULL) THEN RAISE EXCEPTION 'Unmatched supplier scenario broken'; END IF;
 IF (SELECT sum(amount) FROM invoice_allocations WHERE invoice_id=(SELECT id FROM invoices WHERE org_id=o AND invoice_number='BS-6021')) <> 2187.50 THEN RAISE EXCEPTION 'Split coding does not balance'; END IF;
 IF EXISTS(SELECT 1 FROM invoices WHERE org_id=o AND ai_extraction->'demo_document' IS NULL) THEN RAISE EXCEPTION 'Missing source preview'; END IF;
END $$;
-- Exercise the real workflow, not direct status writes.
SELECT id AS clean_invoice FROM invoices WHERE org_id=:'demo_org' AND invoice_number='GSR-88214' \gset
SELECT submit_invoice(:'clean_invoice');
SELECT decide_invoice(:'clean_invoice','approve','Automated rollback-only demo verification');
SELECT create_export_batch(:'demo_org') AS result \gset
SELECT idempotency_key AS record_key, batch_id FROM sync_records WHERE invoice_id=:'clean_invoice' \gset
SELECT record_sync_results(:'batch_id', jsonb_build_array(jsonb_build_object('key',:'record_key','status','synced','external_id','SIMULATED-TEST-650')));
SELECT (record_sync_results(:'batch_id', jsonb_build_array(jsonb_build_object('key',:'record_key','status','synced','external_id','SIMULATED-TEST-650')))->>'unchanged')::int = 1 AS idempotent_confirmation;
-- Recovery must not overwrite another attempt or run twice.
DO $$
DECLARE o uuid := current_setting('test.demo_org')::uuid; i uuid;
BEGIN
 SELECT id INTO i FROM invoices WHERE org_id=o AND invoice_number='BS-6002';
 UPDATE invoices SET extraction_status='pending', agent_session_id='new-test-session' WHERE id=i;
 IF recover_extraction(i, 'old-session', 'stale test') THEN RAISE EXCEPTION 'Stale session overwrote newer run'; END IF;
 IF NOT recover_extraction(i, 'new-test-session', 'rollback-only recovery test') THEN RAISE EXCEPTION 'Recovery did not apply'; END IF;
 IF recover_extraction(i, 'new-test-session', 'repeat test') THEN RAISE EXCEPTION 'Recovery must be idempotent'; END IF;
 UPDATE invoices SET extraction_status='succeeded' WHERE id=i;
 IF recover_extraction(i, 'new-test-session', 'late test') THEN RAISE EXCEPTION 'Recovery overwrote completed extraction'; END IF;
 UPDATE invoices SET extraction_status='running' WHERE id=i;
 DELETE FROM invoice_lines WHERE invoice_id=i;
 BEGIN
   PERFORM agent_submit_extraction(i, '{"total_amount":975,"lines":[{"description":"Rental for 5 days","quantity":"5 days","unit_price":195,"amount":975}]}'::jsonb);
   RAISE EXCEPTION 'Malformed quantity was silently accepted';
 EXCEPTION WHEN SQLSTATE '42501' THEN
   IF SQLERRM NOT LIKE 'Line quantity must be a plain number%' THEN RAISE; END IF;
 END;
END $$;
SET LOCAL ROLE authenticated;
SELECT jsonb_array_length(trestle_read('q0',jsonb_build_array(app_uid()))) > 0 AS own_membership_visible;
ROLLBACK;
