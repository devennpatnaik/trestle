import { describe, expect, test, spyOn } from 'bun:test';
import { ALLOWED_QUERIES } from '../packages/queries';
import { readFileSync } from 'node:fs';
import app from '../backend/index';

describe('read contract', () => {
  test('every approved query is present in the committed invoker migration', () => {
    const migration = readFileSync('prisma/migrations/20261011000000_authenticated_reads/migration.sql', 'utf8');
    for (const [i, sql] of ALLOWED_QUERIES.entries()) {
      const format = sql.replace(/%/g, '%%').replace(/\$(\d+)/g, '%$1$L');
      expect(migration).toContain(`WHEN 'q${i}' THEN $query$${format}$query$`);
    }
    expect(migration).toContain('SECURITY INVOKER');
  });
  test('anonymous read is refused before database access', async () => {
    const r = await app.fetch(new Request('http://test/data/query', { method: 'POST', body: JSON.stringify({sql:ALLOWED_QUERIES[0],params:[]}) }), {} as never);
    expect(r.status).toBe(401);
  });
  test('anonymous intake start and recovery are refused', async () => {
    for (const route of ['start', 'reconcile']) {
      const r = await app.fetch(new Request(`http://test/intake/${route}`, {method:'POST',body:'{}'}),{} as never);
      expect(r.status).toBe(401);
    }
  });
  test('anonymous table write is refused', async () => {
    const r = await app.fetch(new Request('http://test/data/api/invoices', { method: 'POST', body: '{}' }), {} as never);
    expect(r.status).toBe(401);
  });
  test('an exhausted no-op write is an error, never a false success', async () => {
    const mock = spyOn(globalThis, 'fetch').mockImplementation(async () => new Response('[]', {status:200}));
    try {
      const r = await app.fetch(new Request('http://test/data/api/invoices?id=eq.test', {method:'PATCH',headers:{Authorization:'Bearer test','Content-Type':'application/json'},body:'{}'}),{NEON_DATA_API_URL:'http://database'} as never);
      expect(r.status).toBe(409);
      expect(mock).toHaveBeenCalledTimes(4);
    } finally { mock.mockRestore(); }
  });
  test('CORS supports the write methods and exposes import headers', async () => {
    const r = await app.fetch(new Request('http://test/data/api/invoices', {method:'OPTIONS',headers:{Origin:'http://localhost:5173','Access-Control-Request-Method':'PATCH','Access-Control-Request-Headers':'authorization,content-type,prefer'}}),{} as never);
    expect(r.status).toBe(204);
    expect(r.headers.get('Access-Control-Allow-Methods')).toContain('PATCH');
  });
});
