/** What the deployment sets on the backend's env. Typing only; values come from the deployment. */
export type Env = {
  DATABASE_URL: string;
  /** Older deployments only; auth now runs in this backend (lib/auth-server.ts). */
  NEON_AUTH_BASE_URL?: string;
  BOURNE_AUTH_SECRET: string;
  BOURNE_BACKEND_URL: string;
  BOURNE_APP_URL?: string;
  BOURNE_AUTH_EMAIL_FROM?: string;
  RESEND_API_KEY?: string;
  NEON_DATA_API_URL: string;
  LIVE: DurableObjectNamespace;
  BOURNE_PROJECT_ID: string;
  BOURNE_BUILD_ID: string;
  BOURNE_RUNTIME_URL: string;
  BOURNE_AGENTS: unknown;
  /** Set only by the self-hosted package; never on a Bourne deployment. */
  LOCAL_JWT_SECRET?: string;
};
