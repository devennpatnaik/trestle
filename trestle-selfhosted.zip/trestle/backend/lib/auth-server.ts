import { betterAuth } from 'better-auth';
import { bearer, emailOTP, jwt, organization } from 'better-auth/plugins';
import { Pool } from '@neondatabase/serverless';
import { Kysely, PostgresDialect, WithSchemaPlugin } from 'kysely';
import type { Env } from './env';

/** Origin the backend's tokens are issued by and for. The Data API and appUser both check it. */
export const authIssuer = (env: Env) => new URL(env.BOURNE_BACKEND_URL).origin;

async function sendEmail(env: Env, to: string, subject: string, text: string) {
  if (!env.RESEND_API_KEY || !env.BOURNE_AUTH_EMAIL_FROM) throw new Error('Email is not configured for this deployment');
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: env.BOURNE_AUTH_EMAIL_FROM, to: [to], subject, text }),
  });
  if (!response.ok) throw new Error(`Email could not be sent (${response.status})`);
}

/**
 * Better Auth over the neon_auth schema, built per request: a Worker cannot keep a database socket between requests.
 * Call close() once the response is sent.
 */
export function createAuth(env: Env) {
  const pool = new Pool({ connectionString: env.DATABASE_URL });
  const db = new Kysely<Record<string, never>>({ dialect: new PostgresDialect({ pool: pool as unknown as ConstructorParameters<typeof PostgresDialect>[0]['pool'] }), plugins: [new WithSchemaPlugin('neon_auth')] });
  const issuer = authIssuer(env);
  const appOrigins = [env.BOURNE_APP_URL].filter(Boolean).map(u => new URL(u as string).origin);

  const auth = betterAuth({
    appName: 'Trestle',
    secret: env.BOURNE_AUTH_SECRET,
    baseURL: issuer,
    basePath: '/api/auth',
    database: { db, type: 'postgres' },
    trustedOrigins: [...appOrigins, 'http://localhost:5173'],
    emailAndPassword: { enabled: true, autoSignIn: true, requireEmailVerification: false },
    advanced: {
      database: { generateId: 'uuid' },
      // The app is served from another origin than the backend, so the session cookie is cross-site.
      defaultCookieAttributes: { sameSite: 'none', secure: true, partitioned: true },
    },
    plugins: [
      bearer(),
      organization({ creatorRole: 'owner', membershipLimit: 100, organizationLimit: 10 }),
      emailOTP({
        otpLength: 6,
        expiresIn: 600,
        sendVerificationOTP: async ({ email, otp, type }) => {
          const purpose = type === 'forget-password' ? 'reset your password' : type === 'sign-in' ? 'sign in' : 'confirm your email address';
          await sendEmail(env, email, `Your Trestle code: ${otp}`, `Use this code to ${purpose} in Trestle: ${otp}\n\nIt expires in 10 minutes. If you did not ask for it, ignore this email.`);
        },
      }),
      jwt({
        jwks: { jwksPath: '/.well-known/jwks.json' },
        jwt: {
          issuer,
          audience: issuer,
          expirationTime: '15m',
          // The Data API switches to the role in the token; auth.session() -> 'o' ->> 'id' is the active organization.
          definePayload: ({ user, session }) => ({
            role: 'authenticated',
            email: user.email,
            name: user.name,
            email_verified: user.emailVerified,
            ...(session.activeOrganizationId ? { o: { id: session.activeOrganizationId } } : {}),
          }),
        },
      }),
    ],
  });
  return { auth, close: () => pool.end() };
}
