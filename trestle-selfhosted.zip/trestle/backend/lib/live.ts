import postgres from 'postgres';
import { appUser } from './auth';
import type { Env } from './env';

const PING_MS = 25_000;
const BATCH_MS = 20;

/**
 * GET /live?token=… upgrades to a WebSocket that says which public tables changed, never rows. A browser cannot
 * set headers on a WebSocket, so the user's token travels in the query string and is verified before upgrading.
 */
export const liveSocket = async (env: Env, request: Request): Promise<Response> => {
  if (request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') return new Response('Expected a WebSocket', { status: 426 });
  const token = new URL(request.url).searchParams.get('token');
  if (!token) return new Response('Sign in first', { status: 401 });
  const user = await appUser(env, new Request(request.url, { headers: { Authorization: `Bearer ${token}` } }));
  if (!user) return new Response('Sign in first', { status: 401 });
  return env.LIVE.get(env.LIVE.idFromName('live')).fetch(request);
};

/**
 * One Durable Object per branch holds the single LISTEN connection on bourne_changes (fed by the bourne_notify
 * triggers on every public table) and fans table names out to every open socket.
 */
export class Live implements DurableObject {
  private sockets = new Set<WebSocket>();
  private sql: postgres.Sql | null = null;
  private listening: Promise<unknown> | null = null;
  private pending = new Set<string>();
  private flushTimer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;

  constructor(private state: DurableObjectState, private env: Env) {}

  async fetch(request: Request): Promise<Response> {
    if (request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') return new Response('Expected a WebSocket', { status: 426 });
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    server.accept();
    this.sockets.add(server);
    const drop = () => {
      this.sockets.delete(server);
      if (!this.sockets.size) void this.stop();
    };
    server.addEventListener('close', drop);
    server.addEventListener('error', drop);

    try {
      await this.start();
      server.send(JSON.stringify({ type: 'ready' }));
    } catch (error) {
      server.close(1011, error instanceof Error ? error.message.slice(0, 100) : 'Live updates unavailable');
      this.sockets.delete(server);
    }
    return new Response(null, { status: 101, webSocket: client });
  }

  private start(): Promise<unknown> {
    if (this.listening) return this.listening;
    this.sql = postgres(this.env.DATABASE_URL, { max: 1, idle_timeout: 0, fetch_types: false });
    this.listening = this.sql
      .listen('bourne_changes', payload => this.queue(payload), () => this.broadcast({ type: 'ready' }))
      .catch(error => {
        this.listening = null;
        for (const socket of this.sockets) socket.close(1011, 'Live updates restarting');
        throw error;
      });
    this.pingTimer ??= setInterval(() => this.broadcast({ type: 'ping' }), PING_MS);
    return this.listening;
  }

  private async stop() {
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.pingTimer = null;
    const sql = this.sql;
    this.sql = null;
    this.listening = null;
    await sql?.end({ timeout: 1 }).catch(() => undefined);
  }

  private queue(payload: string) {
    try {
      const table = (JSON.parse(payload) as { t?: unknown }).t;
      if (typeof table === 'string') this.pending.add(table);
    } catch {
      return;
    }
    this.flushTimer ??= setTimeout(() => {
      this.flushTimer = null;
      const tables = [...this.pending];
      this.pending.clear();
      if (tables.length) this.broadcast({ type: 'changes', tables });
    }, BATCH_MS);
  }

  private broadcast(message: object) {
    const text = JSON.stringify(message);
    for (const socket of this.sockets) {
      try {
        socket.send(text);
      } catch {
        this.sockets.delete(socket);
      }
    }
  }
}
