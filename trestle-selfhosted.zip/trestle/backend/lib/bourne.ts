import { Hono } from 'hono';
import type { Env } from './env';

const FORWARDED_REQUEST_HEADERS = ['authorization', 'content-type', 'accept', 'last-event-id'];
const FORWARDED_RESPONSE_HEADERS = ['content-type', 'cache-control', 'content-disposition', 'content-length', 'location'];

/**
 * /bourne/* forwards the app's upload, artifact and agent-session requests to the Bourne runtime of this
 * deployment, with the end user's bearer token, so the runtime applies that user's identity. Streams both ways.
 */
export const bourneRoutes = new Hono<{ Bindings: Env }>().all('/*', async c => {
  const url = new URL(c.req.url);
  const path = url.pathname.replace(/^\/bourne/, '') + url.search;

  const headers = new Headers();
  for (const name of FORWARDED_REQUEST_HEADERS) {
    const value = c.req.header(name);
    if (value) headers.set(name, value);
  }

  const hasBody = !['GET', 'HEAD'].includes(c.req.method);
  const upstream = await fetch(`${c.env.BOURNE_RUNTIME_URL}${path}`, {
    method: c.req.method,
    headers,
    body: hasBody ? c.req.raw.body : undefined,
    redirect: 'manual',
  });

  const responseHeaders = new Headers();
  for (const name of FORWARDED_RESPONSE_HEADERS) {
    const value = upstream.headers.get(name);
    if (value) responseHeaders.set(name, value);
  }
  return new Response(upstream.body, { status: upstream.status, headers: responseHeaders });
});
