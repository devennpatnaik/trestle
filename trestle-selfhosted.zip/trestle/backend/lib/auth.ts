import { neon } from '@neondatabase/serverless';
import { createLocalJWKSet, errors, jwtVerify, type JSONWebKeySet, type JWK } from 'jose';

let keySet: ReturnType<typeof createLocalJWKSet> | null = null;
let keysLoadedAt = 0;

/** Public keys the backend's auth server (lib/auth-server.ts) signs tokens with, from neon_auth.jwks. Cached 10 minutes. */
async function signingKeys(databaseUrl: string) {
  if (keySet && Date.now() - keysLoadedAt < 600_000) return keySet;
  const rows = await neon(databaseUrl)`select id::text as id, "publicKey" as public_key, alg from neon_auth.jwks` as { id: string; public_key: string; alg: string | null }[];
  const keys: JWK[] = rows.map(r => ({ ...(JSON.parse(r.public_key) as JWK), kid: r.id, ...(r.alg ? { alg: r.alg } : {}) }));
  keySet = createLocalJWKSet({ keys } as JSONWebKeySet);
  keysLoadedAt = Date.now();
  return keySet;
}

/** The signed-in app user a request is from. */
export type AppUser = { userId: string; organizationId: string | null };

/**
 * The signed-in app user who sent the request, from its bearer token checked against the keys of this backend's auth server,
 * or null when the token is missing or invalid; answer null with 401. Throws when the auth server can't be reached.
 */
export const appUser = async (env: object, request: Request): Promise<AppUser | null> => {
  const authorization = request.headers.get('Authorization') ?? '';
  const token = authorization.match(/^Bearer[ ]+(.+)$/i)?.[1];
  if (!token) return null;

  // The self-hosted package (backend/selfhost) signs its own tokens with a shared secret instead of Neon Auth.
  const { LOCAL_JWT_SECRET } = env as { LOCAL_JWT_SECRET?: string };
  if (LOCAL_JWT_SECRET) {
    try {
      const { payload } = await jwtVerify(token, new TextEncoder().encode(LOCAL_JWT_SECRET), { issuer: 'trestle-selfhost', algorithms: ['HS256'] });
      return typeof payload.sub === 'string' && payload.sub.length ? { userId: payload.sub, organizationId: null } : null;
    } catch {
      return null;
    }
  }

  const { DATABASE_URL, BOURNE_BACKEND_URL } = env as { DATABASE_URL: string; BOURNE_BACKEND_URL: string };
  const issuer = new URL(BOURNE_BACKEND_URL).origin;

  let payload: Awaited<ReturnType<typeof jwtVerify>>['payload'];
  try {
    try {
      ({ payload } = await jwtVerify(token, await signingKeys(DATABASE_URL), { issuer, audience: issuer }));
    } catch (error) {
      // A key created since the keys were cached: reload them once.
      if (!(error instanceof errors.JWKSNoMatchingKey)) throw error;
      keysLoadedAt = 0;
      ({ payload } = await jwtVerify(token, await signingKeys(DATABASE_URL), { issuer, audience: issuer }));
    }
  } catch (error) {
    if (error instanceof errors.JOSEError) return null;
    throw error;
  }

  if (typeof payload.sub !== 'string' || !payload.sub.length) return null;
  const { id } = payload.o && typeof payload.o === 'object' ? (payload.o as { id?: unknown }) : {};

  return { userId: payload.sub, organizationId: typeof id === 'string' && id.length ? id : null };
};
