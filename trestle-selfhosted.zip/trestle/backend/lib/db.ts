import type { Env } from './env';

/** Every request goes to the Data API with the caller's token; it supplies identity and enforces RLS. */
export function userDb(env: Env, request: Request) {
  return async (path: string, body: object): Promise<Response> => fetch(`${env.NEON_DATA_API_URL.replace(/\/$/, '')}/${path}`, {
    method: 'POST', headers: { Authorization: request.headers.get('Authorization') ?? '', 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

/** Table reads and conditional writes with exactly the caller's privileges. */
export function userDbRequest(env: Env, request: Request, path: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers);
  headers.set('Authorization', request.headers.get('Authorization') ?? '');
  headers.set('Content-Type', 'application/json');
  return fetch(`${env.NEON_DATA_API_URL.replace(/\/$/, '')}/${path}`, { ...init, headers });
}
