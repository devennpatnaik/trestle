import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { createAuth } from '../lib/auth-server';
import type { Env } from '../lib/env';

/** Sign-up, sign-in, email codes, sessions, tokens and the token keys, served by Better Auth (lib/auth-server.ts). */
export const authRoutes = new Hono<{ Bindings: Env }>()
  .use('*', cors({
    origin: (origin, c) => {
      const allowed = [c.env.BOURNE_APP_URL && new URL(c.env.BOURNE_APP_URL).origin, 'http://localhost:5173'];
      return allowed.includes(origin) ? origin : null;
    },
    credentials: true,
    allowMethods: ['GET', 'POST', 'OPTIONS'],
    exposeHeaders: ['set-auth-jwt', 'set-auth-token'],
    maxAge: 600,
  }))
  .on(['GET', 'POST'], '/*', async c => {
    const { auth, close } = createAuth(c.env);
    try {
      // The token keys are served at Better Auth's default /jwks path too, for verifiers that use it.
      const url = new URL(c.req.url);
      if (url.pathname === '/api/auth/jwks') {
        url.pathname = '/api/auth/.well-known/jwks.json';
        return await auth.handler(new Request(url, c.req.raw));
      }
      return await auth.handler(c.req.raw);
    } finally {
      c.executionCtx.waitUntil(close());
    }
  });
