import { Hono } from 'hono';
import type { Env } from '../lib/env';

const REQUEST_HEADERS = ['authorization', 'content-type', 'accept', 'prefer', 'range', 'range-unit', 'accept-profile', 'content-profile'];
const RESPONSE_HEADERS = ['content-type', 'content-range', 'preference-applied', 'location'];
const ATTEMPTS = 4;

/**
 * The Neon Data API sometimes runs a request on a fresh connection without establishing the caller's identity
 * (auth.user_id() and request.jwt.claims both empty; about 1 in 8 under concurrency in testing). The database then
 * refuses the write before changing anything: a workflow function raises "Sign in first", or row level security
 * matches no rows. Only those two outcomes are retried, so a retry never repeats a write that happened.
 */
const identityWasMissing = (method: string, status: number, body: string): boolean => {
  if (method === 'GET' || method === 'HEAD') return false;
  if ((status === 401 || status === 403) && body.includes('"Sign in first"')) return true;
  if (status === 403 && body.includes('row-level security')) return true;
  return (method === 'PATCH' || method === 'DELETE') && status === 200 && body.trim() === '[]';
};

/**
 * /data/api/* forwards the app's writes and function calls (inserts, updates, deletes and the workflow RPCs) to
 * this branch's Neon Data API with the signed-in user's own bearer token. The Data API applies that user's row
 * level security and grants, and every workflow rule lives in the database's policies and SECURITY DEFINER
 * functions, so this route adds no privilege of its own. Requests without a token are refused here.
 */
export const dataApiRoutes = new Hono<{ Bindings: Env }>().all('/*', async c => {
  if (!/^Bearer\s+\S+/i.test(c.req.header('authorization') ?? '')) return c.json({ message: 'Sign in first' }, 401);

  const url = new URL(c.req.url);
  const path = url.pathname.replace(/^\/data\/api/, '') + url.search;
  const headers = new Headers();
  for (const name of REQUEST_HEADERS) {
    const value = c.req.header(name);
    if (value) headers.set(name, value);
  }

  const method = c.req.method;
  const body = ['GET', 'HEAD'].includes(method) ? undefined : await c.req.arrayBuffer();
  const target = `${c.env.NEON_DATA_API_URL.replace(/\/$/, '')}${path}`;

  let upstream = await fetch(target, { method, headers, body });
  let text: string | null = null;
  for (let attempt = 1; attempt < ATTEMPTS && method !== 'GET' && method !== 'HEAD'; attempt++) {
    if (upstream.status >= 500) break;
    text = await upstream.text();
    if (!identityWasMissing(method, upstream.status, text)) break;
    await new Promise(resolve => setTimeout(resolve, 100 * attempt));
    upstream = await fetch(target, { method, headers, body });
    text = null;
  }

  const responseHeaders = new Headers();
  for (const name of RESPONSE_HEADERS) {
    const value = upstream.headers.get(name);
    if (value) responseHeaders.set(name, value);
  }
  if (['PATCH', 'DELETE'].includes(method) && upstream.status === 200 && text === null) text = await upstream.text();
  if (['PATCH', 'DELETE'].includes(method) && upstream.status === 200 && text?.trim() === '[]') {
    return c.json({ message: 'No record was changed. It may have changed in another tab, or your role cannot edit it. Refresh and try again.' }, 409);
  }
  return new Response([204, 205, 304].includes(upstream.status) ? null : text ?? upstream.body, { status: upstream.status, headers: responseHeaders });
});
