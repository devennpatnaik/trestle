import { Hono } from 'hono';
import { ALLOWED_QUERIES } from '@project/queries';
import { appUser } from '../lib/auth';
import { userDb } from '../lib/db';
import type { Env } from '../lib/env';

const keys = new Map(ALLOWED_QUERIES.map((sql, i) => [sql, `q${i}`]));

/** Fixed read identifiers + literal parameters; both the backend and the invoker RPC refuse arbitrary SQL. */
export const dataRoutes = new Hono<{ Bindings: Env }>().post('/query', async c => {
  if (!await appUser(c.env, c.req.raw)) return c.json({ error: 'Sign in first' }, 401);
  const body = await c.req.json<{ sql?: string; params?: unknown[] }>().catch(() => null);
  const key = body?.sql && keys.get(body.sql);
  if (!key) return c.json({ error: 'This query is not one the app is allowed to run' }, 400);
  const params = body?.params ?? [];
  if (!Array.isArray(params) || params.length > 4 || params.some(p => p !== null && !['string', 'number', 'boolean'].includes(typeof p))) {
    return c.json({ error: 'Invalid query parameters' }, 400);
  }
  const db = userDb(c.env, c.req.raw);
  for (let attempt = 0; attempt < 4; attempt++) {
    const response = await db('rpc/trestle_read', { p_key: key, p_params: params });
    const result = await response.json().catch(() => null) as unknown;
    if (response.ok && Array.isArray(result)) return c.json({ rows: result });
    const message = (result as { message?: string } | null)?.message ?? 'Could not load data. Please try again.';
    // Safe read-only retry when the Data API has not initialized the caller on a fresh connection.
    if (message === 'Sign in first' && attempt < 3) {
      await new Promise(resolve => setTimeout(resolve, 100 * (attempt + 1)));
      continue;
    }
    return c.json({ error: message }, response.status === 401 ? 401 : 503);
  }
  return c.json({ error: 'Please retry loading your data.' }, 503);
});
