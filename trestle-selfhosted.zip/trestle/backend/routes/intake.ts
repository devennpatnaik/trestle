import { Hono } from 'hono';
import { appUser } from '../lib/auth';
import { openAgentSession, sendAgentMessage } from '../lib/agents';
import { userDb, userDbRequest } from '../lib/db';
import type { Env } from '../lib/env';

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
type Invoice = { id: string; upload_id: string | null; created_by: string; agent_session_id: string | null; updated_at: string; extraction_status: string };
async function json<T>(response: Response): Promise<T> {
  const value = await response.json() as T & { message?: string; error?: string };
  if (!response.ok) throw new Error(value.message ?? value.error ?? `Request failed (${response.status})`);
  return value;
}

export const intakeRoutes = new Hono<{ Bindings: Env }>()
  .post('/start', async c => {
    const user = await appUser(c.env, c.req.raw);
    if (!user) return c.json({ error: 'Sign in to process invoices' }, 401);
    const body = await c.req.json<{ invoiceId?: string }>().catch(() => ({} as { invoiceId?: string }));
    if (!body.invoiceId || !uuid.test(body.invoiceId)) return c.json({ error: 'A valid invoice is required' }, 400);
    const id = body.invoiceId;
    const work = (async () => {
      const request = c.req.raw;
      const invoices = await json<Invoice[]>(await userDbRequest(c.env, request, `invoices?id=eq.${id}&select=id,upload_id,created_by,agent_session_id,updated_at,extraction_status`));
      const invoice = invoices[0];
      if (!invoice || invoice.created_by !== user.userId) return { error: 'Only the uploader can start this extraction', status: 403 };
      if (invoice.extraction_status !== 'pending' || invoice.agent_session_id) return { accepted: false, status: 200 };
      const claimed = await json<{ id: string }[]>(await userDbRequest(c.env, request, `invoices?id=eq.${id}&agent_session_id=is.null&extraction_status=eq.pending&select=id`, {
        method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ agent_session_id: 'dispatching' }),
      }));
      if (!claimed.length) return { accepted: false, status: 200 };
      let session = 'dispatching';
      try {
        session = await openAgentSession(c.env, request, 'invoice-intake');
        const saved = await json<{ id: string }[]>(await userDbRequest(c.env, request, `invoices?id=eq.${id}&agent_session_id=eq.dispatching&extraction_status=eq.pending&select=id`, {
          method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ agent_session_id: session }),
        }));
        if (!saved.length) return { accepted: false, status: 200 };
        // The file stays in durable storage; the agent reads it as the uploader. No browser lifetime dependency.
        await sendAgentMessage(c.env, request, session, `Process invoice ${id}. Read its document with read_app_file upload_id ${invoice.upload_id}.`);
        return { accepted: true, sessionId: session, status: 200 };
      } catch (error) {
        const message = error instanceof Error ? error.message : 'AI dispatch failed';
        await userDb(c.env, request)('rpc/recover_extraction', { p_invoice: id, p_session: session, p_reason: `Could not start AI extraction: ${message}` });
        return { error: message, status: 502 };
      }
    })();
    c.executionCtx.waitUntil(work);
    try {
      const result = await work;
      return c.json(result, result.status as 200 | 403 | 502);
    } catch (error) { return c.json({ error: error instanceof Error ? error.message : 'Could not start extraction' }, 503); }
  })
  .post('/reconcile', async c => {
    const user = await appUser(c.env, c.req.raw);
    if (!user) return c.json({ error: 'Sign in to check extractions' }, 401);
    const body = await c.req.json<{ orgId?: string }>().catch(() => ({} as { orgId?: string }));
    if (!body.orgId || !uuid.test(body.orgId)) return c.json({ error: 'A valid company is required' }, 400);
    try {
      const request = c.req.raw;
      const rows = await json<Invoice[]>(await userDbRequest(c.env, request, `invoices?org_id=eq.${body.orgId}&created_by=eq.${encodeURIComponent(user.userId)}&extraction_status=in.(pending,running)&agent_session_id=not.is.null&select=id,agent_session_id,updated_at&order=updated_at.asc&limit=20`));
      let recovered = 0;
      for (const invoice of rows) {
        let reason = '';
        if (invoice.agent_session_id === 'dispatching') {
          if (Date.now() - Date.parse(invoice.updated_at) > 180000) reason = 'AI dispatch was interrupted. Retry extraction or enter the fields by hand.';
        } else if (invoice.agent_session_id && uuid.test(invoice.agent_session_id)) {
          const history = await fetch(`${c.env.BOURNE_RUNTIME_URL}/agent-sessions/${invoice.agent_session_id}`, { headers: { Authorization: request.headers.get('Authorization') ?? '' } });
          if (!history.ok) continue; // A temporary outage must never mark a healthy run failed.
          const data = await history.json() as { session?: { status?: string }; messages?: { messageType: string }[] };
          if (data.session?.status !== 'running' && data.messages?.some(m => m.messageType === 'turn_terminal')) reason = 'The AI run ended without saving an extraction. Retry AI extraction, or enter the fields by hand.';
        }
        if (reason) {
          const applied = await json<boolean>(await userDb(c.env, request)('rpc/recover_extraction', { p_invoice: invoice.id, p_session: invoice.agent_session_id, p_reason: reason }));
          if (applied) recovered++;
        }
      }
      return c.json({ recovered });
    } catch (error) { return c.json({ error: error instanceof Error ? error.message : 'Could not check extraction status' }, 503); }
  });
