import { readdirSync, readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import type postgres from 'postgres';

/**
 * Brings a plain Postgres database up to the app's schema: the platform stand-ins in bootstrap.sql, then every
 * prisma/migrations/<name>/migration.sql not applied yet, in name order (the same order prisma migrate deploy uses),
 * each in its own transaction. Then it attaches the live-update trigger to every public table and asks PostgREST
 * to reload its schema cache.
 */
export async function migrate(sql: postgres.Sql, root: string, authenticatorPassword: string): Promise<string[]> {
  await sql.unsafe(readFileSync(join(import.meta.dir, 'bootstrap.sql'), 'utf8'));
  await sql.unsafe(`ALTER ROLE authenticator PASSWORD '${authenticatorPassword.replace(/'/g, "''")}'`);

  const dir = join(root, 'prisma', 'migrations');
  const names = readdirSync(dir).filter(name => existsSync(join(dir, name, 'migration.sql'))).sort();
  const done = new Set((await sql<{ name: string }[]>`select name from trestle_local.migrations`).map(r => r.name));
  const applied: string[] = [];
  for (const name of names) {
    if (done.has(name)) continue;
    const text = readFileSync(join(dir, name, 'migration.sql'), 'utf8');
    await sql.begin(async tx => {
      await tx.unsafe(text);
      await tx`insert into trestle_local.migrations (name) values (${name})`;
    });
    applied.push(name);
  }

  await sql.unsafe(`
    DO $$
    DECLARE t record;
    BEGIN
      FOR t IN
        SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public' AND c.relkind = 'r'
          AND NOT EXISTS (SELECT 1 FROM pg_trigger g WHERE g.tgrelid = c.oid AND g.tgname = 'bourne_notify')
      LOOP
        EXECUTE format('CREATE TRIGGER bourne_notify AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION bourne_runtime.emit_change()', t.relname);
      END LOOP;
    END
    $$;
  `);
  await sql`select pg_notify('pgrst', 'reload schema')`;
  return applied;
}
