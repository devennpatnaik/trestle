/**
 * Trestle, self-hosted. One process serves the built app and the API the app expects, against a local Postgres and
 * PostgREST (see docker-compose.yml and SELF_HOSTING.md):
 *
 *   /api/auth/*      email and password accounts (tokens signed with JWT_SECRET, which PostgREST also verifies)
 *   /api/data/*      the hosted backend's own read and write routes, pointed at PostgREST
 *   /api/bourne/uploads, /api/files/:id   invoice files, kept on disk under DATA_DIR
 *   /api/live        WebSocket naming tables that changed (Postgres LISTEN)
 *   /api/intake/*    AI extraction of uploaded invoices with the operator's ANTHROPIC_API_KEY
 *   /api/assistant   the read-only finance assistant
 *
 * Every user-facing database operation runs as the signed-in user (role authenticated plus their claims), so the
 * same row level security and workflow functions decide what is allowed as on the hosted platform.
 */
import { existsSync, mkdirSync, readFileSync, unlinkSync } from 'node:fs';
import { join, resolve, normalize } from 'node:path';
import { randomUUID } from 'node:crypto';
import { Hono, type Context } from 'hono';
import { SignJWT, jwtVerify } from 'jose';
import postgres from 'postgres';
import { appUser } from '../lib/auth';
import { dataRoutes } from '../routes/data';
import { dataApiRoutes } from '../routes/data-api';
import { migrate } from './migrate';
import { ASSISTANT_NOTE, EXTRACTION_SYSTEM, EXTRACTION_TOOL, SQL_TOOL, callModel, documentBlock, type AiConfig, type Message } from './ai';

// ------------------------------------------------------------------ configuration

const ROOT = resolve(import.meta.dir, '..', '..');
const required = (name: string) => {
  const value = process.env[name];
  if (!value) throw new Error(`Set ${name} (see .env.example)`);
  if (value.startsWith('change-me')) throw new Error(`${name} still has its placeholder value. Run ./setup.sh or put a long random value in .env`);
  return value;
};
const DATABASE_URL = required('DATABASE_URL');
const JWT_SECRET = required('JWT_SECRET');
if (JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
const POSTGREST_URL = process.env.POSTGREST_URL ?? 'http://localhost:3001';
const AUTHENTICATOR_PASSWORD = required('AUTHENTICATOR_PASSWORD');
const PORT = Number(process.env.PORT ?? 8080);
const DATA_DIR = resolve(process.env.DATA_DIR ?? join(ROOT, 'data'));
const DIST_DIR = resolve(process.env.DIST_DIR ?? join(ROOT, 'apps', 'untitled-app-6ac8544d7b02af3fede23b8b', 'dist-selfhost'));
const ALLOW_SIGNUP = (process.env.ALLOW_SIGNUP ?? 'true') !== 'false';
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
const ai: AiConfig | null = process.env.ANTHROPIC_API_KEY
  ? { apiKey: process.env.ANTHROPIC_API_KEY, model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-5', baseUrl: process.env.ANTHROPIC_BASE_URL ?? 'https://api.anthropic.com' }
  : null;

const secret = new TextEncoder().encode(JWT_SECRET);
const env = { LOCAL_JWT_SECRET: JWT_SECRET, NEON_DATA_API_URL: POSTGREST_URL };
const UPLOADS = join(DATA_DIR, 'uploads');
mkdirSync(UPLOADS, { recursive: true });

const sql = postgres(DATABASE_URL, { max: 10, onnotice: () => undefined });

// ------------------------------------------------------------------ helpers

type Tx = postgres.TransactionSql;
const claimsOf = (userId: string) => JSON.stringify({ sub: userId, role: 'authenticated', iss: 'trestle-selfhost' });

/** Runs fn in one transaction as the signed-in user, so row level security and grants apply exactly as in the app. */
async function asUser<T>(userId: string, fn: (tx: Tx) => Promise<T>, readOnly = false): Promise<T> {
  return (await sql.begin(readOnly ? 'read only' : 'read write', async tx => {
    await tx`select set_config('role', 'authenticated', true), set_config('request.jwt.claims', ${claimsOf(userId)}, true)`;
    if (readOnly) await tx`select set_config('statement_timeout', '15000', true)`;
    return fn(tx);
  })) as T;
}

async function issueToken(user: { id: string; email: string; name: string }) {
  const expiresAt = Date.now() + 7 * 24 * 3600 * 1000;
  const token = await new SignJWT({ role: 'authenticated', email: user.email })
    .setProtectedHeader({ alg: 'HS256' }).setSubject(user.id).setIssuer('trestle-selfhost')
    .setIssuedAt().setExpirationTime(Math.floor(expiresAt / 1000)).sign(secret);
  return { token, expiresAt, user: { ...user, emailVerified: true } };
}

const signedIn = async (c: Context) => appUser(env, c.req.raw);
const errorMessage = (error: unknown) => (error instanceof Error ? error.message : String(error));
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// ------------------------------------------------------------------ API

const api = new Hono();

api.get('/health', c => c.json({ ok: true, ai: Boolean(ai) }));

api.post('/auth/sign-up', async c => {
  if (!ALLOW_SIGNUP) return c.json({ error: 'New accounts are turned off on this server. Ask its administrator.' }, 403);
  const body = await c.req.json<{ email?: string; password?: string; name?: string }>().catch(() => ({} as Record<string, string>));
  const email = String(body.email ?? '').trim().toLowerCase();
  const password = String(body.password ?? '');
  const name = String(body.name ?? '').trim() || email;
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return c.json({ error: 'Enter a valid email address' }, 400);
  if (password.length < 8) return c.json({ error: 'Use a password of at least 8 characters' }, 400);
  const hash = await Bun.password.hash(password);
  try {
    const [user] = await sql.begin(async tx => {
      const rows = await tx<{ id: string; email: string; name: string }[]>`insert into neon_auth."user" (email, name) values (${email}, ${name}) returning id, email, name`;
      await tx`insert into trestle_local.credentials (user_id, password_hash) values (${rows[0]!.id}, ${hash})`;
      return rows;
    });
    return c.json(await issueToken(user!));
  } catch (error) {
    if (/duplicate key/.test(errorMessage(error))) return c.json({ error: 'An account with this email already exists. Sign in instead.' }, 409);
    throw error;
  }
});

api.post('/auth/sign-in', async c => {
  const body = await c.req.json<{ email?: string; password?: string }>().catch(() => ({} as Record<string, string>));
  const email = String(body.email ?? '').trim().toLowerCase();
  const [row] = await sql<{ id: string; email: string; name: string; password_hash: string }[]>`
    select u.id, u.email, u.name, c.password_hash from neon_auth."user" u join trestle_local.credentials c on c.user_id = u.id where u.email = ${email}`;
  if (!row || !(await Bun.password.verify(String(body.password ?? ''), row.password_hash))) return c.json({ error: 'Email or password is incorrect' }, 401);
  return c.json(await issueToken({ id: row.id, email: row.email, name: row.name }));
});

// The hosted backend's own routes: approved reads through trestle_read, and writes and workflow calls forwarded to
// PostgREST with the user's token.
api.route('/data/api', dataApiRoutes as unknown as Hono);
api.route('/data', dataRoutes as unknown as Hono);

// ---- uploads

api.post('/bourne/uploads', async c => {
  const user = await signedIn(c);
  if (!user) return c.json({ error: 'Sign in first' }, 401);
  const form = await c.req.formData().catch(() => null);
  const file = form?.get('file');
  if (!(file instanceof File)) return c.json({ error: 'Attach a file' }, 400);
  if (file.size > MAX_UPLOAD_BYTES) return c.json({ error: 'Files are limited to 25 MB' }, 413);
  const id = randomUUID();
  await Bun.write(join(UPLOADS, id), file);
  const [row] = await sql`insert into bourne_uploads (id, user_id, organization_id, name, mime_type, size_bytes)
    values (${id}, ${user.userId}, null, ${file.name || 'upload'}, ${file.type || 'application/octet-stream'}, ${file.size})
    returning id, user_id, organization_id, name, mime_type, size_bytes::int, created_at`;
  return c.json(row);
});

api.get('/bourne/uploads/:id/url', async c => {
  const user = await signedIn(c);
  if (!user) return c.json({ error: 'Sign in first' }, 401);
  const id = c.req.param('id');
  if (!uuid.test(id)) return c.json({ error: 'Not found' }, 404);
  const rows = await asUser(user.userId, tx => tx`select id from bourne_uploads where id = ${id}`, true);
  if (!rows.length) return c.json({ error: 'This file is not available to you' }, 404);
  const t = await new SignJWT({ upl: id }).setProtectedHeader({ alg: 'HS256' }).setIssuer('trestle-selfhost-file').setExpirationTime('10m').sign(secret);
  return c.json({ url: `/api/files/${id}?t=${t}` });
});

api.delete('/bourne/uploads/:id', async c => {
  const user = await signedIn(c);
  if (!user) return c.json({ error: 'Sign in first' }, 401);
  const id = c.req.param('id');
  const rows = uuid.test(id) ? await asUser(user.userId, tx => tx`delete from bourne_uploads where id = ${id} returning id`) : [];
  if (!rows.length) return c.json({ error: 'This file is not yours to delete' }, 404);
  try { unlinkSync(join(UPLOADS, id)); } catch { /* already gone */ }
  return c.json({ deleted: true });
});

api.get('/files/:id', async c => {
  const id = c.req.param('id');
  try {
    const { payload } = await jwtVerify(c.req.query('t') ?? '', secret, { issuer: 'trestle-selfhost-file', algorithms: ['HS256'] });
    if (payload.upl !== id) throw new Error('mismatch');
  } catch {
    return c.text('This link has expired. Reload the page.', 403);
  }
  const [row] = await sql<{ mime_type: string; name: string }[]>`select mime_type, name from bourne_uploads where id = ${id}`;
  const path = join(UPLOADS, id);
  if (!row || !existsSync(path)) return c.text('Not found', 404);
  return new Response(Bun.file(path), { headers: { 'content-type': row.mime_type, 'content-disposition': `inline; filename="${row.name.replace(/"/g, '')}"`, 'cache-control': 'private, max-age=300' } });
});

// ---- AI extraction

type InvoiceRow = { id: string; upload_id: string | null; created_by: string; agent_session_id: string | null; extraction_status: string; updated_at: string };
const runningJobs = new Set<string>();

async function recover(userId: string, invoiceId: string, session: string, reason: string) {
  await asUser(userId, tx => tx`select recover_extraction(${invoiceId}::uuid, ${session}, ${reason})`).catch(() => undefined);
}

async function extract(userId: string, invoice: InvoiceRow, session: string) {
  runningJobs.add(session);
  try {
    if (!ai) {
      await recover(userId, invoice.id, session, 'AI reading is not set up on this server (no ANTHROPIC_API_KEY is configured)');
      return;
    }
    const begun = await asUser(userId, tx => tx<{ ctx: Record<string, unknown> | null }[]>`select agent_begin_extraction(${invoice.id}::uuid, ${session}) as ctx`);
    const ctx = begun[0]?.ctx ?? null;
    if (!ctx || ctx.already_processed) return;
    const [upload] = await asUser(userId, tx => tx<{ mime_type: string }[]>`select mime_type from bourne_uploads where id = ${invoice.upload_id}`, true);
    if (!upload || !invoice.upload_id) throw new Error('The uploaded file could not be found');
    const bytes = new Uint8Array(await Bun.file(join(UPLOADS, invoice.upload_id)).arrayBuffer());
    const messages: Message[] = [{ role: 'user', content: [
      documentBlock(bytes, upload.mime_type),
      { type: 'text', text: `Company context (vendors, projects, cost codes, cost types, GL accounts, open commitments, vendor coding history):\n${JSON.stringify(ctx)}\n\nRecord this invoice.` },
    ] }];
    for (let attempt = 1; attempt <= 2; attempt++) {
      const reply = await callModel(ai, { system: EXTRACTION_SYSTEM, messages, tools: [EXTRACTION_TOOL], tool_choice: { type: 'tool', name: 'record_extraction' } });
      const call = reply.content.find(b => b.type === 'tool_use');
      if (!call || call.type !== 'tool_use') throw new Error('The AI did not return an extraction');
      const payload = call.input;
      if (typeof payload.unreadable_reason === 'string' && payload.unreadable_reason) {
        await asUser(userId, tx => tx`select agent_fail_extraction(${invoice.id}::uuid, ${payload.unreadable_reason as string})`);
        return;
      }
      try {
        await asUser(userId, tx => tx`select agent_submit_extraction(${invoice.id}::uuid, ${tx.json(payload as postgres.JSONValue)})`);
        return;
      } catch (error) {
        if (attempt === 2) throw error;
        messages.push({ role: 'assistant', content: reply.content });
        messages.push({ role: 'user', content: [{ type: 'tool_result', tool_use_id: call.id, is_error: true, content: `Saving was refused: ${errorMessage(error)}. Correct the values from the document and call record_extraction again.` }] });
      }
    }
  } catch (error) {
    await recover(userId, invoice.id, session, `AI reading failed: ${errorMessage(error).slice(0, 300).replace(/[.\s]+$/, '')}`);
  } finally {
    runningJobs.delete(session);
  }
}

api.post('/intake/start', async c => {
  const user = await signedIn(c);
  if (!user) return c.json({ error: 'Sign in to process invoices' }, 401);
  const body = await c.req.json<{ invoiceId?: string }>().catch(() => ({} as { invoiceId?: string }));
  if (!body.invoiceId || !uuid.test(body.invoiceId)) return c.json({ error: 'A valid invoice is required' }, 400);
  const session = `local-${randomUUID()}`;
  const invoice = await asUser(user.userId, async tx => {
    const [row] = await tx<InvoiceRow[]>`select id, upload_id, created_by, agent_session_id, extraction_status, updated_at from invoices where id = ${body.invoiceId!}`;
    if (!row) return null;
    if (row.created_by !== user.userId || row.extraction_status !== 'pending' || row.agent_session_id) return { ...row, claimed: false };
    const claimed = await tx`update invoices set agent_session_id = ${session} where id = ${row.id} and agent_session_id is null and extraction_status = 'pending' returning id`;
    return { ...row, claimed: claimed.length > 0 };
  });
  if (!invoice) return c.json({ error: 'Invoice not found' }, 404);
  if (invoice.created_by !== user.userId) return c.json({ error: 'Only the uploader can start this extraction' }, 403);
  if (!invoice.claimed) return c.json({ accepted: false });
  void extract(user.userId, invoice, session);
  return c.json({ accepted: true, sessionId: session });
});

api.post('/intake/reconcile', async c => {
  const user = await signedIn(c);
  if (!user) return c.json({ error: 'Sign in to check extractions' }, 401);
  const body = await c.req.json<{ orgId?: string }>().catch(() => ({} as { orgId?: string }));
  if (!body.orgId || !uuid.test(body.orgId)) return c.json({ error: 'A valid company is required' }, 400);
  const rows = await asUser(user.userId, tx => tx<InvoiceRow[]>`select id, agent_session_id, updated_at from invoices
    where org_id = ${body.orgId!} and created_by = ${user.userId} and extraction_status in ('pending', 'running') and agent_session_id is not null
    order by updated_at limit 20`, true);
  let recovered = 0;
  for (const row of rows) {
    const session = row.agent_session_id!;
    const stale = Date.now() - Date.parse(row.updated_at) > 180_000;
    if (runningJobs.has(session) || (session === 'dispatching' && !stale)) continue;
    const applied = await asUser(user.userId, tx => tx<{ ok: boolean }[]>`select recover_extraction(${row.id}::uuid, ${session}, ${'The AI run was interrupted, for example by a server restart'}) as ok`);
    if (applied[0]?.ok) recovered++;
  }
  return c.json({ recovered });
});

// ---- assistant

const assistantInstructions = (() => {
  const path = join(ROOT, 'agents', 'finops-assistant', 'agent', 'instructions.md');
  const base = existsSync(path) ? readFileSync(path, 'utf8') : 'You answer questions about the company\'s accounts-payable records with read-only SQL.';
  return base + ASSISTANT_NOTE;
})();

api.post('/assistant', async c => {
  const user = await signedIn(c);
  if (!user) return c.json({ error: 'Sign in first' }, 401);
  if (!ai) return c.json({ error: 'The assistant needs an AI key. Ask the administrator to set ANTHROPIC_API_KEY on the server.' }, 503);
  const body = await c.req.json<{ messages?: { role: 'user' | 'assistant'; content: string }[] }>().catch(() => null);
  const history = (body?.messages ?? []).filter(m => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string').slice(-20);
  if (!history.length || history[history.length - 1]!.role !== 'user') return c.json({ error: 'Send a question' }, 400);
  const messages: Message[] = history.map(m => ({ role: m.role, content: m.content }));
  try {
    for (let step = 0; step < 10; step++) {
      const reply = await callModel(ai, { system: assistantInstructions, messages, tools: [SQL_TOOL], max_tokens: 4000 });
      const calls = reply.content.filter(b => b.type === 'tool_use');
      if (!calls.length) {
        return c.json({ reply: reply.content.filter(b => b.type === 'text').map(b => (b as { text: string }).text).join('\n').trim() || 'I could not produce an answer.' });
      }
      messages.push({ role: 'assistant', content: reply.content });
      const results = [];
      for (const call of calls) {
        if (call.type !== 'tool_use') continue;
        let content: string;
        let isError = false;
        try {
          const rows = await asUser(user.userId, tx => tx.unsafe(String(call.input.sql ?? '')), true);
          content = JSON.stringify(rows.slice(0, 200)).slice(0, 20_000);
        } catch (error) {
          content = errorMessage(error);
          isError = true;
        }
        results.push({ type: 'tool_result' as const, tool_use_id: call.id, content, is_error: isError });
      }
      messages.push({ role: 'user', content: results });
    }
    return c.json({ reply: 'That question needed more lookups than allowed. Try a narrower question.' });
  } catch (error) {
    return c.json({ error: errorMessage(error) }, 502);
  }
});

api.onError((error, c) => c.json({ error: errorMessage(error) }, 500));

// ------------------------------------------------------------------ live updates

type Socket = import('bun').ServerWebSocket<unknown>;
const sockets = new Set<Socket>();
const pending = new Set<string>();
let flushTimer: ReturnType<typeof setTimeout> | null = null;
const broadcast = (message: object) => { const text = JSON.stringify(message); for (const s of sockets) s.send(text); };
await sql.listen('bourne_changes', payload => {
  try {
    const table = (JSON.parse(payload) as { t?: unknown }).t;
    if (typeof table === 'string') pending.add(table);
  } catch { return; }
  flushTimer ??= setTimeout(() => { flushTimer = null; const tables = [...pending]; pending.clear(); if (tables.length) broadcast({ type: 'changes', tables }); }, 20);
});
setInterval(() => broadcast({ type: 'ping' }), 25_000);

// ------------------------------------------------------------------ static app

const indexHtml = () => Bun.file(join(DIST_DIR, 'index.html'));
function serveStatic(pathname: string): Response {
  const path = normalize(join(DIST_DIR, decodeURIComponent(pathname)));
  if (path.startsWith(DIST_DIR) && pathname !== '/' && existsSync(path) && Bun.file(path).size > 0) {
    const cache = pathname.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache';
    return new Response(Bun.file(path), { headers: { 'cache-control': cache } });
  }
  return new Response(indexHtml(), { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache' } });
}

// ------------------------------------------------------------------ start

const applied = await migrate(sql, ROOT, AUTHENTICATOR_PASSWORD);
console.log(applied.length ? `Applied ${applied.length} migration(s): ${applied.join(', ')}` : 'Database schema is up to date');
if (!existsSync(join(DIST_DIR, 'index.html'))) console.warn(`No built app at ${DIST_DIR}. Run: bun run selfhost:build`);
if (!ai) console.warn('ANTHROPIC_API_KEY is not set: invoices can be uploaded and entered by hand, but AI reading and the assistant are off.');

Bun.serve({
  port: PORT,
  idleTimeout: 120,
  async fetch(request, server) {
    const url = new URL(request.url);
    if (url.pathname === '/api/live') {
      const token = url.searchParams.get('token') ?? '';
      const user = await appUser(env, new Request(request.url, { headers: { Authorization: `Bearer ${token}` } }));
      if (!user) return new Response('Sign in first', { status: 401 });
      return server.upgrade(request) ? undefined : new Response('Expected a WebSocket', { status: 426 });
    }
    if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
      const inner = new URL(request.url);
      inner.pathname = url.pathname.slice(4) || '/';
      return api.fetch(new Request(inner, request), env);
    }
    return serveStatic(url.pathname);
  },
  websocket: {
    open(ws) { sockets.add(ws); ws.send(JSON.stringify({ type: 'ready' })); },
    close(ws) { sockets.delete(ws); },
    message() { /* the app only listens */ },
  },
});
console.log(`Trestle is running at http://localhost:${PORT}`);
