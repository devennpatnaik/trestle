-- Self-hosted Trestle: what the hosted platform provides before the app's own migrations run.
-- Safe to run more than once. Applied by migrate.ts (and by the Postgres container on first start).

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN CREATE ROLE authenticated NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anonymous') THEN CREATE ROLE anonymous NOLOGIN; END IF;
  -- PostgREST logs in as authenticator and switches to the role named in each request's token.
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticator') THEN CREATE ROLE authenticator LOGIN NOINHERIT; END IF;
END
$$;
GRANT authenticated TO authenticator;
GRANT anonymous TO authenticator;

-- Identity of the signed-in user, read from the claims PostgREST (or the server) sets for each request.
CREATE SCHEMA IF NOT EXISTS auth;
CREATE OR REPLACE FUNCTION auth.session() RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb)
$$;
CREATE OR REPLACE FUNCTION auth.user_id() RETURNS text LANGUAGE sql STABLE AS $$
  SELECT auth.session() ->> 'sub'
$$;
GRANT USAGE ON SCHEMA auth TO authenticated, anonymous;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA auth TO authenticated, anonymous;

-- Accounts. The app reads email and verification from neon_auth."user", as it does on the hosted platform.
CREATE SCHEMA IF NOT EXISTS neon_auth;
CREATE TABLE IF NOT EXISTS neon_auth."user" (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  name text NOT NULL,
  "emailVerified" boolean NOT NULL DEFAULT true,
  "createdAt" timestamptz NOT NULL DEFAULT now()
);
REVOKE ALL ON SCHEMA neon_auth FROM PUBLIC;

-- Server-only bookkeeping: password hashes and applied migrations. No app role can read it.
CREATE SCHEMA IF NOT EXISTS trestle_local;
REVOKE ALL ON SCHEMA trestle_local FROM PUBLIC;
CREATE TABLE IF NOT EXISTS trestle_local.credentials (
  user_id uuid PRIMARY KEY REFERENCES neon_auth."user"(id) ON DELETE CASCADE,
  password_hash text NOT NULL
);
CREATE TABLE IF NOT EXISTS trestle_local.migrations (
  name text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);

-- Live updates: every public table notifies which table changed (never row contents).
CREATE SCHEMA IF NOT EXISTS bourne_runtime;
CREATE OR REPLACE FUNCTION bourne_runtime.emit_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  PERFORM pg_notify('bourne_changes', json_build_object('t', TG_TABLE_NAME)::text);
  RETURN NULL;
END
$$;
GRANT USAGE ON SCHEMA bourne_runtime TO authenticated;
