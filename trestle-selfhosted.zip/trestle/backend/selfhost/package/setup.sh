#!/bin/sh
# Trestle setup. Asks for the few things Trestle needs, writes them to .env, and can start Trestle for you.
# Run it again any time to add or change your Anthropic API key. Your data and passwords are kept.
set -e
cd "$(dirname "$0")"

say() { printf '%s\n' "$*"; }
ask() { printf '%s' "$1" > /dev/tty; IFS= read -r REPLY < /dev/tty || REPLY=""; }
ask_secret() { printf '%s' "$1" > /dev/tty; stty -echo < /dev/tty 2>/dev/null || true; IFS= read -r REPLY < /dev/tty || REPLY=""; stty echo < /dev/tty 2>/dev/null || true; printf '\n' > /dev/tty; }
rand() { openssl rand -hex 24 2>/dev/null || head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n'; }
# set_var NAME VALUE: replace the NAME= line in .env.
set_var() { awk -v k="$1" -v v="$2" 'BEGIN{FS=OFS="="} $1==k{print k"="v; next} {print}' .env > .env.tmp && mv .env.tmp .env; }
get_var() { sed -n "s/^$1=//p" .env | head -n 1; }
INTERACTIVE=1
if ! (: < /dev/tty) 2>/dev/null; then INTERACTIVE=0; fi

say ""
say "Trestle setup"
say "============="
say ""

# Step 1. Docker.
say "Step 1 of 4: Docker"
if ! command -v docker >/dev/null 2>&1; then
  say "  Docker is not installed. Install Docker Desktop from https://www.docker.com/products/docker-desktop/ ,"
  say "  start it, then run ./setup.sh again."
  exit 1
fi
if docker info >/dev/null 2>&1; then say "  OK: Docker is installed and running."
else say "  Docker is installed but not running. Start Docker Desktop before the last step."; fi
say ""

# Step 2. Passwords.
say "Step 2 of 4: Passwords for the database and sign-in"
if [ -f .env ]; then
  say "  OK: .env already exists, so your existing passwords are kept."
else
  sed -e "s/^POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$(rand)/" \
      -e "s/^AUTHENTICATOR_PASSWORD=.*/AUTHENTICATOR_PASSWORD=$(rand)/" \
      -e "s/^JWT_SECRET=.*/JWT_SECRET=$(rand)$(rand)/" .env.example > .env
  say "  OK: created .env with new random passwords. You never need to type these."
fi
say ""

# Step 3. Anthropic API key.
say "Step 3 of 4: Anthropic API key (optional, but needed for AI)"
say "  With a key, Trestle reads uploaded bills for you and the assistant can answer questions."
say "  Without a key, everything else works, and you type each bill's details in by hand."
say "  Get a key at https://console.anthropic.com/settings/keys (it starts with sk-ant-)."
CURRENT=$(get_var ANTHROPIC_API_KEY)
KEY="$CURRENT"
if [ -n "${ANTHROPIC_API_KEY:-}" ]; then
  KEY="$ANTHROPIC_API_KEY"; say "  Using the key from the ANTHROPIC_API_KEY environment variable."
elif [ "$INTERACTIVE" = 1 ]; then
  while :; do
    if [ -n "$CURRENT" ]; then ask_secret "  A key is already saved. Paste a new key, or press Enter to keep it: "
    else ask_secret "  Paste your key (the text stays hidden), or press Enter to skip: "; fi
    [ -z "$REPLY" ] && break
    if command -v curl >/dev/null 2>&1; then
      CODE=$(curl -s -o /dev/null -w '%{http_code}' https://api.anthropic.com/v1/models -H "x-api-key: $REPLY" -H "anthropic-version: 2023-06-01" || echo 000)
      if [ "$CODE" = 200 ]; then KEY="$REPLY"; say "  OK: Anthropic accepted the key."; break
      elif [ "$CODE" = 401 ] || [ "$CODE" = 403 ]; then say "  Anthropic rejected that key. Check it and try again, or press Enter to skip."; continue
      else KEY="$REPLY"; say "  Could not reach Anthropic to check the key (code $CODE). Saving it anyway."; break; fi
    else KEY="$REPLY"; break; fi
  done
fi
set_var ANTHROPIC_API_KEY "$KEY"
if [ -n "$KEY" ]; then say "  AI is ON."; else say "  AI is OFF. Run ./setup.sh again any time to add a key."; fi
say ""

# Step 4. Start.
PORT=$(get_var PORT); PORT=${PORT:-8080}
say "Step 4 of 4: Start Trestle"
START=n
if [ "$INTERACTIVE" = 1 ]; then ask "  Start Trestle now? The first start takes a few minutes. [Y/n] "; case "$REPLY" in n|N|no|No) START=n ;; *) START=y ;; esac; fi
if [ "$START" = y ]; then
  docker compose up --build -d
  printf '  Waiting for Trestle to be ready'
  i=0; until curl -fs "http://localhost:$PORT/api/health" >/dev/null 2>&1; do i=$((i+1)); [ $i -gt 120 ] && break; printf '.'; sleep 2; done; say ""
  if curl -fs "http://localhost:$PORT/api/health" >/dev/null 2>&1; then
    say ""; say "Trestle is running. Open http://localhost:$PORT"
    say "Create an account, then choose \"Create demo workspace\" to try it with sample bills."
  else
    say "  Trestle did not answer yet. See what it is doing with: docker compose logs -f app"
  fi
else
  say "  When you are ready, run: docker compose up --build"
  say "  Then open http://localhost:$PORT"
fi
if [ -n "$CURRENT" ] && [ "$KEY" != "$CURRENT" ] && [ "$START" != y ]; then
  say "  You changed the API key. If Trestle is already running, apply it with: docker compose up -d"
fi
