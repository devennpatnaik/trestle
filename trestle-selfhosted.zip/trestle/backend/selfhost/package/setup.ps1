# Trestle setup for Windows. Right-click > Run with PowerShell, or run: powershell -ExecutionPolicy Bypass -File setup.ps1
# Run it again any time to add or change your Anthropic API key. Your data and passwords are kept.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Rand { -join ((1..48) | ForEach-Object { '{0:x}' -f (Get-Random -Maximum 16) }) }
function Get-Var($name) { $line = Get-Content .env | Where-Object { $_ -like "$name=*" } | Select-Object -First 1; if ($line) { $line.Substring($name.Length + 1) } else { '' } }
function Set-Var($name, $value) { (Get-Content .env) | ForEach-Object { if ($_ -like "$name=*") { "$name=$value" } else { $_ } } | Set-Content .env -Encoding ascii }

Write-Host "`nTrestle setup`n=============`n"
Write-Host "Step 1 of 4: Docker"
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Write-Host "  Docker is not installed. Install Docker Desktop from https://www.docker.com/products/docker-desktop/ , start it, then run this again."; exit 1 }
docker info *> $null; if ($LASTEXITCODE -eq 0) { Write-Host "  OK: Docker is installed and running.`n" } else { Write-Host "  Docker is installed but not running. Start Docker Desktop before the last step.`n" }

Write-Host "Step 2 of 4: Passwords for the database and sign-in"
if (Test-Path .env) { Write-Host "  OK: .env already exists, so your existing passwords are kept.`n" }
else {
  (Get-Content .env.example) | ForEach-Object {
    if ($_ -like 'POSTGRES_PASSWORD=*') { "POSTGRES_PASSWORD=$(Rand)" }
    elseif ($_ -like 'AUTHENTICATOR_PASSWORD=*') { "AUTHENTICATOR_PASSWORD=$(Rand)" }
    elseif ($_ -like 'JWT_SECRET=*') { "JWT_SECRET=$(Rand)$(Rand)" } else { $_ }
  } | Set-Content .env -Encoding ascii
  Write-Host "  OK: created .env with new random passwords. You never need to type these.`n"
}

Write-Host "Step 3 of 4: Anthropic API key (optional, but needed for AI)"
Write-Host "  With a key, Trestle reads uploaded bills for you and the assistant can answer questions."
Write-Host "  Without a key, everything else works, and you type each bill's details in by hand."
Write-Host "  Get a key at https://console.anthropic.com/settings/keys (it starts with sk-ant-)."
$current = Get-Var 'ANTHROPIC_API_KEY'; $key = $current
while ($true) {
  $prompt = if ($current) { '  A key is already saved. Paste a new key, or press Enter to keep it' } else { '  Paste your key (the text stays hidden), or press Enter to skip' }
  $secure = Read-Host -Prompt $prompt -AsSecureString
  $entered = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
  if (-not $entered) { break }
  try {
    Invoke-WebRequest -UseBasicParsing -Uri https://api.anthropic.com/v1/models -Headers @{ 'x-api-key' = $entered; 'anthropic-version' = '2023-06-01' } | Out-Null
    $key = $entered; Write-Host '  OK: Anthropic accepted the key.'; break
  } catch {
    $code = $_.Exception.Response.StatusCode.value__
    if ($code -eq 401 -or $code -eq 403) { Write-Host '  Anthropic rejected that key. Check it and try again, or press Enter to skip.' }
    else { $key = $entered; Write-Host "  Could not reach Anthropic to check the key. Saving it anyway."; break }
  }
}
Set-Var 'ANTHROPIC_API_KEY' $key
if ($key) { Write-Host "  AI is ON.`n" } else { Write-Host "  AI is OFF. Run setup again any time to add a key.`n" }

$port = Get-Var 'PORT'; if (-not $port) { $port = '8080' }
Write-Host "Step 4 of 4: Start Trestle"
$answer = Read-Host '  Start Trestle now? The first start takes a few minutes. [Y/n]'
if ($answer -notmatch '^(n|no)$') {
  docker compose up --build -d
  Write-Host -NoNewline '  Waiting for Trestle to be ready'
  $ok = $false
  for ($i = 0; $i -lt 120; $i++) { try { Invoke-WebRequest -UseBasicParsing "http://localhost:$port/api/health" | Out-Null; $ok = $true; break } catch { Write-Host -NoNewline '.'; Start-Sleep 2 } }
  Write-Host ''
  if ($ok) { Write-Host "`nTrestle is running. Open http://localhost:$port"; Write-Host 'Create an account, then choose "Create demo workspace" to try it with sample bills.' }
  else { Write-Host '  Trestle did not answer yet. See what it is doing with: docker compose logs -f app' }
} else { Write-Host "  When you are ready, run: docker compose up --build`n  Then open http://localhost:$port" }
