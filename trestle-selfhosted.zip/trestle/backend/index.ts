import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { bourneRoutes } from './lib/bourne';
import type { Env } from './lib/env';
import { liveSocket } from './lib/live';
import { intakeRoutes } from './routes/intake';
import { dataRoutes } from './routes/data';
import { dataApiRoutes } from './routes/data-api';
import { actionRoutes } from './lib/actions';
import { authRoutes } from './routes/auth';

const app = new Hono<{ Bindings: Env }>();
app.use('/data/*', cors({ origin: origin => origin, allowMethods: ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'], exposeHeaders: ['Content-Range', 'Preference-Applied', 'Location'], maxAge: 600 }));
app.use('/bourne/*', cors({ origin: origin => origin, allowHeaders: ['Authorization', 'Content-Type', 'Accept', 'Last-Event-ID'], allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'], maxAge: 600 }));
app.use('/intake/*', cors({ origin: origin => origin, allowMethods: ['POST', 'OPTIONS'], allowHeaders: ['Authorization', 'Content-Type'] }));
app.route('/intake', intakeRoutes);
app.get('/health', c => c.text('ok'));
app.route('/api/auth', authRoutes);
app.get('/live', c => liveSocket(c.env, c.req.raw));
app.route('/data/api', dataApiRoutes);
app.route('/data', dataRoutes);
app.use('/actions/*', cors({ origin: origin => origin }));
app.route('/actions', actionRoutes);
app.route('/bourne', bourneRoutes);

export { Live } from './lib/live';
export default app;
