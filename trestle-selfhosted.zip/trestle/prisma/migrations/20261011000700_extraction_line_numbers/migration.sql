-- Reject malformed numeric values instead of silently losing extracted line data.
CREATE OR REPLACE FUNCTION public.agent_submit_extraction(p_invoice uuid, p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  inv invoices;
  conf jsonb := '{}';
  k text;
  l jsonb;
  n int := 0;
  a jsonb;
  checks jsonb;
  v_vendor uuid;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN RETURN jsonb_build_object('already_processed', true); END IF;
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  PERFORM _require(jsonb_typeof(p) = 'object', 'Payload must be a JSON object');
  PERFORM set_config('app.actor_kind', 'agent', true);

  FOR k IN SELECT key FROM jsonb_each(coalesce(p -> 'confidence', '{}')) LOOP
    IF jsonb_typeof(p -> 'confidence' -> k) = 'number' THEN
      conf := conf || jsonb_build_object(CASE k WHEN 'vendor_name' THEN 'vendor' ELSE k END,
        greatest(0, least(1, (p -> 'confidence' ->> k)::numeric)));
    END IF;
  END LOOP;
  v_vendor := _uuid_in_org('vendors', inv.org_id, p ->> 'vendor_id');

  -- Fill only what a person has not already entered; never overwrite their work.
  UPDATE invoices SET
    vendor_name_extracted = coalesce(vendor_name_extracted, nullif(trim(p ->> 'vendor_name'), '')),
    vendor_id = coalesce(vendor_id, v_vendor),
    invoice_number = coalesce(invoice_number, nullif(trim(p ->> 'invoice_number'), '')),
    invoice_date = coalesce(invoice_date, _date(p ->> 'invoice_date')),
    due_date = coalesce(due_date, _date(p ->> 'due_date')),
    payment_terms = coalesce(payment_terms, nullif(trim(p ->> 'payment_terms'), '')),
    currency = coalesce(nullif(upper(trim(p ->> 'currency')), ''), currency),
    subtotal = coalesce(subtotal, _num(p ->> 'subtotal')),
    tax_amount = coalesce(tax_amount, _num(p ->> 'tax_amount')),
    retainage_amount = coalesce(retainage_amount, _num(p ->> 'retainage_amount')),
    total_amount = coalesce(total_amount, _num(p ->> 'total_amount')),
    po_number = coalesce(po_number, nullif(trim(p ->> 'po_number'), '')),
    project_reference = coalesce(project_reference, nullif(trim(p ->> 'project_reference'), '')),
    description = coalesce(description, nullif(trim(p ->> 'description'), '')),
    field_confidence = conf || field_confidence,
    ai_extraction = p,
    ai_summary = nullif(trim(p ->> 'summary'), ''),
    extraction_status = 'succeeded',
    extraction_error = NULL
  WHERE id = inv.id;

  IF NOT EXISTS (SELECT 1 FROM invoice_lines WHERE invoice_id = inv.id) THEN
    FOR l IN SELECT * FROM jsonb_array_elements(CASE WHEN jsonb_typeof(p -> 'lines') = 'array' THEN p -> 'lines' ELSE '[]' END) LOOP
      n := n + 1;
      PERFORM _require(coalesce(l->>'quantity', '') = '' OR _num(l->>'quantity') IS NOT NULL, 'Line quantity must be a plain number; keep units in description');
      PERFORM _require(coalesce(l->>'unit_price', '') = '' OR _num(l->>'unit_price') IS NOT NULL, 'Line unit price must be a plain number');
      PERFORM _require(coalesce(l->>'amount', '') = '' OR _num(l->>'amount') IS NOT NULL, 'Line amount must be a plain number');
      INSERT INTO invoice_lines (org_id, invoice_id, line_no, description, quantity, unit_price, amount)
      VALUES (inv.org_id, inv.id, n, left(l ->> 'description', 1000), _num(l ->> 'quantity'), _num(l ->> 'unit_price'), _num(l ->> 'amount'));
    END LOOP;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM invoice_allocations WHERE invoice_id = inv.id) THEN
    FOR a IN SELECT * FROM jsonb_array_elements(CASE WHEN jsonb_typeof(p -> 'allocations') = 'array' THEN p -> 'allocations' ELSE '[]' END) LOOP
      IF _num(a ->> 'amount') IS NOT NULL THEN
        INSERT INTO invoice_allocations (org_id, invoice_id, project_id, cost_code_id, cost_type_id, gl_account_id, amount, description, source, confidence, rationale)
        VALUES (inv.org_id, inv.id,
          _uuid_in_org('projects', inv.org_id, a ->> 'project_id'), _uuid_in_org('cost_codes', inv.org_id, a ->> 'cost_code_id'),
          _uuid_in_org('cost_types', inv.org_id, a ->> 'cost_type_id'), _uuid_in_org('gl_accounts', inv.org_id, a ->> 'gl_account_id'),
          _num(a ->> 'amount'), left(a ->> 'description', 500), 'ai',
          CASE WHEN jsonb_typeof(a -> 'confidence') = 'number' THEN greatest(0, least(1, (a ->> 'confidence')::numeric)) END,
          left(a ->> 'rationale', 2000));
      END IF;
    END LOOP;
  END IF;

  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'ai_extracted', 'AI extracted invoice fields and proposed coding',
    jsonb_build_object('confidence', conf));
  checks := _invoice_checks(inv.id, true);
  UPDATE agent_runs SET status = 'succeeded', finished_at = now(),
    summary = format('Extracted %s %s for %s; %s blocking, %s warnings left for review',
      coalesce(p ->> 'vendor_name', 'unknown vendor'), coalesce(p ->> 'invoice_number', '(no number)'), coalesce(p ->> 'total_amount', '?'),
      checks ->> 'blocking', checks ->> 'warnings'),
    output = jsonb_build_object('extraction', p, 'checks', checks)
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
  RETURN checks;
END $function$;
