-- Approved reads through the user's Data API identity, never an owner connection.
CREATE OR REPLACE FUNCTION public.trestle_read(p_key text, p_params jsonb DEFAULT '[]') RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path = public AS $fn$
DECLARE template text; result jsonb;
BEGIN
  IF app_uid() IS NULL THEN RAISE EXCEPTION 'Sign in first' USING ERRCODE = '42501'; END IF;
  IF jsonb_typeof(p_params) <> 'array' OR jsonb_array_length(p_params) > 4 THEN
    RAISE EXCEPTION 'Invalid query parameters';
  END IF;
  template := CASE p_key
WHEN 'q0' THEN $query$select m.org_id, m.role, m.approval_limit, o.name, o.is_demo
       from org_members m join orgs o on o.id = m.org_id
      where m.user_id = %1$L and m.active order by o.is_demo, o.name$query$
WHEN 'q1' THEN $query$select i.id, i.upload_id, i.file_name, u.size_bytes, u.mime_type from invoices i left join bourne_uploads u on u.id = i.upload_id
      where i.org_id = %1$L and i.created_by = %2$L and i.extraction_status = 'pending' and i.status = 'needs_review'
        and i.upload_id is not null and i.agent_session_id is null order by i.created_at limit 20$query$
WHEN 'q2' THEN $query$
select
  (select row_to_json(o) from (select id, name, legal_entity, is_demo from orgs where id = %1$L) o) as org,
  (select row_to_json(s) from org_settings s where s.org_id = %1$L) as settings,
  (select coalesce(json_agg(v order by v.name), '[]') from (select id, code, name, status, tax_id, email, phone, address, payment_terms, default_gl_account_id, default_cost_type_id, external_id from vendors where org_id = %1$L) v) as vendors,
  (select coalesce(json_agg(p order by p.code), '[]') from (select id, code, name, status, project_manager_user_id, legal_entity, address, external_id from projects where org_id = %1$L) p) as projects,
  (select coalesce(json_agg(c order by c.code), '[]') from (select id, code, name, project_id, budget_amount from cost_codes where org_id = %1$L) c) as cost_codes,
  (select coalesce(json_agg(t order by t.code), '[]') from (select id, code, name from cost_types where org_id = %1$L) t) as cost_types,
  (select coalesce(json_agg(g order by g.code), '[]') from (select id, code, name, account_type, active from gl_accounts where org_id = %1$L) g) as gl_accounts,
  (select coalesce(json_agg(m order by m.email), '[]') from (select user_id, email, display_name, role, approval_limit, active from org_members where org_id = %1$L) m) as members,
  (select coalesce(json_agg(c order by c.number), '[]') from (select id, kind, number, vendor_id, project_id, description, status, original_amount, retainage_pct, external_id from commitments where org_id = %1$L) c) as commitments
$query$
WHEN 'q3' THEN $query$
    select r.*, i.invoice_number from agent_runs r left join invoices i on i.id = r.invoice_id
    where r.org_id = %1$L and (%2$L = 'all' or r.agent = %2$L) order by r.started_at desc limit 300$query$
WHEN 'q4' THEN $query$
    select e.*, i.invoice_number from audit_events e left join invoices i on i.id = e.invoice_id
    where e.org_id = %1$L and (%2$L = 'all' or e.actor_kind = %2$L) order by e.created_at desc, e.id desc limit 1000$query$
WHEN 'q5' THEN $query$
select s.id step_id, i.id invoice_id, i.invoice_number, coalesce(v.name, i.vendor_name_extracted) vendor, i.total_amount, i.currency,
  s.step_order, s.approver_user_id, s.approver_role, s.reason, i.submitted_at, i.submitted_by,
  (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) projects,
  (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status in ('open', 'acknowledged') and x.severity = 'warning') warnings,
  (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'overridden') overridden,
  s.step_order = (select min(step_order) from approval_steps o where o.invoice_id = i.id and o.round = i.approval_round and o.status = 'pending') is_next
from approval_steps s join invoices i on i.id = s.invoice_id left join vendors v on v.id = i.vendor_id
where s.org_id = %1$L and s.status = 'pending' and i.status = 'pending_approval' and s.round = i.approval_round
order by i.submitted_at limit 500$query$
WHEN 'q6' THEN $query$
select b.*, (select count(*)::int from sync_records r where r.batch_id = b.id and r.status = 'synced') synced,
  (select count(*)::int from sync_records r where r.batch_id = b.id and r.status = 'failed') failed,
  (select count(*)::int from sync_records r where r.batch_id = b.id and r.status = 'exported') exported
from export_batches b where b.org_id = %1$L order by b.batch_number desc limit 200$query$
WHEN 'q7' THEN $query$select count(*) filter (where sync_status = 'ready')::int n, coalesce(sum(total_amount) filter (where sync_status = 'ready'), 0) amount,
  count(*) filter (where sync_status = 'failed')::int failed, coalesce(sum(total_amount) filter (where sync_status = 'failed'), 0) failed_amount
from invoices where org_id = %1$L and status = 'approved'$query$
WHEN 'q8' THEN $query$select r.id, r.invoice_id, r.idempotency_key, r.attempt, r.status, r.external_id, r.error, r.payload ->> 'invoice_number' invoice_number, r.payload ->> 'vendor_name' vendor, r.payload ->> 'total_amount' total,
       exists (select 1 from sync_records o where o.invoice_id = r.invoice_id and o.attempt > r.attempt) newer
     from sync_records r where r.batch_id = %1$L order by r.idempotency_key$query$
WHEN 'q9' THEN $query$
select row_to_json(i) as invoice,
  (select coalesce(json_agg(a order by a.created_at, a.id), '[]') from invoice_allocations a where a.invoice_id = i.id) as allocations,
  (select coalesce(json_agg(l order by l.line_no), '[]') from invoice_lines l where l.invoice_id = i.id) as lines,
  (select coalesce(json_agg(x order by case x.status when 'open' then 0 else 1 end, case x.severity when 'blocking' then 0 when 'warning' then 1 else 2 end, x.created_at), '[]')
     from invoice_exceptions x where x.invoice_id = i.id) as exceptions,
  (select coalesce(json_agg(s order by s.round desc, s.step_order, s.created_at), '[]') from approval_steps s where s.invoice_id = i.id) as steps,
  (select coalesce(json_agg(e order by e.created_at desc, e.id desc), '[]') from (select * from audit_events where invoice_id = i.id order by created_at desc, id desc limit 300) e) as audit,
  (select coalesce(json_agg(r order by r.attempt desc), '[]') from (select r.id, r.attempt, r.status, r.external_id, r.error, r.idempotency_key, r.created_at, r.updated_at, b.batch_number
     from sync_records r join export_batches b on b.id = r.batch_id where r.invoice_id = i.id) r) as sync,
  (select json_build_object('id', c.id, 'number', c.number, 'kind', c.kind, 'status', c.status, 'original', c.original_amount, 'retainage_pct', c.retainage_pct,
      'description', c.description, 'vendor_id', c.vendor_id, 'project_id', c.project_id,
      'approved_cos', (select coalesce(sum(amount), 0) from change_orders where commitment_id = c.id and status = 'approved'),
      'pending_cos', (select coalesce(sum(amount), 0) from change_orders where commitment_id = c.id and status = 'pending'),
      'billed_other', (select coalesce(sum(total_amount), 0) from invoices o where o.commitment_id = c.id and o.id <> i.id and o.status in ('pending_approval', 'approved')),
      'lines', (select coalesce(json_agg(cl order by cl.line_no), '[]') from commitment_lines cl where cl.commitment_id = c.id))
     from commitments c where c.id = i.commitment_id) as commitment
from invoices i where i.id = %1$L and i.org_id = %2$L$query$
WHEN 'q10' THEN $query$
with i as (select * from invoices where org_id = %1$L),
openx as (select x.invoice_id, x.code, x.severity from invoice_exceptions x join i on i.id = x.invoice_id where x.status = 'open' and i.status = 'needs_review')
select
  (select count(*)::int from i where status = 'needs_review') in_review,
  (select count(distinct invoice_id)::int from openx where severity = 'blocking') blocked,
  (select count(distinct invoice_id)::int from openx where code = 'low_confidence') flagged,
  (select count(distinct invoice_id)::int from openx where code in ('duplicate', 'possible_duplicate')) duplicates,
  (select count(*)::int from i where status = 'needs_review' and extraction_status in ('pending', 'running')) extracting,
  (select count(*)::int from i where status = 'needs_review' and extraction_status = 'failed') extraction_failed,
  (select count(*)::int from i where status = 'pending_approval') awaiting_approval,
  (select coalesce(sum(total_amount), 0) from i where status = 'pending_approval') awaiting_amount,
  (select round(extract(epoch from now() - min(submitted_at)) / 3600)::int from i where status = 'pending_approval') oldest_awaiting_hours,
  (select count(*)::int from i where status = 'approved' and sync_status in ('ready')) ready_count,
  (select coalesce(sum(total_amount), 0) from i where status = 'approved' and sync_status = 'ready') ready_amount,
  (select count(*)::int from i where sync_status = 'exported') exported_count,
  (select count(*)::int from i where sync_status = 'failed') sync_failed,
  (select count(*)::int from i where created_at > now() - interval '30 days') received_30d,
  (select count(*)::int from i where approved_at > now() - interval '30 days') approved_30d,
  (select coalesce(sum(total_amount), 0) from i where approved_at > now() - interval '30 days') approved_amount_30d,
  (select round((percentile_cont(0.5) within group (order by extract(epoch from approved_at - created_at)) / 3600)::numeric, 1)::float from i where approved_at > now() - interval '30 days') median_hours_to_approve,
  (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(field_confidence, '{}')))), 0)::int from i where extraction_status = 'succeeded' and created_at > now() - interval '30 days') fields_extracted_30d,
  (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(details -> 'changes', '{}')))), 0)::int from audit_events where org_id = %1$L and action = 'field_corrected' and created_at > now() - interval '30 days') fields_corrected_30d$query$
WHEN 'q11' THEN $query$
    select c.*, (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'approved') approved_cos,
      (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'pending') pending_cos,
      (select coalesce(sum(total_amount), 0) from invoices i where i.commitment_id = c.id and i.status in ('pending_approval', 'approved')) billed,
      (select coalesce(json_agg(l order by l.line_no), '[]') from commitment_lines l where l.commitment_id = c.id) lines
    from commitments c where c.org_id = %1$L order by c.number limit 2000$query$
WHEN 'q12' THEN $query$select id, commitment_id, number, description, amount, status, approved_date from change_orders where org_id = %1$L order by created_at desc limit 1000$query$
WHEN 'q13' THEN $query$
    select i.invoice_number, coalesce(v.code, '') vendor_code, coalesce(v.name, i.vendor_name_extracted) vendor, i.invoice_date, i.due_date, i.total_amount, i.retainage_amount, i.currency,
      c.number commitment, i.status, i.sync_status, i.created_at::date received, i.approved_at::date approved,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) jobs, i.id invoice_id
    from invoices i left join vendors v on v.id = i.vendor_id left join commitments c on c.id = i.commitment_id
    where i.org_id = %1$L and i.created_at >= %2$L::date and i.created_at < %3$L::date + 1 and (%4$L = 'all' or i.status = %4$L)
    order by i.created_at desc limit 5000$query$
WHEN 'q14' THEN $query$
    select p.code job, p.name job_name, cc.code cost_code, cc.name cost_code_name, ct.code cost_type, sum(a.amount) amount, count(distinct i.id)::int invoices, max(cc.budget_amount) budget
    from invoice_allocations a join invoices i on i.id = a.invoice_id
      left join projects p on p.id = a.project_id left join cost_codes cc on cc.id = a.cost_code_id left join cost_types ct on ct.id = a.cost_type_id
    where i.org_id = %1$L and i.created_at >= %2$L::date and i.created_at < %3$L::date + 1
      and (case when %4$L = 'approved' then i.status = 'approved' else i.status in ('needs_review', 'pending_approval', 'approved') end)
    group by p.code, p.name, cc.code, cc.name, ct.code order by p.code nulls last, cc.code nulls last, ct.code limit 5000$query$
WHEN 'q15' THEN $query$
    select c.number, c.kind, v.name vendor, p.code job, c.status, c.original_amount original,
      (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'approved') approved_cos,
      (select coalesce(sum(amount), 0) from change_orders o where o.commitment_id = c.id and o.status = 'pending') pending_cos,
      (select coalesce(sum(total_amount), 0) from invoices i where i.commitment_id = c.id and i.status = 'approved') billed_approved,
      (select coalesce(sum(total_amount), 0) from invoices i where i.commitment_id = c.id and i.status = 'pending_approval') billed_pending,
      (select coalesce(sum(retainage_amount), 0) from invoices i where i.commitment_id = c.id and i.status = 'approved') retainage_held
    from commitments c join vendors v on v.id = c.vendor_id join projects p on p.id = c.project_id
    where c.org_id = %1$L order by p.code, c.number limit 5000$query$
WHEN 'q16' THEN $query$
    with i as (select * from invoices where org_id = %1$L and created_at >= %2$L::date and created_at < %3$L::date + 1)
    select (select count(*)::int from i) received, (select count(*)::int from i where approved_at is not null) approved,
      (select round((percentile_cont(0.5) within group (order by extract(epoch from submitted_at - created_at)) / 3600)::numeric, 1)::float from i where submitted_at is not null) median_receipt_to_submit_h,
      (select round((percentile_cont(0.5) within group (order by extract(epoch from approved_at - submitted_at)) / 3600)::numeric, 1)::float from i where approved_at is not null) median_submit_to_approve_h,
      (select round((percentile_cont(0.9) within group (order by extract(epoch from approved_at - created_at)) / 3600)::numeric, 1)::float from i where approved_at is not null) p90_receipt_to_approve_h,
      (select count(*)::int from i where extraction_status = 'succeeded') ai_extracted, (select count(*)::int from i where extraction_status = 'failed') ai_failed,
      (select count(*)::int from i where extraction_status = 'manual') manual,
      (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(ai_extraction -> 'confidence', field_confidence, '{}')))), 0)::int from i where extraction_status = 'succeeded') fields_extracted,
      (select coalesce(sum((select count(*) from jsonb_object_keys(coalesce(e.details -> 'changes', '{}')))), 0)::int from audit_events e join i on i.id = e.invoice_id where e.action = 'field_corrected') fields_corrected,
      (select count(*)::int from i where approved_at is not null and extraction_status = 'succeeded'
         and not exists (select 1 from audit_events e where e.invoice_id = i.id and e.action = 'field_corrected')
         and not exists (select 1 from invoice_allocations a where a.invoice_id = i.id and a.source = 'user')) touchless$query$
WHEN 'q17' THEN $query$select id, email, role, approval_limit, accepted_at, created_at from org_invites where org_id = %1$L and accepted_at is null order by created_at desc$query$
WHEN 'q18' THEN $query$select id, name, active, step_order, min_amount, approver_kind, approver_user_id, approver_role, vendor_id, project_id from approval_rules where org_id = %1$L order by step_order, min_amount$query$
WHEN 'q19' THEN $query$select id, alias, vendor_id, learned_from_invoice_id, created_at from vendor_aliases where org_id = %1$L order by created_at desc limit 500$query$
WHEN 'q20' THEN $query$select count(*)::int n from approval_steps s join invoices i on i.id = s.invoice_id
      where s.org_id = %1$L and s.status = 'pending' and i.status = 'pending_approval' and s.round = i.approval_round
        and (s.approver_user_id = %2$L or (s.approver_user_id is null and (s.approver_role = %3$L or (s.approver_role = 'controller' and %3$L = 'owner'))))$query$
WHEN 'q21' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status in ('needs_review','pending_approval'))
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q22' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'needs_review')
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q23' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'needs_review' and exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking'))
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q24' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.code in ('duplicate','possible_duplicate')))
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q25' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status in ('open','overridden') and x.code in ('overbilling','po_vendor_mismatch','po_not_found','po_required','cost_code_outside_commitment','project_outside_commitment')))
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q26' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'pending_approval')
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q27' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'approved')
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q28' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.sync_status = 'failed')
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q29' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'rejected')
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q30' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'void')
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q31' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (true)
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q32' THEN $query$select i.id, i.invoice_number, v.name as vendor_name, i.vendor_name_extracted, i.invoice_date, i.due_date, i.total_amount, i.currency,
      i.status, i.extraction_status, i.sync_status, i.file_name, i.created_at, i.po_number,
      (select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id) as projects,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'blocking') as blocking,
      (select count(*)::int from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity = 'warning') as warnings
    from invoices i left join vendors v on v.id = i.vendor_id
    where i.org_id = %1$L and (i.status = 'needs_review' and (i.extraction_status = 'failed' or exists (select 1 from invoice_exceptions x where x.invoice_id = i.id and x.status = 'open' and x.severity in ('blocking','warning'))))
      and (%2$L = '' or i.invoice_number ilike '%%' || %2$L || '%%' or v.name ilike '%%' || %2$L || '%%' or i.vendor_name_extracted ilike '%%' || %2$L || '%%'
           or i.po_number ilike '%%' || %2$L || '%%' or i.file_name ilike '%%' || %2$L || '%%'
           or exists (select 1 from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id and (p.code ilike '%%' || %2$L || '%%' or p.name ilike '%%' || %2$L || '%%')))
    order by i.created_at desc limit 500$query$
WHEN 'q33' THEN $query$
    select x.title grp, count(*)::int total, count(*) filter (where x.status = 'open')::int open, count(*) filter (where x.status = 'overridden')::int overridden,
      count(*) filter (where x.status = 'acknowledged')::int acknowledged, count(*) filter (where x.status = 'resolved')::int resolved,
      count(*) filter (where x.severity = 'blocking')::int blocking, coalesce(sum(distinct i.total_amount), 0) amount
    from invoice_exceptions x join invoices i on i.id = x.invoice_id left join vendors v on v.id = i.vendor_id
    where x.org_id = %1$L and x.created_at >= %2$L::date and x.created_at < %3$L::date + 1 and i.status <> 'void'
    group by 1 order by total desc limit 500$query$
WHEN 'q34' THEN $query$
    select coalesce(v.name, i.vendor_name_extracted, '(unmatched vendor)') grp, count(*)::int total, count(*) filter (where x.status = 'open')::int open, count(*) filter (where x.status = 'overridden')::int overridden,
      count(*) filter (where x.status = 'acknowledged')::int acknowledged, count(*) filter (where x.status = 'resolved')::int resolved,
      count(*) filter (where x.severity = 'blocking')::int blocking, coalesce(sum(distinct i.total_amount), 0) amount
    from invoice_exceptions x join invoices i on i.id = x.invoice_id left join vendors v on v.id = i.vendor_id
    where x.org_id = %1$L and x.created_at >= %2$L::date and x.created_at < %3$L::date + 1 and i.status <> 'void'
    group by 1 order by total desc limit 500$query$
WHEN 'q35' THEN $query$
    select coalesce((select string_agg(distinct p.code, ', ') from invoice_allocations a join projects p on p.id = a.project_id where a.invoice_id = i.id), '(uncoded)') grp, count(*)::int total, count(*) filter (where x.status = 'open')::int open, count(*) filter (where x.status = 'overridden')::int overridden,
      count(*) filter (where x.status = 'acknowledged')::int acknowledged, count(*) filter (where x.status = 'resolved')::int resolved,
      count(*) filter (where x.severity = 'blocking')::int blocking, coalesce(sum(distinct i.total_amount), 0) amount
    from invoice_exceptions x join invoices i on i.id = x.invoice_id left join vendors v on v.id = i.vendor_id
    where x.org_id = %1$L and x.created_at >= %2$L::date and x.created_at < %3$L::date + 1 and i.status <> 'void'
    group by 1 order by total desc limit 500$query$
ELSE NULL END;
  IF template IS NULL THEN RAISE EXCEPTION 'Unknown read'; END IF;
  -- format %L quotes values as literals, never as identifiers or executable SQL.
  -- SECURITY INVOKER means the Data API's authenticated role and RLS apply throughout.
  EXECUTE 'SELECT coalesce(jsonb_agg(to_jsonb(r)), ''[]''::jsonb) FROM (' ||
    format(template, p_params->>0, p_params->>1, p_params->>2, p_params->>3) || ') r' INTO result;
  RETURN result;
END $fn$;
REVOKE ALL ON FUNCTION public.trestle_read(text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.trestle_read(text,jsonb) TO authenticated;
