-- Compare status AND session under lock so recovery cannot overwrite a completed,
-- manually entered, or newer retry run.
CREATE OR REPLACE FUNCTION public.recover_extraction(p_invoice uuid, p_session text, p_reason text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap') AND inv.created_by = app_uid(), 'Only the uploader can recover this extraction');
  IF inv.extraction_status NOT IN ('pending', 'running') OR inv.agent_session_id IS DISTINCT FROM p_session THEN RETURN false; END IF;
  PERFORM agent_fail_extraction(inv.id, p_reason);
  RETURN true;
END $$;
REVOKE ALL ON FUNCTION public.recover_extraction(uuid, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.recover_extraction(uuid, text, text) TO authenticated;
