-- Data API eagerly populates request.jwt.claims; the agent SQL gateway uses pg_session_jwt.
-- Branch in PL/pgSQL so the lazy JWT initializer is NOT planned/executed for a Data API call.
-- The invoker path permits initialization before any definer business workflow.
CREATE OR REPLACE FUNCTION public.app_uid() RETURNS text
LANGUAGE plpgsql STABLE SECURITY INVOKER AS $$
DECLARE claims text;
BEGIN
  claims := nullif(current_setting('request.jwt.claims', true), '');
  IF claims IS NOT NULL THEN RETURN claims::jsonb ->> 'sub'; END IF;
  RETURN auth.user_id();
END
$$;
