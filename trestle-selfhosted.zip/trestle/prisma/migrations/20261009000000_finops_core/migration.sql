-- Construction FinOps core: tenancy, construction master data, AP invoices,
-- matching exceptions, approvals, accounting sync and audit.
-- Access model: every business row carries org_id. A signed-in user sees an
-- org's rows only while they are an active member (org_members). What they may
-- change depends on their role. Every workflow status change goes through a
-- SECURITY DEFINER function in the next migration, so neither the browser nor
-- an AI agent can skip a control by writing a status column directly.

-- ---------------------------------------------------------------- identity
CREATE OR REPLACE FUNCTION app_uid() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT auth.user_id()
$$;

CREATE TABLE orgs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (length(trim(name)) > 0),
  legal_entity text,
  is_demo boolean NOT NULL DEFAULT false,
  created_by text NOT NULL DEFAULT app_uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE org_members (
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  user_id text NOT NULL,
  email text NOT NULL,
  display_name text NOT NULL DEFAULT '',
  role text NOT NULL CHECK (role IN ('owner', 'controller', 'ap_clerk', 'project_manager', 'viewer')),
  approval_limit numeric(14, 2) CHECK (approval_limit IS NULL OR approval_limit >= 0),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, user_id)
);
CREATE INDEX org_members_user_idx ON org_members (user_id);

CREATE TABLE org_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  email text NOT NULL CHECK (email = lower(email)),
  role text NOT NULL CHECK (role IN ('owner', 'controller', 'ap_clerk', 'project_manager', 'viewer')),
  approval_limit numeric(14, 2),
  invited_by text NOT NULL,
  accepted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, email)
);

-- Role helpers. SECURITY DEFINER so policies can consult membership without
-- recursing into org_members' own policies.
CREATE OR REPLACE FUNCTION app_role(p_org uuid) RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM org_members WHERE org_id = p_org AND user_id = app_uid() AND active
$$;

-- Permission vocabulary used by policies and functions:
--   read     any active member
--   ap       owner, controller, ap_clerk: enter, code and submit invoices; master data; prepare exports
--   admin    owner, controller: approval rules, settings, overriding blocking exceptions, sync results
--   owner    owner: members and roles
CREATE OR REPLACE FUNCTION app_can(p_org uuid, p_perm text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE p_perm
    WHEN 'read' THEN r IS NOT NULL
    WHEN 'ap' THEN r IN ('owner', 'controller', 'ap_clerk')
    WHEN 'admin' THEN r IN ('owner', 'controller')
    WHEN 'owner' THEN r = 'owner'
    ELSE false END
  FROM (SELECT app_role(p_org) AS r) s
$$;

CREATE TABLE org_settings (
  org_id uuid PRIMARY KEY REFERENCES orgs (id) ON DELETE CASCADE,
  variance_pct numeric(6, 3) NOT NULL DEFAULT 2 CHECK (variance_pct >= 0),
  variance_amount numeric(14, 2) NOT NULL DEFAULT 250 CHECK (variance_amount >= 0),
  require_po boolean NOT NULL DEFAULT false,
  require_po_over_amount numeric(14, 2) NOT NULL DEFAULT 0,
  possible_duplicate_days integer NOT NULL DEFAULT 14 CHECK (possible_duplicate_days BETWEEN 0 AND 365),
  allow_self_approval boolean NOT NULL DEFAULT false,
  low_confidence_threshold numeric(4, 3) NOT NULL DEFAULT 0.8 CHECK (low_confidence_threshold BETWEEN 0 AND 1),
  export_target text NOT NULL DEFAULT 'generic_csv',
  ap_can_sync boolean NOT NULL DEFAULT true,
  approval_reminder_hours integer NOT NULL DEFAULT 48 CHECK (approval_reminder_hours BETWEEN 1 AND 720),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- master data
CREATE TABLE vendors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  code text NOT NULL CHECK (length(trim(code)) > 0),
  name text NOT NULL CHECK (length(trim(name)) > 0),
  tax_id text,
  email text,
  phone text,
  address text,
  payment_terms text,
  default_gl_account_id uuid,
  default_cost_type_id uuid,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  external_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, code)
);

CREATE TABLE vendor_aliases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  vendor_id uuid NOT NULL REFERENCES vendors (id) ON DELETE CASCADE,
  alias text NOT NULL,
  learned_from_invoice_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, alias)
);

CREATE TABLE projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  code text NOT NULL CHECK (length(trim(code)) > 0),
  name text NOT NULL CHECK (length(trim(name)) > 0),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'closed')),
  project_manager_user_id text,
  legal_entity text,
  address text,
  external_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, code)
);

CREATE TABLE cost_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  code text NOT NULL CHECK (length(trim(code)) > 0),
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, code)
);

CREATE TABLE gl_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  code text NOT NULL CHECK (length(trim(code)) > 0),
  name text NOT NULL,
  account_type text NOT NULL DEFAULT 'expense' CHECK (account_type IN ('expense', 'cost_of_goods', 'asset', 'liability', 'other')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, code)
);


-- A cost code is company standard (project_id null) or specific to one project.
CREATE TABLE cost_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  project_id uuid REFERENCES projects (id) ON DELETE CASCADE,
  code text NOT NULL CHECK (length(trim(code)) > 0),
  name text NOT NULL,
  budget_amount numeric(14, 2),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE NULLS NOT DISTINCT (org_id, project_id, code)
);

-- Purchase orders and subcontracts share one commitment model.
CREATE TABLE commitments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('purchase_order', 'subcontract')),
  number text NOT NULL CHECK (length(trim(number)) > 0),
  vendor_id uuid NOT NULL REFERENCES vendors (id),
  project_id uuid NOT NULL REFERENCES projects (id),
  description text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
  original_amount numeric(14, 2) NOT NULL DEFAULT 0,
  retainage_pct numeric(5, 2) NOT NULL DEFAULT 0 CHECK (retainage_pct BETWEEN 0 AND 100),
  external_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, number)
);

CREATE TABLE commitment_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  commitment_id uuid NOT NULL REFERENCES commitments (id) ON DELETE CASCADE,
  line_no integer NOT NULL,
  description text,
  cost_code_id uuid REFERENCES cost_codes (id),
  cost_type_id uuid REFERENCES cost_types (id),
  amount numeric(14, 2) NOT NULL DEFAULT 0,
  UNIQUE (commitment_id, line_no)
);

CREATE TABLE change_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  commitment_id uuid NOT NULL REFERENCES commitments (id) ON DELETE CASCADE,
  number text NOT NULL,
  description text,
  amount numeric(14, 2) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  approved_date date,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (commitment_id, number)
);

-- ---------------------------------------------------------------- AP invoices
CREATE TABLE invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  source text NOT NULL DEFAULT 'upload' CHECK (source IN ('upload', 'manual', 'email', 'import')),
  upload_id uuid,
  file_name text,
  status text NOT NULL DEFAULT 'needs_review'
    CHECK (status IN ('needs_review', 'pending_approval', 'approved', 'rejected', 'void')),
  extraction_status text NOT NULL DEFAULT 'pending'
    CHECK (extraction_status IN ('pending', 'running', 'succeeded', 'failed', 'manual')),
  sync_status text NOT NULL DEFAULT 'not_ready'
    CHECK (sync_status IN ('not_ready', 'ready', 'exported', 'synced', 'failed')),
  vendor_id uuid REFERENCES vendors (id),
  vendor_name_extracted text,
  invoice_number text,
  invoice_date date,
  due_date date,
  payment_terms text,
  currency text NOT NULL DEFAULT 'USD',
  subtotal numeric(14, 2),
  tax_amount numeric(14, 2),
  retainage_amount numeric(14, 2),
  total_amount numeric(14, 2),
  po_number text,
  commitment_id uuid REFERENCES commitments (id),
  project_reference text,
  description text,
  field_confidence jsonb NOT NULL DEFAULT '{}',
  ai_extraction jsonb,
  ai_summary text,
  extraction_error text,
  extraction_started_at timestamptz,
  agent_session_id text,
  approval_round integer NOT NULL DEFAULT 0,
  submitted_by text,
  submitted_at timestamptz,
  approved_at timestamptz,
  rejected_reason text,
  approved_snapshot jsonb,
  created_by text NOT NULL DEFAULT app_uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX invoices_org_status_idx ON invoices (org_id, status, created_at DESC);
CREATE INDEX invoices_vendor_idx ON invoices (org_id, vendor_id);
CREATE UNIQUE INDEX invoices_upload_once ON invoices (upload_id) WHERE upload_id IS NOT NULL;

CREATE TABLE invoice_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL REFERENCES invoices (id) ON DELETE CASCADE,
  line_no integer NOT NULL,
  description text,
  quantity numeric(14, 4),
  unit_price numeric(14, 4),
  amount numeric(14, 2),
  UNIQUE (invoice_id, line_no)
);

CREATE TABLE invoice_allocations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL REFERENCES invoices (id) ON DELETE CASCADE,
  project_id uuid REFERENCES projects (id),
  cost_code_id uuid REFERENCES cost_codes (id),
  cost_type_id uuid REFERENCES cost_types (id),
  gl_account_id uuid REFERENCES gl_accounts (id),
  commitment_line_id uuid REFERENCES commitment_lines (id),
  amount numeric(14, 2) NOT NULL DEFAULT 0,
  description text,
  source text NOT NULL DEFAULT 'user' CHECK (source IN ('ai', 'user', 'rule')),
  confidence numeric(4, 3),
  rationale text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX invoice_allocations_invoice_idx ON invoice_allocations (invoice_id);
CREATE INDEX invoice_allocations_project_idx ON invoice_allocations (org_id, project_id);

CREATE TABLE invoice_exceptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL REFERENCES invoices (id) ON DELETE CASCADE,
  code text NOT NULL,
  fingerprint text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('blocking', 'warning', 'info')),
  overridable boolean NOT NULL DEFAULT true,
  title text NOT NULL,
  detail text NOT NULL,
  evidence jsonb NOT NULL DEFAULT '{}',
  resolver text NOT NULL DEFAULT 'ap',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'overridden', 'acknowledged')),
  resolution_note text,
  resolved_by text,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (invoice_id, fingerprint)
);
CREATE INDEX invoice_exceptions_open_idx ON invoice_exceptions (org_id, status);

-- ---------------------------------------------------------------- approvals
CREATE TABLE approval_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  name text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  step_order integer NOT NULL DEFAULT 1 CHECK (step_order BETWEEN 1 AND 20),
  min_amount numeric(14, 2) NOT NULL DEFAULT 0,
  project_id uuid REFERENCES projects (id) ON DELETE CASCADE,
  vendor_id uuid REFERENCES vendors (id) ON DELETE CASCADE,
  approver_kind text NOT NULL CHECK (approver_kind IN ('project_manager', 'user', 'role')),
  approver_user_id text,
  approver_role text CHECK (approver_role IS NULL OR approver_role IN ('owner', 'controller', 'ap_clerk', 'project_manager')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (approver_kind <> 'user' OR approver_user_id IS NOT NULL),
  CHECK (approver_kind <> 'role' OR approver_role IS NOT NULL)
);

CREATE TABLE approval_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL REFERENCES invoices (id) ON DELETE CASCADE,
  round integer NOT NULL,
  step_order integer NOT NULL,
  approver_user_id text,
  approver_role text,
  rule_id uuid REFERENCES approval_rules (id) ON DELETE SET NULL,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'skipped')),
  decided_by text,
  decided_at timestamptz,
  comment text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (approver_user_id IS NOT NULL OR approver_role IS NOT NULL)
);
CREATE INDEX approval_steps_invoice_idx ON approval_steps (invoice_id, round, step_order);
CREATE INDEX approval_steps_approver_idx ON approval_steps (org_id, approver_user_id, status);

-- ---------------------------------------------------------------- accounting sync
CREATE TABLE export_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  batch_number integer NOT NULL,
  target text NOT NULL DEFAULT 'generic_csv',
  status text NOT NULL DEFAULT 'exported' CHECK (status IN ('exported', 'reconciled', 'partially_failed', 'failed')),
  invoice_count integer NOT NULL,
  invoice_total numeric(14, 2) NOT NULL,
  allocation_total numeric(14, 2) NOT NULL,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, batch_number)
);

CREATE TABLE sync_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  invoice_id uuid NOT NULL REFERENCES invoices (id) ON DELETE CASCADE,
  batch_id uuid NOT NULL REFERENCES export_batches (id) ON DELETE CASCADE,
  target text NOT NULL,
  idempotency_key text NOT NULL,
  attempt integer NOT NULL,
  status text NOT NULL DEFAULT 'exported' CHECK (status IN ('exported', 'synced', 'failed')),
  external_id text,
  error text,
  payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (invoice_id, attempt)
);
-- The duplicate-posting guard: an invoice can be in at most one live export.
CREATE UNIQUE INDEX sync_records_one_live ON sync_records (invoice_id) WHERE status IN ('exported', 'synced');
CREATE UNIQUE INDEX sync_records_external_once ON sync_records (org_id, target, external_id) WHERE external_id IS NOT NULL AND status = 'synced';

-- ---------------------------------------------------------------- audit & agents
CREATE TABLE audit_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  entity_type text NOT NULL,
  entity_id uuid,
  invoice_id uuid,
  action text NOT NULL,
  actor_user_id text,
  actor_kind text NOT NULL DEFAULT 'user' CHECK (actor_kind IN ('user', 'agent', 'system')),
  summary text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_events_org_idx ON audit_events (org_id, created_at DESC);
CREATE INDEX audit_events_invoice_idx ON audit_events (invoice_id, created_at);

CREATE TABLE agent_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES orgs (id) ON DELETE CASCADE,
  agent text NOT NULL CHECK (agent IN ('invoice_intake', 'matching_engine', 'approval_router', 'assistant')),
  kind text NOT NULL DEFAULT 'rules' CHECK (kind IN ('ai', 'rules')),
  invoice_id uuid REFERENCES invoices (id) ON DELETE CASCADE,
  status text NOT NULL CHECK (status IN ('running', 'succeeded', 'failed', 'needs_human')),
  summary text,
  input jsonb NOT NULL DEFAULT '{}',
  output jsonb NOT NULL DEFAULT '{}',
  error text,
  triggered_by text,
  session_id text,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
CREATE INDEX agent_runs_org_idx ON agent_runs (org_id, started_at DESC);

-- Composite keys: a row may only reference records of its own organization.
ALTER TABLE vendors ADD UNIQUE (org_id, id);
ALTER TABLE projects ADD UNIQUE (org_id, id);
ALTER TABLE cost_types ADD UNIQUE (org_id, id);
ALTER TABLE gl_accounts ADD UNIQUE (org_id, id);
ALTER TABLE cost_codes ADD UNIQUE (org_id, id);
ALTER TABLE commitments ADD UNIQUE (org_id, id);
ALTER TABLE commitment_lines ADD UNIQUE (org_id, id);
ALTER TABLE invoices ADD UNIQUE (org_id, id);
ALTER TABLE export_batches ADD UNIQUE (org_id, id);
ALTER TABLE vendors ADD FOREIGN KEY (org_id, default_gl_account_id) REFERENCES gl_accounts (org_id, id);
ALTER TABLE vendors ADD FOREIGN KEY (org_id, default_cost_type_id) REFERENCES cost_types (org_id, id);
ALTER TABLE vendor_aliases ADD FOREIGN KEY (org_id, vendor_id) REFERENCES vendors (org_id, id) ON DELETE CASCADE;
ALTER TABLE cost_codes ADD FOREIGN KEY (org_id, project_id) REFERENCES projects (org_id, id) ON DELETE CASCADE;
ALTER TABLE commitments ADD FOREIGN KEY (org_id, vendor_id) REFERENCES vendors (org_id, id);
ALTER TABLE commitments ADD FOREIGN KEY (org_id, project_id) REFERENCES projects (org_id, id);
ALTER TABLE commitment_lines ADD FOREIGN KEY (org_id, commitment_id) REFERENCES commitments (org_id, id) ON DELETE CASCADE;
ALTER TABLE commitment_lines ADD FOREIGN KEY (org_id, cost_code_id) REFERENCES cost_codes (org_id, id);
ALTER TABLE commitment_lines ADD FOREIGN KEY (org_id, cost_type_id) REFERENCES cost_types (org_id, id);
ALTER TABLE change_orders ADD FOREIGN KEY (org_id, commitment_id) REFERENCES commitments (org_id, id) ON DELETE CASCADE;
ALTER TABLE invoices ADD FOREIGN KEY (org_id, vendor_id) REFERENCES vendors (org_id, id);
ALTER TABLE invoices ADD FOREIGN KEY (org_id, commitment_id) REFERENCES commitments (org_id, id);
ALTER TABLE invoice_lines ADD FOREIGN KEY (org_id, invoice_id) REFERENCES invoices (org_id, id) ON DELETE CASCADE;
ALTER TABLE invoice_allocations ADD FOREIGN KEY (org_id, invoice_id) REFERENCES invoices (org_id, id) ON DELETE CASCADE;
ALTER TABLE invoice_allocations ADD FOREIGN KEY (org_id, project_id) REFERENCES projects (org_id, id);
ALTER TABLE invoice_allocations ADD FOREIGN KEY (org_id, cost_code_id) REFERENCES cost_codes (org_id, id);
ALTER TABLE invoice_allocations ADD FOREIGN KEY (org_id, cost_type_id) REFERENCES cost_types (org_id, id);
ALTER TABLE invoice_allocations ADD FOREIGN KEY (org_id, gl_account_id) REFERENCES gl_accounts (org_id, id);
ALTER TABLE invoice_allocations ADD FOREIGN KEY (org_id, commitment_line_id) REFERENCES commitment_lines (org_id, id);
ALTER TABLE approval_rules ADD FOREIGN KEY (org_id, project_id) REFERENCES projects (org_id, id) ON DELETE CASCADE;
ALTER TABLE approval_rules ADD FOREIGN KEY (org_id, vendor_id) REFERENCES vendors (org_id, id) ON DELETE CASCADE;
ALTER TABLE sync_records ADD FOREIGN KEY (org_id, invoice_id) REFERENCES invoices (org_id, id) ON DELETE CASCADE;
ALTER TABLE sync_records ADD FOREIGN KEY (org_id, batch_id) REFERENCES export_batches (org_id, id) ON DELETE CASCADE;

-- ---------------------------------------------------------------- invoice visibility
-- Finance roles and viewers see every invoice of the org. A project manager
-- sees invoices allocated to a project they manage or routed to them.
CREATE OR REPLACE FUNCTION app_invoice_visible(p_invoice uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM invoices i
    WHERE i.id = p_invoice AND (
      app_role(i.org_id) IN ('owner', 'controller', 'ap_clerk', 'viewer')
      OR (app_role(i.org_id) = 'project_manager' AND (
        EXISTS (SELECT 1 FROM approval_steps s WHERE s.invoice_id = i.id AND s.approver_user_id = app_uid())
        OR EXISTS (SELECT 1 FROM invoice_allocations a JOIN projects p ON p.id = a.project_id
                   WHERE a.invoice_id = i.id AND p.project_manager_user_id = app_uid())
        OR i.created_by = app_uid()
      ))
    )
  )
$$;

CREATE OR REPLACE FUNCTION app_invoice_editable(p_invoice uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM invoices i WHERE i.id = p_invoice AND i.status = 'needs_review' AND app_can(i.org_id, 'ap'))
$$;

-- ---------------------------------------------------------------- RLS
ALTER TABLE orgs ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_invites ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendor_aliases ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE gl_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE commitments ENABLE ROW LEVEL SECURITY;
ALTER TABLE commitment_lines ENABLE ROW LEVEL SECURITY;
ALTER TABLE change_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_lines ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_exceptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE export_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE sync_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY member_read ON orgs FOR SELECT TO authenticated USING (app_can(id, 'read'));
CREATE POLICY owner_update ON orgs FOR UPDATE TO authenticated USING (app_can(id, 'owner')) WITH CHECK (app_can(id, 'owner'));

CREATE POLICY member_read ON org_members FOR SELECT TO authenticated USING (app_can(org_id, 'read'));
CREATE POLICY admin_read ON org_invites FOR SELECT TO authenticated USING (app_can(org_id, 'admin'));
CREATE POLICY member_read ON org_settings FOR SELECT TO authenticated USING (app_can(org_id, 'read'));
CREATE POLICY admin_update ON org_settings FOR UPDATE TO authenticated USING (app_can(org_id, 'admin')) WITH CHECK (app_can(org_id, 'admin'));

-- Master data: every member reads; AP and admins maintain.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['vendors', 'vendor_aliases', 'projects', 'cost_types', 'gl_accounts', 'cost_codes'] LOOP
    EXECUTE format('CREATE POLICY member_read ON %I FOR SELECT TO authenticated USING (app_can(org_id, ''read''))', t);
    EXECUTE format('CREATE POLICY ap_insert ON %I FOR INSERT TO authenticated WITH CHECK (app_can(org_id, ''ap''))', t);
    EXECUTE format('CREATE POLICY ap_update ON %I FOR UPDATE TO authenticated USING (app_can(org_id, ''ap'')) WITH CHECK (app_can(org_id, ''ap''))', t);
    EXECUTE format('CREATE POLICY ap_delete ON %I FOR DELETE TO authenticated USING (app_can(org_id, ''ap''))', t);
  END LOOP;
  -- Commitment values drive the overbilling control, so only controllers and owners change them.
  FOREACH t IN ARRAY ARRAY['commitments', 'commitment_lines', 'change_orders'] LOOP
    EXECUTE format('CREATE POLICY member_read ON %I FOR SELECT TO authenticated USING (app_can(org_id, ''read''))', t);
    EXECUTE format('CREATE POLICY admin_insert ON %I FOR INSERT TO authenticated WITH CHECK (app_can(org_id, ''admin''))', t);
    EXECUTE format('CREATE POLICY admin_update ON %I FOR UPDATE TO authenticated USING (app_can(org_id, ''admin'')) WITH CHECK (app_can(org_id, ''admin''))', t);
    EXECUTE format('CREATE POLICY admin_delete ON %I FOR DELETE TO authenticated USING (app_can(org_id, ''admin''))', t);
  END LOOP;
END $$;

-- Invoices: visible per app_invoice_visible; AP inserts and edits only while in review.
CREATE OR REPLACE FUNCTION app_pm_linked(p_invoice uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM approval_steps s WHERE s.invoice_id = p_invoice AND s.approver_user_id = app_uid())
      OR EXISTS (SELECT 1 FROM invoice_allocations a JOIN projects p ON p.id = a.project_id
                 WHERE a.invoice_id = p_invoice AND p.project_manager_user_id = app_uid())
$$;
-- Evaluated on the row's own columns so a freshly inserted row is visible to its creator.
CREATE POLICY visible_read ON invoices FOR SELECT TO authenticated USING (
  app_role(org_id) IN ('owner', 'controller', 'ap_clerk', 'viewer')
  OR (app_role(org_id) = 'project_manager' AND (created_by = app_uid() OR app_pm_linked(id)))
);
CREATE POLICY ap_insert ON invoices FOR INSERT TO authenticated WITH CHECK (
  app_can(org_id, 'ap') AND status = 'needs_review' AND sync_status = 'not_ready' AND approval_round = 0
  AND created_by = app_uid() AND approved_snapshot IS NULL
);
CREATE POLICY ap_update_in_review ON invoices FOR UPDATE TO authenticated
  USING (status = 'needs_review' AND app_can(org_id, 'ap'))
  WITH CHECK (status = 'needs_review' AND app_can(org_id, 'ap'));

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['invoice_lines', 'invoice_allocations'] LOOP
    EXECUTE format('CREATE POLICY visible_read ON %I FOR SELECT TO authenticated USING (app_invoice_visible(invoice_id))', t);
    EXECUTE format('CREATE POLICY ap_insert ON %I FOR INSERT TO authenticated WITH CHECK (app_invoice_editable(invoice_id) AND org_id = (SELECT org_id FROM invoices WHERE id = invoice_id))', t);
    EXECUTE format('CREATE POLICY ap_update ON %I FOR UPDATE TO authenticated USING (app_invoice_editable(invoice_id)) WITH CHECK (app_invoice_editable(invoice_id) AND org_id = (SELECT org_id FROM invoices WHERE id = invoice_id))', t);
    EXECUTE format('CREATE POLICY ap_delete ON %I FOR DELETE TO authenticated USING (app_invoice_editable(invoice_id))', t);
  END LOOP;
END $$;

CREATE POLICY visible_read ON invoice_exceptions FOR SELECT TO authenticated USING (app_invoice_visible(invoice_id));
CREATE POLICY visible_read ON approval_steps FOR SELECT TO authenticated USING (app_invoice_visible(invoice_id));

CREATE POLICY member_read ON approval_rules FOR SELECT TO authenticated USING (app_can(org_id, 'read'));
CREATE POLICY admin_insert ON approval_rules FOR INSERT TO authenticated WITH CHECK (app_can(org_id, 'admin'));
CREATE POLICY admin_update ON approval_rules FOR UPDATE TO authenticated USING (app_can(org_id, 'admin')) WITH CHECK (app_can(org_id, 'admin'));
CREATE POLICY admin_delete ON approval_rules FOR DELETE TO authenticated USING (app_can(org_id, 'admin'));

CREATE POLICY finance_read ON export_batches FOR SELECT TO authenticated USING (app_role(org_id) IN ('owner', 'controller', 'ap_clerk', 'viewer'));
CREATE POLICY finance_read ON sync_records FOR SELECT TO authenticated USING (app_role(org_id) IN ('owner', 'controller', 'ap_clerk', 'viewer'));

CREATE POLICY member_read ON audit_events FOR SELECT TO authenticated USING (
  app_can(org_id, 'read') AND (invoice_id IS NULL OR app_invoice_visible(invoice_id))
);
CREATE POLICY member_read ON agent_runs FOR SELECT TO authenticated USING (
  app_can(org_id, 'read') AND (invoice_id IS NULL OR app_invoice_visible(invoice_id))
);

-- ---------------------------------------------------------------- grants
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON orgs, org_members, org_invites, org_settings, invoice_exceptions, approval_steps,
  export_batches, sync_records, audit_events, agent_runs TO authenticated;
GRANT UPDATE (name, legal_entity) ON orgs TO authenticated;
GRANT UPDATE (variance_pct, variance_amount, require_po, require_po_over_amount, possible_duplicate_days,
  allow_self_approval, low_confidence_threshold, export_target, ap_can_sync, approval_reminder_hours, updated_at) ON org_settings TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON vendors, vendor_aliases, projects, cost_types, gl_accounts, cost_codes,
  commitments, commitment_lines, change_orders, invoice_lines, invoice_allocations, approval_rules TO authenticated;
GRANT SELECT, INSERT ON invoices TO authenticated;
-- Only reviewable fields; status, sync and approval columns change through functions.
GRANT UPDATE (vendor_id, vendor_name_extracted, invoice_number, invoice_date, due_date, payment_terms, currency,
  subtotal, tax_amount, retainage_amount, total_amount, po_number, commitment_id, project_reference, description,
  agent_session_id, updated_at) ON invoices TO authenticated;
REVOKE TRUNCATE, TRIGGER, REFERENCES ON ALL TABLES IN SCHEMA public FROM authenticated;
