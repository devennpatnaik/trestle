-- Preserve an actually unmatched-vendor exercise; exact names are auto-matched by the real controls engine.
CREATE OR REPLACE FUNCTION public.create_demo_organization() RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $fn$
DECLARE
  o uuid; p3 uuid; c uuid; inv uuid; prior uuid; v uuid; j uuid; cc uuid; ct uuid; gl uuid; com uuid;
  batch uuid; batchno int; r record; x record; stage text; received timestamptz;
BEGIN
  PERFORM _require(app_uid() IS NOT NULL, 'Sign in first');
  PERFORM pg_advisory_xact_lock(hashtext('demo:' || app_uid()));
  SELECT id INTO o FROM orgs WHERE created_by = app_uid() AND is_demo
    AND EXISTS (SELECT 1 FROM audit_events a WHERE a.org_id = orgs.id AND a.action = 'demo_seed_v2') LIMIT 1;
  IF o IS NOT NULL THEN RETURN o; END IF;
  o := _create_demo_base_v2();
  UPDATE orgs SET name = 'Summit Ridge Builders · Demo', legal_entity = 'Summit Ridge Builders LLC (fictional)' WHERE id = o;
  UPDATE org_settings SET export_target = 'demo_csv', allow_self_approval = true WHERE org_id = o;
  -- Keep production's separation-of-duties rules intact. The demo explicitly uses one owner step.
  UPDATE approval_rules SET active = false WHERE org_id = o;
  INSERT INTO approval_rules(org_id,name,step_order,approver_kind,approver_role)
    VALUES(o,'Demo only: owner approval for a single-person walkthrough',1,'role','owner');
  UPDATE vendors SET email = lower(code) || '@example.com', address = 'Fictional supplier address · training data',
    external_id = 'DEMO-' || code WHERE org_id = o;
  INSERT INTO projects(org_id,code,name,address,project_manager_user_id,legal_entity)
    VALUES(o,'26-204','Harbor Distribution Center','80 Harbor Way (fictional)',app_uid(),'Summit Ridge Builders LLC') RETURNING id INTO p3;
  INSERT INTO vendors(org_id,code,name,email,payment_terms,default_gl_account_id,default_cost_type_id)
    SELECT o,'V-1006','Cedar Site Safety','safety@example.com','Net 30',g.id,t.id FROM gl_accounts g,cost_types t
    WHERE g.org_id=o AND g.code='5010' AND t.org_id=o AND t.code='M';
  UPDATE projects SET external_id='DEMO-JOB-'||code WHERE org_id=o;
  UPDATE cost_codes SET budget_amount = CASE code WHEN '03-300' THEN 220000 WHEN '26-050' THEN 240000 ELSE 95000 END WHERE org_id=o;
  FOR r IN SELECT * FROM (VALUES
    ('SC-24117-004','V-1005','24-117','22-100','S',72000::numeric,'Plumbing renovation and fixtures',5::numeric,'subcontract'),
    ('PO-26204-011','V-1004','26-204','06-100','M',36000::numeric,'Timber and framing materials',0::numeric,'purchase_order'),
    ('PO-24117-006','V-1004','24-117','09-250','M',18000::numeric,'Classroom gypsum board and accessories',0::numeric,'purchase_order')
  ) AS t(number,vendor,job,cost,type,amount,description,retainage,kind) LOOP
    SELECT id INTO v FROM vendors WHERE org_id=o AND code=r.vendor;
    SELECT id INTO j FROM projects WHERE org_id=o AND code=r.job;
    SELECT id INTO cc FROM cost_codes WHERE org_id=o AND code=r.cost;
    SELECT id INTO ct FROM cost_types WHERE org_id=o AND code=r.type;
    INSERT INTO commitments(org_id,kind,number,vendor_id,project_id,description,original_amount,retainage_pct,external_id)
      VALUES(o,r.kind,r.number,v,j,r.description,r.amount,r.retainage,'DEMO-'||r.number) RETURNING id INTO c;
    INSERT INTO commitment_lines(org_id,commitment_id,line_no,description,cost_code_id,cost_type_id,amount)
      VALUES(o,c,1,r.description,cc,ct,r.amount);
  END LOOP;
  INSERT INTO change_orders(org_id,commitment_id,number,description,amount,status)
    SELECT o,id,'CO-01','Additional classroom sink scope — not authorized',4500,'pending' FROM commitments WHERE org_id=o AND number='SC-24117-004';
  -- Finish the old history record: approved snapshot, approval evidence and confirmed simulated export.
  SELECT id INTO prior FROM invoices WHERE org_id=o AND invoice_number='GSR-88120';
  UPDATE invoices SET retainage_amount=0, approved_snapshot=_invoice_snapshot(id), description='Fictional prior foundation pours; baseline for duplicate and overbilling checks.' WHERE id=prior;
  INSERT INTO invoice_lines(org_id,invoice_id,line_no,description,quantity,unit_price,amount)
    VALUES(o,prior,1,'Foundation pours, delivered and accepted',1,41000,41000);
  INSERT INTO approval_steps(org_id,invoice_id,round,step_order,approver_user_id,reason,status,decided_by,decided_at,comment,created_at)
    VALUES(o,prior,1,1,app_uid(),'Synthetic historical approval','approved',app_uid(),now()-interval '38 days','Seeded example, not a real approval',now()-interval '39 days');

  FOR r IN SELECT * FROM jsonb_to_recordset($scenarios$[
    {"number":"GSR-88214","vendor":"V-1001","job":"24-101","cost":"03-300","type":"M","gl":"5010","po":"PO-24101-007","amount":650,"tax":0,"retainage":0,"age":2,"stage":"review","description":"Additional concrete delivery: 4 CY at $162.50. Ready for review and submission."},
    {"number":"GSR-88219","vendor":"V-1001","job":"24-101","cost":"03-300","type":"M","gl":"5010","po":"PO-24101-007","amount":9800,"tax":0,"retainage":0,"age":1,"stage":"overbilling","description":"Slab delivery exceeds the remaining concrete commitment. Obtain an approved change order or correct the bill."},
    {"number":"GSR-88120","vendor":"V-1001","job":"24-101","cost":"03-300","type":"M","gl":"5010","po":"PO-24101-007","amount":41000,"tax":0,"retainage":0,"age":1,"stage":"duplicate","description":"Resent copy of the foundation invoice already recorded in demo history. Void this duplicate; do not pay twice."},
    {"number":"AE-2409-02","vendor":"V-1002","job":"24-101","cost":"26-050","type":"S","gl":"5020","po":"SC-24101-003","amount":50000,"tax":0,"retainage":5000,"age":24,"stage":"synced","description":"Electrical progress billing: rough-in complete on first floor. $5,000 retainage withheld; $45,000 payable."},
    {"number":"AE-2410-03","vendor":"V-1002","job":"24-101","cost":"26-050","type":"S","gl":"5020","po":"SC-24101-003","amount":30000,"tax":0,"retainage":3000,"age":5,"stage":"pending","description":"Electrical progress billing: second-floor circuits. $3,000 retainage withheld; $27,000 payable. Awaiting owner approval."},
    {"number":"NR-7102","vendor":"V-1003","job":"24-117","cost":"01-540","type":"E","gl":"5030","po":"PO-24117-002","amount":1800,"tax":0,"retainage":0,"age":8,"stage":"ready","description":"Two-week scissor lift rental; approved and ready for accounting export."},
    {"number":"BS-6021","vendor":"V-1004","job":"24-117","cost":"09-250","type":"M","gl":"5010","amount":2187.50,"tax":187.50,"retainage":0,"age":4,"stage":"split","description":"Consumable materials and sales tax split between Oakwood ($1,312.50) and Harbor ($875). Awaiting approval."},
    {"number":"CF-3018","vendor":"V-1005","job":"24-117","cost":"22-100","type":"S","gl":"5020","po":"SC-24117-004","amount":6300,"tax":0,"retainage":315,"age":9,"stage":"rejected","description":"Plumbing fixture installation: returned to AP because delivery tickets do not support billed quantities."},
    {"number":"BS-6002","vendor":"V-1004","cost":"09-250","type":"M","gl":"5010","amount":840,"tax":0,"retainage":0,"age":3,"stage":"uncoded","description":"Gypsum accessories with no job on the invoice. Ask the site team and assign the correct job before submission."},
    {"number":"NR-7097","vendor":"V-1003","job":"24-117","cost":"01-540","type":"E","gl":"5030","po":"PO-24117-002","amount":2400,"tax":0,"retainage":0,"age":12,"stage":"failed","description":"Excavator rental approved; simulated ERP import rejected the vendor mapping. Correct mapping and re-export."},
    {"number":"BS-5940","vendor":"V-1004","job":"26-204","cost":"06-100","type":"M","gl":"5010","po":"PO-26204-011","amount":1620,"tax":120,"retainage":0,"age":18,"stage":"synced","description":"Framing hardware for Harbor Distribution Center; simulated accounting confirmation recorded."},
    {"number":"NR-7079","vendor":"V-1003","job":"24-117","cost":"01-540","type":"E","gl":"5030","po":"PO-24117-002","amount":1200,"tax":0,"retainage":0,"age":10,"stage":"exported","description":"Portable generator rental; CSV prepared, awaiting accounting confirmation. Not yet confirmed posted."},
    {"number":"BS-6025","vendor":"V-1004","job":"26-204","cost":"06-100","type":"M","gl":"5010","po":"PO-26204-011","amount":945,"tax":70,"retainage":0,"age":1,"stage":"confidence","description":"Timber blocking and anchors. Illustrative low-confidence due date: compare the source and confirm it."},
    {"number":"CSS-1184","job":"26-204","cost":"01-540","type":"M","gl":"5010","amount":375,"tax":0,"retainage":0,"age":2,"stage":"unmatched","description":"Safety signage and barriers. The supplier trades as CSS Site Services. Confirm it is Cedar Site Safety, then match the existing vendor rather than creating a duplicate."}
  ]$scenarios$::jsonb) AS t(number text,vendor text,job text,cost text,type text,gl text,po text,amount numeric,tax numeric,retainage numeric,age int,stage text,description text) LOOP
    SELECT id INTO v FROM vendors WHERE org_id=o AND code=r.vendor;
    SELECT id INTO j FROM projects WHERE org_id=o AND code=r.job;
    SELECT id INTO cc FROM cost_codes WHERE org_id=o AND code=r.cost;
    SELECT id INTO ct FROM cost_types WHERE org_id=o AND code=r.type;
    SELECT id INTO gl FROM gl_accounts WHERE org_id=o AND code=r.gl;
    SELECT id INTO com FROM commitments WHERE org_id=o AND number=r.po;
    received := now() - r.age * interval '1 day';
    INSERT INTO invoices(org_id,source,extraction_status,vendor_id,vendor_name_extracted,invoice_number,invoice_date,due_date,payment_terms,
      subtotal,tax_amount,retainage_amount,total_amount,po_number,commitment_id,project_reference,description,created_by,created_at)
    VALUES(o,'import','manual',v,coalesce((SELECT name FROM vendors WHERE id=v),'CSS Site Services'),r.number,current_date-r.age,current_date-r.age+30,'Net 30',
      r.amount-r.tax,r.tax,r.retainage,r.amount,r.po,com,r.job,r.description,app_uid(),received) RETURNING id INTO inv;
    INSERT INTO invoice_lines(org_id,invoice_id,line_no,description,quantity,unit_price,amount)
      VALUES(o,inv,1,r.description,1,r.amount-r.tax,r.amount-r.tax);
    INSERT INTO invoice_allocations(org_id,invoice_id,project_id,cost_code_id,cost_type_id,gl_account_id,amount,description,source)
      VALUES(o,inv,j,cc,ct,gl,CASE WHEN r.stage='split' THEN 1312.50 ELSE r.amount END,r.description,'user');
    IF r.stage='split' THEN
      INSERT INTO invoice_allocations(org_id,invoice_id,project_id,cost_code_id,cost_type_id,gl_account_id,amount,description,source)
      SELECT o,inv,p3,id,ct,gl,875,'Harbor share of supplies and tax','user' FROM cost_codes WHERE org_id=o AND code='06-100';
    END IF;
    IF r.stage='confidence' THEN
      UPDATE invoices SET extraction_status='succeeded', field_confidence='{"due_date":0.62}', ai_summary='Illustrative extraction result, seeded for training; no AI run was performed.' WHERE id=inv;
    END IF;
    PERFORM _invoice_checks(inv,false);
    IF r.stage IN ('pending','split','ready','synced','exported','failed','rejected') THEN
      PERFORM submit_invoice(inv);
      IF r.stage='rejected' THEN
        PERFORM decide_invoice(inv,'reject','Synthetic review: delivery tickets support fewer fixtures. Request a corrected invoice before resubmission.');
      ELSIF r.stage NOT IN ('pending','split') THEN
        PERFORM decide_invoice(inv,'approve','Synthetic demo approval, not a real financial decision');
        UPDATE invoices SET sync_status=CASE WHEN r.stage='ready' THEN 'ready' ELSE r.stage END WHERE id=inv;
      END IF;
      UPDATE invoices SET submitted_at=received+interval '4 hours',
        approved_at=CASE WHEN status='approved' THEN received+interval '1 day' ELSE NULL END WHERE id=inv;
      UPDATE approval_steps SET created_at=received+interval '4 hours',decided_at=CASE WHEN status IN ('approved','rejected') THEN received+interval '1 day' ELSE NULL END WHERE invoice_id=inv;
    END IF;
  END LOOP;
  -- Keep immutable illustrative source data beside each demo record. No invented upload/storage IDs.
  UPDATE invoices SET ai_extraction=jsonb_build_object('demo',true,'demo_document',
    _invoice_snapshot(id) || jsonb_build_object('vendor_name',coalesce((SELECT name FROM vendors WHERE id=invoices.vendor_id),vendor_name_extracted),'description',description,
      'lines',(SELECT coalesce(jsonb_agg(to_jsonb(l) - 'org_id' - 'invoice_id'), '[]') FROM invoice_lines l WHERE l.invoice_id=invoices.id)))
    WHERE org_id=o;
  -- Actual approval snapshots always describe the approved coding, separately from the illustrative document.
  UPDATE invoices SET approved_snapshot=_invoice_snapshot(id) WHERE org_id=o AND status='approved';
  batchno := 0;
  FOREACH stage IN ARRAY ARRAY['synced','failed','exported'] LOOP
    batchno := batchno+1;
    INSERT INTO export_batches(org_id,batch_number,target,status,invoice_count,invoice_total,allocation_total,created_by,created_at)
      SELECT o,batchno,'demo_csv',CASE stage WHEN 'synced' THEN 'reconciled' WHEN 'failed' THEN 'failed' ELSE 'exported' END,
        count(*),sum(total_amount),sum(total_amount),app_uid(),max(approved_at)+interval '1 hour'
      FROM invoices WHERE org_id=o AND sync_status=stage RETURNING id INTO batch;
    INSERT INTO sync_records(org_id,invoice_id,batch_id,target,idempotency_key,attempt,status,external_id,error,payload,created_at,updated_at)
      SELECT o,id,batch,'demo_csv','INV-'||id,1,stage,
        CASE WHEN stage='synced' THEN 'SIMULATED-AP-'||invoice_number END,
        CASE WHEN stage='failed' THEN 'Simulated ERP rejection: vendor V-1003 not mapped in the accounting import. Confirm the vendor mapping and retry.' END,
        approved_snapshot,approved_at+interval '1 hour',approved_at+interval '2 hours'
      FROM invoices WHERE org_id=o AND sync_status=stage;
  END LOOP;
  -- Make the seed's audit history unmistakably fictional; future user actions remain normal audit events.
  UPDATE audit_events SET actor_kind='system',summary='Demo seed · '||summary,details=details||'{"synthetic":true}'::jsonb,
    created_at=coalesce((SELECT CASE WHEN action IN ('approved','step_approved','rejected') THEN coalesce(i.approved_at,i.submitted_at+interval '20 hours')
      WHEN action='submitted' THEN i.submitted_at ELSE i.created_at END FROM invoices i WHERE i.id=audit_events.invoice_id),now())
    WHERE org_id=o;
  INSERT INTO audit_events(org_id,entity_type,entity_id,action,actor_kind,summary,details)
    VALUES(o,'org',o,'demo_seed_v2','system','Demo initialized: 15 fictional invoices, 6 vendors, 3 jobs, 6 commitments. No external posting or payments.',
      '{"synthetic":true,"version":2}');
  RETURN o;
END $fn$;
REVOKE ALL ON FUNCTION public.create_demo_organization() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_demo_organization() TO authenticated;
