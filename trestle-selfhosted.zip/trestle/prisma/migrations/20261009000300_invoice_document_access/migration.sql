-- Reviewers, approvers and controllers must see the original document of any
-- invoice they can see, not only the person who uploaded it. Invoice visibility
-- is itself governed by the invoices policies (company membership and role), and
-- the uploader must belong to that invoice's company, so pointing an invoice at
-- another company's upload id grants nothing.
CREATE POLICY invoice_document_read ON bourne_uploads FOR SELECT TO authenticated USING (
  EXISTS (
    SELECT 1 FROM invoices i JOIN org_members m ON m.org_id = i.org_id AND m.user_id::text = bourne_uploads.user_id
    WHERE i.upload_id = bourne_uploads.id
  )
);
