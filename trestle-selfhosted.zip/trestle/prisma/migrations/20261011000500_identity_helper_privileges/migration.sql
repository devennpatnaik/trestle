-- authenticated intentionally has no general access to schema auth. The helper may
-- read only the caller's authenticated identity; the explicit branch avoids initializing
-- pg_session_jwt for Data API calls whose verified claims are already supplied.
ALTER FUNCTION public.app_uid() SECURITY DEFINER;
ALTER FUNCTION public.app_uid() SET search_path = public;
