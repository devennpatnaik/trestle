-- The Data API and platform SQL gateway authenticate the request and set request.jwt.claims.
-- Read the same signed subject directly: pg_session_jwt's lazy initialization attempts to
-- change a GUC inside SECURITY DEFINER functions and can clear identity on a fresh connection.
-- No app route accepts caller-supplied claims or arbitrary SQL; trestle_read is invoker-only.
CREATE OR REPLACE FUNCTION public.app_uid() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub'
$$;
