-- GL account on allocations is required only when the company has active GL accounts.
CREATE OR REPLACE FUNCTION _invoice_checks(p_invoice uuid, p_log boolean DEFAULT true) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  st org_settings;
  ven vendors;
  com commitments;
  ex jsonb := '[]';
  matched jsonb := '{}';
  v_id uuid;
  v_count int;
  r record;
  k text;
  v_alloc_sum numeric;
  v_alloc_count int;
  v_lines_sum numeric;
  v_revised numeric;
  v_billed numeric;
  v_overage numeric;
  v_tol numeric;
  v_blocking int;
  v_warn int;
  v_run uuid;
  e jsonb;
  v_gl_required boolean;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invoice not found'; END IF;
  SELECT * INTO st FROM org_settings WHERE org_id = inv.org_id;
  -- GL coding is required only for companies that maintain a chart of accounts here;
  -- job-cost-only ERPs derive the GL from the cost type.
  v_gl_required := EXISTS (SELECT 1 FROM gl_accounts WHERE org_id = inv.org_id AND active);

  -- ---- vendor matching (exact normalized name, learned alias, or tax id)
  IF inv.vendor_id IS NULL AND inv.vendor_name_extracted IS NOT NULL AND inv.status = 'needs_review' THEN
    SELECT count(DISTINCT vid), min(vid::text)::uuid INTO v_count, v_id FROM (
      SELECT id AS vid FROM vendors WHERE org_id = inv.org_id AND status = 'active'
        AND app_norm_name(name) = app_norm_name(inv.vendor_name_extracted)
      UNION
      SELECT vendor_id FROM vendor_aliases WHERE org_id = inv.org_id AND alias = app_norm_name(inv.vendor_name_extracted)
    ) m;
    IF v_count = 1 THEN
      PERFORM set_config('app.actor_kind', 'system', true);
      UPDATE invoices SET vendor_id = v_id WHERE id = inv.id;
      matched := matched || jsonb_build_object('vendor', jsonb_build_object('vendor_id', v_id, 'method', 'name_or_alias'));
      inv.vendor_id := v_id;
    END IF;
  END IF;
  IF inv.vendor_id IS NOT NULL THEN SELECT * INTO ven FROM vendors WHERE id = inv.vendor_id; END IF;

  -- ---- commitment matching by PO / subcontract number
  IF inv.commitment_id IS NULL AND inv.po_number IS NOT NULL AND inv.status = 'needs_review' THEN
    SELECT count(*), min(id::text)::uuid INTO v_count, v_id FROM commitments
    WHERE org_id = inv.org_id AND app_norm_ref(number) = app_norm_ref(inv.po_number);
    IF v_count = 1 THEN
      PERFORM set_config('app.actor_kind', 'system', true);
      UPDATE invoices SET commitment_id = v_id WHERE id = inv.id;
      matched := matched || jsonb_build_object('commitment', jsonb_build_object('commitment_id', v_id, 'method', 'po_number'));
      inv.commitment_id := v_id;
    END IF;
  END IF;
  IF inv.commitment_id IS NOT NULL THEN SELECT * INTO com FROM commitments WHERE id = inv.commitment_id; END IF;

  -- Rule-based coding when nothing has been proposed: a single-line commitment fully defines the coding.
  SELECT count(*) INTO v_alloc_count FROM invoice_allocations WHERE invoice_id = inv.id;
  IF v_alloc_count = 0 AND com.id IS NOT NULL AND inv.total_amount IS NOT NULL AND inv.status = 'needs_review'
     AND (SELECT count(*) FROM commitment_lines WHERE commitment_id = com.id) = 1 THEN
    PERFORM set_config('app.actor_kind', 'system', true);
    INSERT INTO invoice_allocations (org_id, invoice_id, project_id, cost_code_id, cost_type_id, gl_account_id, commitment_line_id, amount, source, confidence, rationale)
    SELECT inv.org_id, inv.id, com.project_id, l.cost_code_id, coalesce(l.cost_type_id, ven.default_cost_type_id), ven.default_gl_account_id, l.id,
      inv.total_amount, 'rule', 1, 'Coded from the only line of ' || com.number || '.'
    FROM commitment_lines l WHERE l.commitment_id = com.id;
    matched := matched || jsonb_build_object('coding', 'single_line_commitment');
  END IF;
  PERFORM set_config('app.actor_kind', '', true);

  -- ---- required fields
  IF inv.vendor_id IS NULL THEN
    IF inv.vendor_name_extracted IS NOT NULL THEN
      ex := ex || jsonb_build_object('code', 'vendor_unmatched', 'fp', 'vendor_unmatched', 'severity', 'blocking', 'overridable', false,
        'title', 'Vendor not matched',
        'detail', format('The invoice names "%s", which matches no active vendor or learned alias. Pick the vendor (the system learns the alias) or add the vendor first.', inv.vendor_name_extracted),
        'evidence', jsonb_build_object('extracted_name', inv.vendor_name_extracted,
          'similar_vendors', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name)), '[]') FROM (
            SELECT id, code, name FROM vendors WHERE org_id = inv.org_id AND status = 'active'
              AND app_norm_name(name) LIKE split_part(app_norm_name(inv.vendor_name_extracted), ' ', 1) || '%' LIMIT 5) s)));
    ELSE
      ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:vendor', 'severity', 'blocking', 'overridable', false,
        'title', 'Vendor missing', 'detail', 'No vendor was found on the document. Select the vendor.', 'evidence', '{}');
    END IF;
  END IF;
  IF inv.invoice_number IS NULL THEN
    ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:invoice_number', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice number missing', 'detail', 'An invoice number is required for duplicate control and posting. Enter it from the document.', 'evidence', '{}');
  END IF;
  IF inv.invoice_date IS NULL THEN
    ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:invoice_date', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice date missing', 'detail', 'Enter the invoice date from the document.', 'evidence', '{}');
  END IF;
  IF inv.total_amount IS NULL THEN
    ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:total_amount', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice total missing', 'detail', 'Enter the invoice total from the document.', 'evidence', '{}');
  END IF;

  -- ---- low-confidence extraction
  FOR k IN SELECT key FROM jsonb_each(inv.field_confidence)
           WHERE jsonb_typeof(value) = 'number' AND value::text::numeric < st.low_confidence_threshold LOOP
    ex := ex || jsonb_build_object('code', 'low_confidence', 'fp', 'low_conf:' || k, 'severity', 'warning', 'overridable', true,
      'title', 'Check ' || replace(k, '_', ' ') || ' against the document',
      'detail', format('The AI read this field with %s%% confidence (threshold %s%%). Confirm or correct it; editing the field marks it verified.',
        round((inv.field_confidence ->> k)::numeric * 100), round(st.low_confidence_threshold * 100)),
      'evidence', jsonb_build_object('field', k, 'confidence', inv.field_confidence -> k, 'ai_value', inv.ai_extraction -> k));
  END LOOP;

  -- ---- arithmetic consistency
  IF inv.subtotal IS NOT NULL AND inv.total_amount IS NOT NULL
     AND abs(inv.subtotal + coalesce(inv.tax_amount, 0) - inv.total_amount) > 0.01 THEN
    ex := ex || jsonb_build_object('code', 'totals_mismatch', 'fp', 'totals:header', 'severity', 'warning', 'overridable', true,
      'title', 'Subtotal plus tax does not equal total',
      'detail', format('Subtotal %s + tax %s = %s, but the total is %s (difference %s).', inv.subtotal, coalesce(inv.tax_amount, 0),
        inv.subtotal + coalesce(inv.tax_amount, 0), inv.total_amount, inv.total_amount - inv.subtotal - coalesce(inv.tax_amount, 0)),
      'evidence', jsonb_build_object('subtotal', inv.subtotal, 'tax', inv.tax_amount, 'total', inv.total_amount));
  END IF;
  SELECT sum(amount) INTO v_lines_sum FROM invoice_lines WHERE invoice_id = inv.id;
  IF v_lines_sum IS NOT NULL AND coalesce(inv.subtotal, inv.total_amount) IS NOT NULL
     AND abs(v_lines_sum - coalesce(inv.subtotal, inv.total_amount - coalesce(inv.tax_amount, 0))) > 0.01 THEN
    ex := ex || jsonb_build_object('code', 'totals_mismatch', 'fp', 'totals:lines', 'severity', 'warning', 'overridable', true,
      'title', 'Line items do not add up',
      'detail', format('Line items sum to %s; the invoice states %s before tax.', v_lines_sum, coalesce(inv.subtotal, inv.total_amount - coalesce(inv.tax_amount, 0))),
      'evidence', jsonb_build_object('lines_sum', v_lines_sum, 'subtotal', inv.subtotal));
  END IF;

  -- ---- dates
  IF inv.due_date IS NOT NULL AND inv.invoice_date IS NOT NULL AND inv.due_date < inv.invoice_date THEN
    ex := ex || jsonb_build_object('code', 'date_inconsistent', 'fp', 'date:due_before', 'severity', 'warning', 'overridable', true,
      'title', 'Due date is before invoice date', 'detail', format('Invoice date %s, due date %s.', inv.invoice_date, inv.due_date), 'evidence', '{}');
  END IF;
  IF inv.invoice_date > current_date + 1 THEN
    ex := ex || jsonb_build_object('code', 'date_inconsistent', 'fp', 'date:future', 'severity', 'warning', 'overridable', true,
      'title', 'Invoice is dated in the future', 'detail', format('Invoice date %s is after today.', inv.invoice_date), 'evidence', '{}');
  END IF;

  -- ---- duplicates
  IF inv.vendor_id IS NOT NULL AND app_norm_ref(inv.invoice_number) IS NOT NULL THEN
    FOR r IN SELECT id, invoice_number, total_amount, invoice_date, status FROM invoices
             WHERE org_id = inv.org_id AND id <> inv.id AND vendor_id = inv.vendor_id AND status <> 'void'
               AND app_norm_ref(invoice_number) = app_norm_ref(inv.invoice_number) LOOP
      ex := ex || jsonb_build_object('code', 'duplicate', 'fp', 'dup:' || r.id,
        'severity', CASE WHEN r.status = 'rejected' THEN 'warning' ELSE 'blocking' END, 'overridable', true, 'resolver', 'admin',
        'title', 'Duplicate invoice number for this vendor',
        'detail', format('%s already has invoice %s (%s, %s, status %s). Paying both would double-pay the vendor. Void this copy, or a controller can override with a reason if the vendor really reused the number.',
          ven.name, r.invoice_number, r.invoice_date, r.total_amount, r.status),
        'evidence', jsonb_build_object('other_invoice_id', r.id, 'other_number', r.invoice_number, 'other_total', r.total_amount, 'other_status', r.status));
    END LOOP;
  END IF;
  IF inv.vendor_id IS NOT NULL AND inv.total_amount IS NOT NULL AND inv.invoice_date IS NOT NULL THEN
    FOR r IN SELECT id, invoice_number, total_amount, invoice_date, status FROM invoices
             WHERE org_id = inv.org_id AND id <> inv.id AND vendor_id = inv.vendor_id AND status NOT IN ('void', 'rejected')
               AND total_amount = inv.total_amount
               AND abs(invoice_date - inv.invoice_date) <= st.possible_duplicate_days
               AND app_norm_ref(invoice_number) IS DISTINCT FROM app_norm_ref(inv.invoice_number) LOOP
      ex := ex || jsonb_build_object('code', 'possible_duplicate', 'fp', 'pdup:' || r.id, 'severity', 'warning', 'overridable', true,
        'title', 'Possible duplicate: same vendor and amount',
        'detail', format('Invoice %s from the same vendor is also %s, dated %s (within %s days). Confirm these are separate charges.',
          r.invoice_number, r.total_amount, r.invoice_date, st.possible_duplicate_days),
        'evidence', jsonb_build_object('other_invoice_id', r.id, 'other_number', r.invoice_number, 'other_date', r.invoice_date));
    END LOOP;
  END IF;

  IF ven.id IS NOT NULL AND ven.status = 'inactive' THEN
    ex := ex || jsonb_build_object('code', 'vendor_inactive', 'fp', 'vendor_inactive', 'severity', 'warning', 'overridable', true,
      'title', 'Vendor is inactive', 'detail', ven.name || ' is marked inactive in the vendor list.', 'evidence', jsonb_build_object('vendor_id', ven.id));
  END IF;

  -- ---- commitment (PO / subcontract) matching
  IF com.id IS NULL THEN
    IF inv.po_number IS NOT NULL THEN
      ex := ex || jsonb_build_object('code', 'po_not_found', 'fp', 'po_not_found:' || coalesce(app_norm_ref(inv.po_number), ''),
        'severity', CASE WHEN st.require_po THEN 'blocking' ELSE 'warning' END, 'overridable', true, 'resolver', 'admin',
        'title', 'Referenced PO / subcontract not found',
        'detail', format('The invoice references "%s", but no commitment has that number. Import the commitment or pick the right one.', inv.po_number),
        'evidence', jsonb_build_object('po_number', inv.po_number));
    ELSIF st.require_po AND coalesce(inv.total_amount, 0) >= st.require_po_over_amount THEN
      ex := ex || jsonb_build_object('code', 'po_required', 'fp', 'po_required', 'severity', 'blocking', 'overridable', true, 'resolver', 'admin',
        'title', 'Purchase order or subcontract required',
        'detail', format('Company policy requires a commitment for invoices of %s or more. Link the commitment, or a controller can override with a reason.', st.require_po_over_amount),
        'evidence', jsonb_build_object('policy_threshold', st.require_po_over_amount, 'total', inv.total_amount));
    END IF;
  ELSE
    IF inv.vendor_id IS NOT NULL AND com.vendor_id <> inv.vendor_id THEN
      ex := ex || jsonb_build_object('code', 'po_vendor_mismatch', 'fp', 'po_vendor:' || com.id, 'severity', 'blocking', 'overridable', true, 'resolver', 'admin',
        'title', 'Commitment belongs to a different vendor',
        'detail', format('%s is issued to %s, not to %s.', com.number, (SELECT name FROM vendors WHERE id = com.vendor_id), ven.name),
        'evidence', jsonb_build_object('commitment_id', com.id, 'commitment_vendor_id', com.vendor_id, 'invoice_vendor_id', inv.vendor_id));
    END IF;
    IF com.status = 'closed' THEN
      ex := ex || jsonb_build_object('code', 'po_closed', 'fp', 'po_closed:' || com.id, 'severity', 'warning', 'overridable', true,
        'title', 'Commitment is closed', 'detail', com.number || ' is closed; billing against it is unusual.', 'evidence', jsonb_build_object('commitment_id', com.id));
    END IF;
    SELECT com.original_amount + coalesce(sum(amount) FILTER (WHERE status = 'approved'), 0) INTO v_revised
    FROM change_orders WHERE commitment_id = com.id;
    SELECT coalesce(sum(total_amount), 0) INTO v_billed FROM invoices
    WHERE commitment_id = com.id AND id <> inv.id AND status IN ('pending_approval', 'approved');
    v_overage := v_billed + coalesce(inv.total_amount, 0) - v_revised;
    v_tol := least(v_revised * st.variance_pct / 100, st.variance_amount);
    IF v_overage > v_tol + 0.005 THEN
      ex := ex || jsonb_build_object('code', 'overbilling', 'fp', 'over:' || com.id || ':' || round(v_overage, 2),
        'severity', 'blocking', 'overridable', true, 'resolver', 'admin',
        'title', 'Billing exceeds the commitment',
        'detail', format('%s is committed at %s (original %s plus approved change orders). Already billed: %s. This invoice: %s. That is %s over, beyond the allowed variance of %s (the lesser of %s%% or %s). Get a change order approved, short-pay, or a controller can override with a reason.',
          com.number, v_revised, com.original_amount, v_billed, inv.total_amount, round(v_overage, 2), round(v_tol, 2), st.variance_pct, st.variance_amount),
        'evidence', jsonb_build_object('commitment_id', com.id, 'commitment_number', com.number, 'original', com.original_amount,
          'revised', v_revised, 'billed_to_date', v_billed, 'this_invoice', inv.total_amount, 'overage', round(v_overage, 2), 'tolerance', round(v_tol, 2)));
    ELSIF v_overage > 0 THEN
      ex := ex || jsonb_build_object('code', 'overbilling_within_tolerance', 'fp', 'over_tol:' || com.id, 'severity', 'info', 'overridable', true,
        'title', 'Slightly over commitment, within tolerance',
        'detail', format('Billing exceeds %s by %s, inside the allowed variance of %s.', com.number, round(v_overage, 2), round(v_tol, 2)),
        'evidence', jsonb_build_object('commitment_id', com.id, 'overage', round(v_overage, 2), 'tolerance', round(v_tol, 2)));
    END IF;
    FOR r IN SELECT number, amount FROM change_orders WHERE commitment_id = com.id AND status = 'pending' LOOP
      ex := ex || jsonb_build_object('code', 'pending_change_order', 'fp', 'pco:' || com.id || ':' || r.number, 'severity', 'info', 'overridable', true,
        'title', 'Pending change order ' || r.number,
        'detail', format('Change order %s for %s on %s is not approved yet and is not counted in the committed amount.', r.number, r.amount, com.number),
        'evidence', jsonb_build_object('commitment_id', com.id, 'change_order', r.number, 'amount', r.amount));
    END LOOP;
    IF com.retainage_pct > 0 AND inv.retainage_amount IS NULL AND inv.total_amount IS NOT NULL THEN
      ex := ex || jsonb_build_object('code', 'retainage_expected', 'fp', 'ret:' || com.id, 'severity', 'info', 'overridable', true,
        'title', 'Retainage expected',
        'detail', format('%s carries %s%% retainage (%s on this invoice), but no retainage is recorded.', com.number, com.retainage_pct,
          round(inv.total_amount * com.retainage_pct / 100, 2)),
        'evidence', jsonb_build_object('retainage_pct', com.retainage_pct));
    END IF;
    -- Cost-code level: committed vs billed per cost code on this commitment.
    FOR r IN
      WITH committed AS (
        SELECT cost_code_id, sum(amount) AS amt FROM commitment_lines WHERE commitment_id = com.id AND cost_code_id IS NOT NULL GROUP BY 1),
      billed AS (
        SELECT a.cost_code_id, sum(a.amount) AS amt FROM invoice_allocations a JOIN invoices i ON i.id = a.invoice_id
        WHERE i.commitment_id = com.id AND (i.id = inv.id OR i.status IN ('pending_approval', 'approved')) GROUP BY 1)
      SELECT b.cost_code_id, cc.code, b.amt AS billed, c.amt AS committed
      FROM billed b LEFT JOIN committed c USING (cost_code_id) LEFT JOIN cost_codes cc ON cc.id = b.cost_code_id
      WHERE b.cost_code_id IS NOT NULL AND EXISTS (SELECT 1 FROM committed) AND (c.amt IS NULL OR b.amt > c.amt + 0.005)
    LOOP
      ex := ex || jsonb_build_object('code', 'cost_code_outside_commitment', 'fp', 'cc_over:' || com.id || ':' || r.cost_code_id || ':' || round(r.billed, 2),
        'severity', 'warning', 'overridable', true,
        'title', CASE WHEN r.committed IS NULL THEN 'Cost code ' || r.code || ' is not on ' || com.number ELSE 'Cost code ' || r.code || ' billed beyond its commitment line' END,
        'detail', CASE WHEN r.committed IS NULL THEN format('This invoice codes cost to %s, which has no line on %s.', r.code, com.number)
          ELSE format('Billed to date on %s for %s: %s against %s committed.', com.number, r.code, r.billed, r.committed) END,
        'evidence', jsonb_build_object('commitment_id', com.id, 'cost_code', r.code, 'billed', r.billed, 'committed', r.committed));
    END LOOP;
  END IF;

  -- ---- allocations (job / cost code / cost type / GL coding)
  SELECT coalesce(sum(amount), 0), count(*) INTO v_alloc_sum, v_alloc_count FROM invoice_allocations WHERE invoice_id = inv.id;
  IF v_alloc_count = 0 THEN
    ex := ex || jsonb_build_object('code', 'no_allocations', 'fp', 'no_alloc', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice is not coded', 'detail', 'Add at least one allocation with project, cost code and cost type (and GL account when your chart of accounts is set up).', 'evidence', '{}');
  ELSIF inv.total_amount IS NOT NULL AND abs(v_alloc_sum - inv.total_amount) > 0.005 THEN
    ex := ex || jsonb_build_object('code', 'allocation_unbalanced', 'fp', 'alloc_balance', 'severity', 'blocking', 'overridable', false,
      'title', 'Allocations do not equal the invoice total',
      'detail', format('Allocations total %s; the invoice total is %s (difference %s).', v_alloc_sum, inv.total_amount, inv.total_amount - v_alloc_sum),
      'evidence', jsonb_build_object('allocated', v_alloc_sum, 'total', inv.total_amount, 'difference', inv.total_amount - v_alloc_sum));
  END IF;
  FOR r IN SELECT a.*, p.code AS pcode, p.status AS pstatus, cc.project_id AS cc_project, cc.code AS cccode
           FROM invoice_allocations a LEFT JOIN projects p ON p.id = a.project_id LEFT JOIN cost_codes cc ON cc.id = a.cost_code_id
           WHERE a.invoice_id = inv.id LOOP
    IF r.project_id IS NULL OR r.cost_code_id IS NULL OR r.cost_type_id IS NULL OR (v_gl_required AND r.gl_account_id IS NULL) THEN
      ex := ex || jsonb_build_object('code', 'allocation_incomplete', 'fp', 'alloc_incomplete:' || r.id, 'severity', 'blocking', 'overridable', false,
        'title', 'Allocation is missing coding',
        'detail', format('The %s allocation is missing: %s.', r.amount, concat_ws(', ',
          CASE WHEN r.project_id IS NULL THEN 'project' END, CASE WHEN r.cost_code_id IS NULL THEN 'cost code' END,
          CASE WHEN r.cost_type_id IS NULL THEN 'cost type' END, CASE WHEN v_gl_required AND r.gl_account_id IS NULL THEN 'GL account' END)),
        'evidence', jsonb_build_object('allocation_id', r.id));
    END IF;
    IF r.cc_project IS NOT NULL AND r.project_id IS NOT NULL AND r.cc_project <> r.project_id THEN
      ex := ex || jsonb_build_object('code', 'cost_code_wrong_project', 'fp', 'cc_proj:' || r.id, 'severity', 'blocking', 'overridable', false,
        'title', 'Cost code belongs to another project',
        'detail', format('Cost code %s is specific to a different project than %s.', r.cccode, r.pcode), 'evidence', jsonb_build_object('allocation_id', r.id));
    END IF;
    IF r.pstatus = 'closed' THEN
      ex := ex || jsonb_build_object('code', 'project_closed', 'fp', 'proj_closed:' || r.project_id, 'severity', 'warning', 'overridable', true,
        'title', 'Project ' || r.pcode || ' is closed', 'detail', 'Cost is being coded to a closed project.', 'evidence', jsonb_build_object('project_id', r.project_id));
    END IF;
    IF com.id IS NOT NULL AND r.project_id IS NOT NULL AND r.project_id <> com.project_id THEN
      ex := ex || jsonb_build_object('code', 'project_outside_commitment', 'fp', 'proj_com:' || r.id, 'severity', 'warning', 'overridable', true,
        'title', 'Allocation project differs from the commitment',
        'detail', format('%s is for a different project than %s.', com.number, r.pcode), 'evidence', jsonb_build_object('allocation_id', r.id, 'commitment_id', com.id));
    END IF;
  END LOOP;

  -- ---- reconcile exception records with this run
  FOR e IN SELECT * FROM jsonb_array_elements(ex) LOOP
    INSERT INTO invoice_exceptions AS x (org_id, invoice_id, code, fingerprint, severity, overridable, title, detail, evidence, resolver)
    VALUES (inv.org_id, inv.id, e ->> 'code', e ->> 'fp', e ->> 'severity', (e ->> 'overridable')::boolean, e ->> 'title', e ->> 'detail',
      coalesce(e -> 'evidence', '{}'), coalesce(e ->> 'resolver', CASE WHEN e ->> 'severity' = 'blocking' AND (e ->> 'overridable')::boolean THEN 'admin' ELSE 'ap' END))
    ON CONFLICT (invoice_id, fingerprint) DO UPDATE SET
      severity = EXCLUDED.severity, overridable = EXCLUDED.overridable, title = EXCLUDED.title, detail = EXCLUDED.detail,
      evidence = EXCLUDED.evidence, resolver = EXCLUDED.resolver, updated_at = now(),
      status = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.status ELSE 'open' END,
      resolution_note = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.resolution_note END,
      resolved_by = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.resolved_by END,
      resolved_at = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.resolved_at END;
  END LOOP;
  UPDATE invoice_exceptions SET status = 'resolved', resolution_note = 'Cleared on re-check: the condition is no longer present.',
    resolved_at = now(), resolved_by = NULL, updated_at = now()
  WHERE invoice_id = inv.id AND status <> 'resolved'
    AND fingerprint NOT IN (SELECT e2 ->> 'fp' FROM jsonb_array_elements(ex) e2);

  SELECT count(*) FILTER (WHERE severity = 'blocking' AND status = 'open'), count(*) FILTER (WHERE severity = 'warning' AND status = 'open')
  INTO v_blocking, v_warn FROM invoice_exceptions WHERE invoice_id = inv.id;

  IF p_log THEN
    INSERT INTO agent_runs (org_id, agent, kind, invoice_id, status, summary, input, output, triggered_by, finished_at)
    VALUES (inv.org_id, 'matching_engine', 'rules', inv.id, CASE WHEN v_blocking > 0 THEN 'needs_human' ELSE 'succeeded' END,
      format('Checked invoice %s: %s blocking, %s warnings', coalesce(inv.invoice_number, '(no number)'), v_blocking, v_warn),
      jsonb_build_object('invoice_id', inv.id), jsonb_build_object('matched', matched, 'exceptions', ex), app_uid(), now())
    RETURNING id INTO v_run;
  END IF;
  RETURN jsonb_build_object('blocking', v_blocking, 'warnings', v_warn, 'matched', matched, 'exception_count', jsonb_array_length(ex));
END $$;

CREATE OR REPLACE FUNCTION run_invoice_checks(p_invoice uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_org uuid;
BEGIN
  SELECT org_id INTO v_org FROM invoices WHERE id = p_invoice;
  PERFORM _require(v_org IS NOT NULL AND app_can(v_org, 'ap'), 'You do not have permission to process invoices');
  RETURN _invoice_checks(p_invoice, true);
END $$;

-- ================================================================ AI intake agent entry points
-- The intake agent runs as the signed-in user and may only use these functions
-- to record what it read. It cannot submit, approve, export or override.
CREATE OR REPLACE FUNCTION agent_begin_extraction(p_invoice uuid, p_session_id text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  ctx jsonb;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN
    RETURN jsonb_build_object('already_processed', true);
  END IF;
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  PERFORM set_config('app.actor_kind', 'agent', true);
  UPDATE invoices SET extraction_status = 'running', extraction_started_at = now(), extraction_error = NULL,
    agent_session_id = coalesce(p_session_id, agent_session_id)
  WHERE id = inv.id;
  INSERT INTO agent_runs (org_id, agent, kind, invoice_id, status, summary, input, triggered_by, session_id)
  VALUES (inv.org_id, 'invoice_intake', 'ai', inv.id, 'running', 'Reading ' || coalesce(inv.file_name, 'invoice'),
    jsonb_build_object('upload_id', inv.upload_id, 'file_name', inv.file_name), app_uid(), p_session_id);
  SELECT jsonb_build_object(
    'invoice', jsonb_build_object('id', inv.id, 'upload_id', inv.upload_id, 'file_name', inv.file_name),
    'vendors', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', v.id, 'code', v.code, 'name', v.name, 'tax_id', v.tax_id,
        'aliases', (SELECT jsonb_agg(alias) FROM vendor_aliases a WHERE a.vendor_id = v.id))), '[]')
      FROM (SELECT * FROM vendors WHERE org_id = inv.org_id AND status = 'active' ORDER BY name LIMIT 1000) v),
    'projects', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name, 'address', address)), '[]')
      FROM projects WHERE org_id = inv.org_id AND status = 'active'),
    'cost_codes', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name, 'project_id', project_id)), '[]')
      FROM (SELECT * FROM cost_codes WHERE org_id = inv.org_id ORDER BY code LIMIT 3000) c),
    'cost_types', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name)), '[]') FROM cost_types WHERE org_id = inv.org_id),
    'gl_accounts', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name)), '[]') FROM gl_accounts WHERE org_id = inv.org_id AND active),
    'open_commitments', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'number', c.number, 'kind', c.kind, 'vendor_id', c.vendor_id,
        'project_id', c.project_id, 'amount', c.original_amount,
        'lines', (SELECT jsonb_agg(jsonb_build_object('line_no', l.line_no, 'description', l.description, 'cost_code_id', l.cost_code_id,
            'cost_type_id', l.cost_type_id, 'amount', l.amount) ORDER BY l.line_no) FROM commitment_lines l WHERE l.commitment_id = c.id))), '[]')
      FROM commitments c WHERE c.org_id = inv.org_id AND c.status = 'open'),
    -- How this company has coded each vendor before: the strongest signal for coding suggestions.
    'vendor_coding_history', (SELECT coalesce(jsonb_agg(h), '[]') FROM (
      SELECT i.vendor_id, a.project_id, a.cost_code_id, a.cost_type_id, a.gl_account_id, count(*) AS times, max(i.invoice_date) AS last_used
      FROM invoice_allocations a JOIN invoices i ON i.id = a.invoice_id
      WHERE i.org_id = inv.org_id AND i.status = 'approved'
      GROUP BY 1, 2, 3, 4, 5 ORDER BY times DESC LIMIT 400) h)
  ) INTO ctx;
  RETURN ctx;
END $$;

CREATE OR REPLACE FUNCTION _uuid_in_org(p_table text, p_org uuid, p_value text) RETURNS uuid
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v uuid;
BEGIN
  IF p_value IS NULL OR p_value !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN RETURN NULL; END IF;
  EXECUTE format('SELECT id FROM %I WHERE id = $1 AND org_id = $2', p_table) INTO v USING p_value::uuid, p_org;
  RETURN v;
END $$;

-- payload: { vendor_name, vendor_id?, invoice_number, invoice_date, due_date, payment_terms, currency,
--   subtotal, tax_amount, retainage_amount, total_amount, po_number, project_reference, description, summary,
--   confidence: {field: 0..1}, lines: [{description, quantity, unit_price, amount}],
--   allocations: [{project_id, cost_code_id, cost_type_id, gl_account_id, amount, confidence, rationale}] }
CREATE OR REPLACE FUNCTION agent_submit_extraction(p_invoice uuid, p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  conf jsonb := '{}';
  k text;
  l jsonb;
  n int := 0;
  a jsonb;
  checks jsonb;
  v_vendor uuid;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN RETURN jsonb_build_object('already_processed', true); END IF;
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  PERFORM _require(jsonb_typeof(p) = 'object', 'Payload must be a JSON object');
  PERFORM set_config('app.actor_kind', 'agent', true);

  FOR k IN SELECT key FROM jsonb_each(coalesce(p -> 'confidence', '{}')) LOOP
    IF jsonb_typeof(p -> 'confidence' -> k) = 'number' THEN
      conf := conf || jsonb_build_object(CASE k WHEN 'vendor_name' THEN 'vendor' ELSE k END,
        greatest(0, least(1, (p -> 'confidence' ->> k)::numeric)));
    END IF;
  END LOOP;
  v_vendor := _uuid_in_org('vendors', inv.org_id, p ->> 'vendor_id');

  -- Fill only what a person has not already entered; never overwrite their work.
  UPDATE invoices SET
    vendor_name_extracted = coalesce(vendor_name_extracted, nullif(trim(p ->> 'vendor_name'), '')),
    vendor_id = coalesce(vendor_id, v_vendor),
    invoice_number = coalesce(invoice_number, nullif(trim(p ->> 'invoice_number'), '')),
    invoice_date = coalesce(invoice_date, _date(p ->> 'invoice_date')),
    due_date = coalesce(due_date, _date(p ->> 'due_date')),
    payment_terms = coalesce(payment_terms, nullif(trim(p ->> 'payment_terms'), '')),
    currency = coalesce(nullif(upper(trim(p ->> 'currency')), ''), currency),
    subtotal = coalesce(subtotal, _num(p ->> 'subtotal')),
    tax_amount = coalesce(tax_amount, _num(p ->> 'tax_amount')),
    retainage_amount = coalesce(retainage_amount, _num(p ->> 'retainage_amount')),
    total_amount = coalesce(total_amount, _num(p ->> 'total_amount')),
    po_number = coalesce(po_number, nullif(trim(p ->> 'po_number'), '')),
    project_reference = coalesce(project_reference, nullif(trim(p ->> 'project_reference'), '')),
    description = coalesce(description, nullif(trim(p ->> 'description'), '')),
    field_confidence = conf || field_confidence,
    ai_extraction = p,
    ai_summary = nullif(trim(p ->> 'summary'), ''),
    extraction_status = 'succeeded',
    extraction_error = NULL
  WHERE id = inv.id;

  IF NOT EXISTS (SELECT 1 FROM invoice_lines WHERE invoice_id = inv.id) THEN
    FOR l IN SELECT * FROM jsonb_array_elements(CASE WHEN jsonb_typeof(p -> 'lines') = 'array' THEN p -> 'lines' ELSE '[]' END) LOOP
      n := n + 1;
      INSERT INTO invoice_lines (org_id, invoice_id, line_no, description, quantity, unit_price, amount)
      VALUES (inv.org_id, inv.id, n, left(l ->> 'description', 1000), _num(l ->> 'quantity'), _num(l ->> 'unit_price'), _num(l ->> 'amount'));
    END LOOP;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM invoice_allocations WHERE invoice_id = inv.id) THEN
    FOR a IN SELECT * FROM jsonb_array_elements(CASE WHEN jsonb_typeof(p -> 'allocations') = 'array' THEN p -> 'allocations' ELSE '[]' END) LOOP
      IF _num(a ->> 'amount') IS NOT NULL THEN
        INSERT INTO invoice_allocations (org_id, invoice_id, project_id, cost_code_id, cost_type_id, gl_account_id, amount, description, source, confidence, rationale)
        VALUES (inv.org_id, inv.id,
          _uuid_in_org('projects', inv.org_id, a ->> 'project_id'), _uuid_in_org('cost_codes', inv.org_id, a ->> 'cost_code_id'),
          _uuid_in_org('cost_types', inv.org_id, a ->> 'cost_type_id'), _uuid_in_org('gl_accounts', inv.org_id, a ->> 'gl_account_id'),
          _num(a ->> 'amount'), left(a ->> 'description', 500), 'ai',
          CASE WHEN jsonb_typeof(a -> 'confidence') = 'number' THEN greatest(0, least(1, (a ->> 'confidence')::numeric)) END,
          left(a ->> 'rationale', 2000));
      END IF;
    END LOOP;
  END IF;

  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'ai_extracted', 'AI extracted invoice fields and proposed coding',
    jsonb_build_object('confidence', conf));
  checks := _invoice_checks(inv.id, true);
  UPDATE agent_runs SET status = 'succeeded', finished_at = now(),
    summary = format('Extracted %s %s for %s; %s blocking, %s warnings left for review',
      coalesce(p ->> 'vendor_name', 'unknown vendor'), coalesce(p ->> 'invoice_number', '(no number)'), coalesce(p ->> 'total_amount', '?'),
      checks ->> 'blocking', checks ->> 'warnings'),
    output = jsonb_build_object('extraction', p, 'checks', checks)
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
  RETURN checks;
END $$;

CREATE OR REPLACE FUNCTION agent_fail_extraction(p_invoice uuid, p_error text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN RETURN; END IF;
  PERFORM set_config('app.actor_kind', 'agent', true);
  UPDATE invoices SET extraction_status = 'failed', extraction_error = left(coalesce(p_error, 'Extraction failed'), 2000) WHERE id = inv.id;
  UPDATE agent_runs SET status = 'failed', error = left(p_error, 2000), finished_at = now(), summary = 'Could not read the document'
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'ai_failed', 'AI could not read the document: ' || left(coalesce(p_error, ''), 300), '{}');
END $$;

-- A person takes over data entry (extraction failed, stalled, or not wanted).
CREATE OR REPLACE FUNCTION start_manual_entry(p_invoice uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  IF inv.extraction_status IN ('pending', 'running', 'failed') THEN
    UPDATE invoices SET extraction_status = 'manual' WHERE id = inv.id;
    UPDATE agent_runs SET status = 'failed', error = 'Superseded by manual entry', finished_at = now()
    WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
    PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'manual_entry', 'Switched to manual data entry', '{}');
  END IF;
  RETURN _invoice_checks(inv.id, false);
END $$;

-- Re-queue AI extraction (e.g. after a failure or a stalled run).
CREATE OR REPLACE FUNCTION retry_extraction(p_invoice uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  PERFORM _require(inv.status = 'needs_review' AND inv.upload_id IS NOT NULL, 'Only uploaded invoices in review can be re-read');
  PERFORM _require(inv.extraction_status IN ('failed', 'manual')
      OR (inv.extraction_status = 'running' AND inv.extraction_started_at < now() - interval '10 minutes')
      OR (inv.extraction_status = 'pending' AND inv.updated_at < now() - interval '10 minutes'),
    'Extraction is already running or finished');
  UPDATE invoices SET extraction_status = 'pending', extraction_error = NULL, agent_session_id = NULL WHERE id = inv.id;
  UPDATE agent_runs SET status = 'failed', error = 'Retried', finished_at = now()
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
END $$;

-- ================================================================ approval workflow
CREATE OR REPLACE FUNCTION _can_decide_step(s approval_steps, inv invoices, st org_settings) RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  me org_members;
BEGIN
  SELECT * INTO me FROM org_members WHERE org_id = inv.org_id AND user_id = app_uid() AND active;
  IF me.user_id IS NULL THEN RETURN 'You are not a member of this company'; END IF;
  IF s.approver_user_id IS NOT NULL AND s.approver_user_id <> me.user_id THEN RETURN 'This step is assigned to someone else'; END IF;
  IF s.approver_user_id IS NULL AND NOT (me.role = s.approver_role OR (s.approver_role = 'controller' AND me.role = 'owner')) THEN
    RETURN 'This step needs a ' || replace(s.approver_role, '_', ' ');
  END IF;
  IF me.role = 'viewer' THEN RETURN 'Viewers cannot approve'; END IF;
  IF NOT st.allow_self_approval AND inv.submitted_by = me.user_id THEN RETURN 'You submitted this invoice; company policy requires someone else to approve it'; END IF;
  IF me.approval_limit IS NOT NULL AND inv.total_amount > me.approval_limit THEN
    RETURN format('The total %s exceeds your approval limit of %s', inv.total_amount, me.approval_limit);
  END IF;
  IF s.approver_user_id IS NULL AND EXISTS (SELECT 1 FROM approval_steps o WHERE o.invoice_id = inv.id AND o.round = s.round
      AND o.id <> s.id AND o.decided_by = me.user_id AND o.status = 'approved') THEN
    RETURN 'You already approved another step of this invoice; a different person must approve this one';
  END IF;
  RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION _invoice_snapshot(p_invoice uuid) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT jsonb_build_object(
    'invoice_id', i.id, 'vendor_code', v.code, 'vendor_name', v.name, 'vendor_external_id', v.external_id,
    'invoice_number', i.invoice_number, 'invoice_date', i.invoice_date, 'due_date', i.due_date, 'payment_terms', i.payment_terms,
    'currency', i.currency, 'subtotal', i.subtotal, 'tax_amount', i.tax_amount, 'retainage_amount', i.retainage_amount,
    'total_amount', i.total_amount, 'commitment_number', c.number, 'commitment_external_id', c.external_id, 'description', i.description,
    'allocations', (SELECT coalesce(jsonb_agg(jsonb_build_object(
        'project_code', p.code, 'project_external_id', p.external_id, 'cost_code', cc.code, 'cost_type', ct.code,
        'gl_account', g.code, 'amount', a.amount, 'description', a.description) ORDER BY a.created_at, a.id), '[]')
      FROM invoice_allocations a
      LEFT JOIN projects p ON p.id = a.project_id LEFT JOIN cost_codes cc ON cc.id = a.cost_code_id
      LEFT JOIN cost_types ct ON ct.id = a.cost_type_id LEFT JOIN gl_accounts g ON g.id = a.gl_account_id
      WHERE a.invoice_id = i.id))
  FROM invoices i LEFT JOIN vendors v ON v.id = i.vendor_id LEFT JOIN commitments c ON c.id = i.commitment_id
  WHERE i.id = p_invoice
$$;
