-- The runtime's ddl_command_end hook can see the same table more than once
-- within one command (for example CREATE TABLE ... REFERENCES ..., which also
-- reports an ALTER TABLE subcommand). Attaching the change trigger once per
-- distinct table keeps the same behavior without failing the CREATE TABLE.
DO $do$
BEGIN
  IF to_regprocedure('bourne_runtime.attach_notify()') IS NULL THEN
    RETURN;
  END IF;
  EXECUTE $fn$
    CREATE OR REPLACE FUNCTION bourne_runtime.attach_notify()
    RETURNS event_trigger
    LANGUAGE plpgsql
    AS $body$
    DECLARE
      created record;
    BEGIN
      FOR created IN
        SELECT DISTINCT n.nspname, r.relname
        FROM pg_event_trigger_ddl_commands() c
        JOIN pg_class r ON r.oid = c.objid
        JOIN pg_namespace n ON n.oid = r.relnamespace
        WHERE c.object_type = 'table'
          AND n.nspname = 'public'
      LOOP
        IF NOT EXISTS (
          SELECT 1 FROM pg_trigger t
          JOIN pg_class r ON r.oid = t.tgrelid
          JOIN pg_namespace n ON n.oid = r.relnamespace
          WHERE n.nspname = created.nspname AND r.relname = created.relname
            AND t.tgname = 'bourne_notify' AND NOT t.tgisinternal
        ) THEN
          EXECUTE format(
            'CREATE TRIGGER bourne_notify AFTER INSERT OR UPDATE OR DELETE ON %I.%I FOR EACH ROW EXECUTE FUNCTION bourne_runtime.emit_change()',
            created.nspname,
            created.relname
          );
        END IF;
      END LOOP;
    END
    $body$
  $fn$;
END
$do$;
