-- Workflow functions. Each is SECURITY DEFINER (runs as the table owner, which
-- bypasses RLS), so each checks the caller's permission itself before acting.
-- Internal helpers start with an underscore and are not executable by app users.

-- ================================================================ helpers
CREATE OR REPLACE FUNCTION app_norm_name(p text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT nullif(trim(regexp_replace(
    regexp_replace(' ' || regexp_replace(lower(coalesce(p, '')), '[^a-z0-9]+', ' ', 'g') || ' ',
      ' (the|inc|incorporated|llc|l l c|ltd|limited|co|corp|corporation|company|lp|llp|pc) ', ' ', 'g'),
    '\s+', ' ', 'g')), '')
$$;

CREATE OR REPLACE FUNCTION app_norm_ref(p text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  -- INV-0042, inv 42 and INV42 compare equal: drop punctuation and leading zeros of each number group.
  SELECT nullif(regexp_replace(regexp_replace(upper(coalesce(p, '')), '[^A-Z0-9]', '', 'g'), '(^|[A-Z])0+([0-9])', '\1\2', 'g'), '')
$$;

CREATE OR REPLACE FUNCTION _num(p text) RETURNS numeric
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF p IS NULL OR trim(p) = '' THEN RETURN NULL; END IF;
  RETURN round(regexp_replace(p, '[$,\s]', '', 'g')::numeric, 2);
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION _date(p text) RETURNS date
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF p IS NULL OR trim(p) = '' THEN RETURN NULL; END IF;
  RETURN p::date;
EXCEPTION WHEN others THEN RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION _actor_kind() RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT coalesce(nullif(current_setting('app.actor_kind', true), ''), 'user')
$$;

CREATE OR REPLACE FUNCTION _audit(p_org uuid, p_entity text, p_entity_id uuid, p_invoice uuid, p_action text,
  p_summary text, p_details jsonb DEFAULT '{}') RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  INSERT INTO audit_events (org_id, entity_type, entity_id, invoice_id, action, actor_user_id, actor_kind, summary, details)
  VALUES (p_org, p_entity, p_entity_id, p_invoice, p_action, app_uid(), _actor_kind(), p_summary, coalesce(p_details, '{}'))
$$;

CREATE OR REPLACE FUNCTION _require(p_ok boolean, p_message text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  IF p_ok IS NOT TRUE THEN RAISE EXCEPTION '%', p_message USING ERRCODE = '42501'; END IF;
END $$;

-- ================================================================ audit triggers
-- Generic change log for master data, coding and configuration tables.
CREATE OR REPLACE FUNCTION _audit_row() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  o jsonb := CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END;
  n jsonb := CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END;
  r jsonb := coalesce(n, o);
  changes jsonb := '{}';
  k text;
  label text;
  inv uuid;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    FOR k IN SELECT jsonb_object_keys(n) LOOP
      IF k NOT IN ('updated_at', 'created_at') AND (o -> k) IS DISTINCT FROM (n -> k) THEN
        changes := changes || jsonb_build_object(k, jsonb_build_object('from', o -> k, 'to', n -> k));
      END IF;
    END LOOP;
    IF changes = '{}' THEN RETURN NULL; END IF;
  END IF;
  label := coalesce(r ->> 'code', r ->> 'number', r ->> 'name', r ->> 'email', '');
  inv := CASE WHEN TG_TABLE_NAME IN ('invoice_allocations', 'invoice_lines') THEN (r ->> 'invoice_id')::uuid END;
  INSERT INTO audit_events (org_id, entity_type, entity_id, invoice_id, action, actor_user_id, actor_kind, summary, details)
  VALUES ((r ->> 'org_id')::uuid, TG_TABLE_NAME,
    CASE WHEN r ? 'id' THEN (r ->> 'id')::uuid END, inv,
    lower(TG_OP), app_uid(), _actor_kind(),
    CASE TG_OP WHEN 'INSERT' THEN 'Added ' WHEN 'UPDATE' THEN 'Updated ' ELSE 'Deleted ' END || replace(TG_TABLE_NAME, '_', ' ') || CASE WHEN label <> '' THEN ' ' || label ELSE '' END
      || CASE WHEN TG_TABLE_NAME = 'invoice_allocations' THEN ' ($' || coalesce(r ->> 'amount', '0') || ')' ELSE '' END,
    CASE TG_OP WHEN 'UPDATE' THEN jsonb_build_object('changes', changes)
               WHEN 'INSERT' THEN jsonb_build_object('row', n)
               ELSE jsonb_build_object('row', o) END);
  RETURN NULL;
END $$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['vendors', 'projects', 'cost_types', 'gl_accounts', 'cost_codes', 'commitments',
    'commitment_lines', 'change_orders', 'invoice_allocations', 'approval_rules', 'org_settings', 'org_members'] LOOP
    EXECUTE format('CREATE TRIGGER audit_row AFTER INSERT OR UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION _audit_row()', t);
  END LOOP;
END $$;

-- Invoice header edits: a person changing a field marks it verified (confidence 1),
-- and the change is logged as a correction when it overwrites an AI-extracted value.
CREATE OR REPLACE FUNCTION _invoice_before_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  f text;
  o jsonb := to_jsonb(OLD);
  n jsonb := to_jsonb(NEW);
BEGIN
  NEW.updated_at := now();
  IF _actor_kind() = 'user' THEN
    FOREACH f IN ARRAY ARRAY['vendor_id', 'invoice_number', 'invoice_date', 'due_date', 'payment_terms', 'subtotal',
      'tax_amount', 'retainage_amount', 'total_amount', 'po_number', 'commitment_id', 'project_reference', 'currency'] LOOP
      IF (o -> f) IS DISTINCT FROM (n -> f) THEN
        NEW.field_confidence := NEW.field_confidence || jsonb_build_object(CASE f WHEN 'vendor_id' THEN 'vendor' ELSE f END, 1);
      END IF;
    END LOOP;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER invoice_before_update BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION _invoice_before_update();

CREATE OR REPLACE FUNCTION _invoice_after_write() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  f text;
  o jsonb;
  n jsonb := to_jsonb(NEW);
  changes jsonb := '{}';
  v_alias text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM _audit(NEW.org_id, 'invoice', NEW.id, NEW.id, 'created',
      'Invoice received' || coalesce(' (' || NEW.file_name || ')', '') || ' via ' || NEW.source, jsonb_build_object('source', NEW.source));
    RETURN NULL;
  END IF;
  o := to_jsonb(OLD);
  FOREACH f IN ARRAY ARRAY['vendor_id', 'vendor_name_extracted', 'invoice_number', 'invoice_date', 'due_date', 'payment_terms',
    'subtotal', 'tax_amount', 'retainage_amount', 'total_amount', 'po_number', 'commitment_id', 'project_reference',
    'description', 'currency'] LOOP
    IF (o -> f) IS DISTINCT FROM (n -> f) THEN
      changes := changes || jsonb_build_object(f, jsonb_build_object('from', o -> f, 'to', n -> f,
        'ai_value', OLD.ai_extraction -> f));
    END IF;
  END LOOP;
  IF changes <> '{}' THEN
    PERFORM _audit(NEW.org_id, 'invoice', NEW.id, NEW.id,
      CASE WHEN _actor_kind() = 'user' AND OLD.ai_extraction IS NOT NULL THEN 'field_corrected' ELSE 'fields_updated' END,
      CASE WHEN _actor_kind() = 'user' THEN 'Updated ' ELSE 'Filled ' END
        || (SELECT string_agg(replace(k, '_', ' '), ', ') FROM jsonb_object_keys(changes) k),
      jsonb_build_object('changes', changes));
  END IF;
  -- Learn vendor aliases from a person's vendor choice.
  IF _actor_kind() = 'user' AND NEW.vendor_id IS NOT NULL AND NEW.vendor_id IS DISTINCT FROM OLD.vendor_id
     AND NEW.vendor_name_extracted IS NOT NULL THEN
    v_alias := app_norm_name(NEW.vendor_name_extracted);
    IF v_alias IS NOT NULL AND v_alias <> (SELECT app_norm_name(name) FROM vendors WHERE id = NEW.vendor_id) THEN
      INSERT INTO vendor_aliases (org_id, vendor_id, alias, learned_from_invoice_id)
      VALUES (NEW.org_id, NEW.vendor_id, v_alias, NEW.id)
      ON CONFLICT (org_id, alias) DO UPDATE SET vendor_id = EXCLUDED.vendor_id, learned_from_invoice_id = EXCLUDED.learned_from_invoice_id;
      PERFORM _audit(NEW.org_id, 'vendor', NEW.vendor_id, NEW.id, 'alias_learned',
        'Learned that "' || NEW.vendor_name_extracted || '" refers to this vendor', '{}');
    END IF;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER invoice_after_write AFTER INSERT OR UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION _invoice_after_write();

-- ================================================================ organizations
CREATE OR REPLACE FUNCTION _current_user_identity() RETURNS TABLE (email text, name text, verified boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT lower(u.email), u.name, u."emailVerified" FROM neon_auth."user" u WHERE u.id::text = app_uid()
$$;

CREATE OR REPLACE FUNCTION _seed_org(p_org uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO org_settings (org_id) VALUES (p_org) ON CONFLICT DO NOTHING;
  -- Standard construction cost types; customers rename or extend them.
  INSERT INTO cost_types (org_id, code, name) VALUES
    (p_org, 'L', 'Labor'), (p_org, 'M', 'Material'), (p_org, 'S', 'Subcontract'),
    (p_org, 'E', 'Equipment'), (p_org, 'O', 'Other')
  ON CONFLICT DO NOTHING;
  INSERT INTO approval_rules (org_id, name, step_order, min_amount, approver_kind) VALUES
    (p_org, 'Project manager approves job costs', 1, 0, 'project_manager');
  INSERT INTO approval_rules (org_id, name, step_order, min_amount, approver_kind, approver_role) VALUES
    (p_org, 'Controller approves invoices of $10,000 or more', 2, 10000, 'role', 'controller');
END $$;

CREATE OR REPLACE FUNCTION create_organization(p_name text, p_legal_entity text DEFAULT NULL) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_org uuid;
  me record;
BEGIN
  PERFORM _require(app_uid() IS NOT NULL, 'Sign in first');
  PERFORM _require(length(trim(coalesce(p_name, ''))) > 0, 'Company name is required');
  SELECT * INTO me FROM _current_user_identity();
  PERFORM _require((SELECT count(*) FROM orgs WHERE created_by = app_uid()) < 10, 'You can create at most 10 companies');
  INSERT INTO orgs (name, legal_entity, created_by) VALUES (trim(p_name), nullif(trim(p_legal_entity), ''), app_uid()) RETURNING id INTO v_org;
  INSERT INTO org_members (org_id, user_id, email, display_name, role)
  VALUES (v_org, app_uid(), coalesce(me.email, ''), coalesce(me.name, ''), 'owner');
  PERFORM _seed_org(v_org);
  PERFORM _audit(v_org, 'org', v_org, NULL, 'created', 'Company workspace created', jsonb_build_object('name', p_name));
  RETURN v_org;
END $$;

-- Invitations are claimed by a signed-in user whose verified email matches.
CREATE OR REPLACE FUNCTION accept_invitations() RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  me record;
  inv record;
  joined int := 0;
  pending int;
BEGIN
  PERFORM _require(app_uid() IS NOT NULL, 'Sign in first');
  SELECT * INTO me FROM _current_user_identity();
  SELECT count(*) INTO pending FROM org_invites WHERE email = me.email AND accepted_at IS NULL;
  IF pending = 0 THEN RETURN jsonb_build_object('joined', 0, 'pending_unverified', 0); END IF;
  IF NOT coalesce(me.verified, false) THEN
    RETURN jsonb_build_object('joined', 0, 'pending_unverified', pending, 'email', me.email);
  END IF;
  FOR inv IN SELECT * FROM org_invites WHERE email = me.email AND accepted_at IS NULL FOR UPDATE LOOP
    INSERT INTO org_members (org_id, user_id, email, display_name, role, approval_limit)
    VALUES (inv.org_id, app_uid(), me.email, coalesce(me.name, ''), inv.role, inv.approval_limit)
    ON CONFLICT (org_id, user_id) DO NOTHING;
    UPDATE org_invites SET accepted_at = now() WHERE id = inv.id;
    PERFORM _audit(inv.org_id, 'member', NULL, NULL, 'joined', me.email || ' joined as ' || inv.role, '{}');
    joined := joined + 1;
  END LOOP;
  RETURN jsonb_build_object('joined', joined, 'pending_unverified', 0);
END $$;

CREATE OR REPLACE FUNCTION invite_member(p_org uuid, p_email text, p_role text, p_approval_limit numeric DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_email text := lower(trim(p_email));
BEGIN
  PERFORM _require(app_can(p_org, 'owner'), 'Only an owner can invite people');
  PERFORM _require(v_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$', 'Enter a valid email address');
  PERFORM _require(p_role IN ('owner', 'controller', 'ap_clerk', 'project_manager', 'viewer'), 'Unknown role');
  PERFORM _require(NOT EXISTS (SELECT 1 FROM org_members WHERE org_id = p_org AND lower(email) = v_email), 'That person is already a member');
  INSERT INTO org_invites (org_id, email, role, approval_limit, invited_by)
  VALUES (p_org, v_email, p_role, p_approval_limit, app_uid())
  ON CONFLICT (org_id, email) DO UPDATE SET role = EXCLUDED.role, approval_limit = EXCLUDED.approval_limit, accepted_at = NULL;
  PERFORM _audit(p_org, 'member', NULL, NULL, 'invited', 'Invited ' || v_email || ' as ' || p_role, '{}');
  RETURN jsonb_build_object('invited', v_email);
END $$;

CREATE OR REPLACE FUNCTION revoke_invite(p_invite uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v record;
BEGIN
  SELECT * INTO v FROM org_invites WHERE id = p_invite;
  PERFORM _require(v.id IS NOT NULL AND app_can(v.org_id, 'owner'), 'Only an owner can revoke invitations');
  DELETE FROM org_invites WHERE id = p_invite AND accepted_at IS NULL;
  PERFORM _audit(v.org_id, 'member', NULL, NULL, 'invite_revoked', 'Revoked invitation for ' || v.email, '{}');
END $$;

CREATE OR REPLACE FUNCTION update_member(p_org uuid, p_user text, p_role text, p_approval_limit numeric, p_active boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM _require(app_can(p_org, 'owner'), 'Only an owner can change roles');
  PERFORM _require(p_role IN ('owner', 'controller', 'ap_clerk', 'project_manager', 'viewer'), 'Unknown role');
  PERFORM _require(p_approval_limit IS NULL OR p_approval_limit >= 0, 'Approval limit cannot be negative');
  UPDATE org_members SET role = p_role, approval_limit = p_approval_limit, active = p_active
  WHERE org_id = p_org AND user_id = p_user;
  PERFORM _require(FOUND, 'Member not found');
  PERFORM _require(EXISTS (SELECT 1 FROM org_members WHERE org_id = p_org AND role = 'owner' AND active),
    'A company needs at least one active owner');
END $$;

-- ================================================================ matching & controls engine
-- Deterministic checks. The AI proposes values; this engine decides what is
-- consistent, matched, duplicated or over-committed, and records why.
CREATE OR REPLACE FUNCTION _invoice_checks(p_invoice uuid, p_log boolean DEFAULT true) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  st org_settings;
  ven vendors;
  com commitments;
  ex jsonb := '[]';
  matched jsonb := '{}';
  v_id uuid;
  v_count int;
  r record;
  k text;
  v_alloc_sum numeric;
  v_alloc_count int;
  v_lines_sum numeric;
  v_revised numeric;
  v_billed numeric;
  v_overage numeric;
  v_tol numeric;
  v_blocking int;
  v_warn int;
  v_run uuid;
  e jsonb;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  IF inv.id IS NULL THEN RAISE EXCEPTION 'Invoice not found'; END IF;
  SELECT * INTO st FROM org_settings WHERE org_id = inv.org_id;

  -- ---- vendor matching (exact normalized name, learned alias, or tax id)
  IF inv.vendor_id IS NULL AND inv.vendor_name_extracted IS NOT NULL AND inv.status = 'needs_review' THEN
    SELECT count(DISTINCT vid), min(vid::text)::uuid INTO v_count, v_id FROM (
      SELECT id AS vid FROM vendors WHERE org_id = inv.org_id AND status = 'active'
        AND app_norm_name(name) = app_norm_name(inv.vendor_name_extracted)
      UNION
      SELECT vendor_id FROM vendor_aliases WHERE org_id = inv.org_id AND alias = app_norm_name(inv.vendor_name_extracted)
    ) m;
    IF v_count = 1 THEN
      PERFORM set_config('app.actor_kind', 'system', true);
      UPDATE invoices SET vendor_id = v_id WHERE id = inv.id;
      matched := matched || jsonb_build_object('vendor', jsonb_build_object('vendor_id', v_id, 'method', 'name_or_alias'));
      inv.vendor_id := v_id;
    END IF;
  END IF;
  IF inv.vendor_id IS NOT NULL THEN SELECT * INTO ven FROM vendors WHERE id = inv.vendor_id; END IF;

  -- ---- commitment matching by PO / subcontract number
  IF inv.commitment_id IS NULL AND inv.po_number IS NOT NULL AND inv.status = 'needs_review' THEN
    SELECT count(*), min(id::text)::uuid INTO v_count, v_id FROM commitments
    WHERE org_id = inv.org_id AND app_norm_ref(number) = app_norm_ref(inv.po_number);
    IF v_count = 1 THEN
      PERFORM set_config('app.actor_kind', 'system', true);
      UPDATE invoices SET commitment_id = v_id WHERE id = inv.id;
      matched := matched || jsonb_build_object('commitment', jsonb_build_object('commitment_id', v_id, 'method', 'po_number'));
      inv.commitment_id := v_id;
    END IF;
  END IF;
  IF inv.commitment_id IS NOT NULL THEN SELECT * INTO com FROM commitments WHERE id = inv.commitment_id; END IF;

  -- Rule-based coding when nothing has been proposed: a single-line commitment fully defines the coding.
  SELECT count(*) INTO v_alloc_count FROM invoice_allocations WHERE invoice_id = inv.id;
  IF v_alloc_count = 0 AND com.id IS NOT NULL AND inv.total_amount IS NOT NULL AND inv.status = 'needs_review'
     AND (SELECT count(*) FROM commitment_lines WHERE commitment_id = com.id) = 1 THEN
    PERFORM set_config('app.actor_kind', 'system', true);
    INSERT INTO invoice_allocations (org_id, invoice_id, project_id, cost_code_id, cost_type_id, gl_account_id, commitment_line_id, amount, source, confidence, rationale)
    SELECT inv.org_id, inv.id, com.project_id, l.cost_code_id, coalesce(l.cost_type_id, ven.default_cost_type_id), ven.default_gl_account_id, l.id,
      inv.total_amount, 'rule', 1, 'Coded from the only line of ' || com.number || '.'
    FROM commitment_lines l WHERE l.commitment_id = com.id;
    matched := matched || jsonb_build_object('coding', 'single_line_commitment');
  END IF;
  PERFORM set_config('app.actor_kind', '', true);

  -- ---- required fields
  IF inv.vendor_id IS NULL THEN
    IF inv.vendor_name_extracted IS NOT NULL THEN
      ex := ex || jsonb_build_object('code', 'vendor_unmatched', 'fp', 'vendor_unmatched', 'severity', 'blocking', 'overridable', false,
        'title', 'Vendor not matched',
        'detail', format('The invoice names "%s", which matches no active vendor or learned alias. Pick the vendor (the system learns the alias) or add the vendor first.', inv.vendor_name_extracted),
        'evidence', jsonb_build_object('extracted_name', inv.vendor_name_extracted,
          'similar_vendors', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name)), '[]') FROM (
            SELECT id, code, name FROM vendors WHERE org_id = inv.org_id AND status = 'active'
              AND app_norm_name(name) LIKE split_part(app_norm_name(inv.vendor_name_extracted), ' ', 1) || '%' LIMIT 5) s)));
    ELSE
      ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:vendor', 'severity', 'blocking', 'overridable', false,
        'title', 'Vendor missing', 'detail', 'No vendor was found on the document. Select the vendor.', 'evidence', '{}');
    END IF;
  END IF;
  IF inv.invoice_number IS NULL THEN
    ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:invoice_number', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice number missing', 'detail', 'An invoice number is required for duplicate control and posting. Enter it from the document.', 'evidence', '{}');
  END IF;
  IF inv.invoice_date IS NULL THEN
    ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:invoice_date', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice date missing', 'detail', 'Enter the invoice date from the document.', 'evidence', '{}');
  END IF;
  IF inv.total_amount IS NULL THEN
    ex := ex || jsonb_build_object('code', 'missing_field', 'fp', 'missing:total_amount', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice total missing', 'detail', 'Enter the invoice total from the document.', 'evidence', '{}');
  END IF;

  -- ---- low-confidence extraction
  FOR k IN SELECT key FROM jsonb_each(inv.field_confidence)
           WHERE jsonb_typeof(value) = 'number' AND value::text::numeric < st.low_confidence_threshold LOOP
    ex := ex || jsonb_build_object('code', 'low_confidence', 'fp', 'low_conf:' || k, 'severity', 'warning', 'overridable', true,
      'title', 'Check ' || replace(k, '_', ' ') || ' against the document',
      'detail', format('The AI read this field with %s%% confidence (threshold %s%%). Confirm or correct it; editing the field marks it verified.',
        round((inv.field_confidence ->> k)::numeric * 100), round(st.low_confidence_threshold * 100)),
      'evidence', jsonb_build_object('field', k, 'confidence', inv.field_confidence -> k, 'ai_value', inv.ai_extraction -> k));
  END LOOP;

  -- ---- arithmetic consistency
  IF inv.subtotal IS NOT NULL AND inv.total_amount IS NOT NULL
     AND abs(inv.subtotal + coalesce(inv.tax_amount, 0) - inv.total_amount) > 0.01 THEN
    ex := ex || jsonb_build_object('code', 'totals_mismatch', 'fp', 'totals:header', 'severity', 'warning', 'overridable', true,
      'title', 'Subtotal plus tax does not equal total',
      'detail', format('Subtotal %s + tax %s = %s, but the total is %s (difference %s).', inv.subtotal, coalesce(inv.tax_amount, 0),
        inv.subtotal + coalesce(inv.tax_amount, 0), inv.total_amount, inv.total_amount - inv.subtotal - coalesce(inv.tax_amount, 0)),
      'evidence', jsonb_build_object('subtotal', inv.subtotal, 'tax', inv.tax_amount, 'total', inv.total_amount));
  END IF;
  SELECT sum(amount) INTO v_lines_sum FROM invoice_lines WHERE invoice_id = inv.id;
  IF v_lines_sum IS NOT NULL AND coalesce(inv.subtotal, inv.total_amount) IS NOT NULL
     AND abs(v_lines_sum - coalesce(inv.subtotal, inv.total_amount - coalesce(inv.tax_amount, 0))) > 0.01 THEN
    ex := ex || jsonb_build_object('code', 'totals_mismatch', 'fp', 'totals:lines', 'severity', 'warning', 'overridable', true,
      'title', 'Line items do not add up',
      'detail', format('Line items sum to %s; the invoice states %s before tax.', v_lines_sum, coalesce(inv.subtotal, inv.total_amount - coalesce(inv.tax_amount, 0))),
      'evidence', jsonb_build_object('lines_sum', v_lines_sum, 'subtotal', inv.subtotal));
  END IF;

  -- ---- dates
  IF inv.due_date IS NOT NULL AND inv.invoice_date IS NOT NULL AND inv.due_date < inv.invoice_date THEN
    ex := ex || jsonb_build_object('code', 'date_inconsistent', 'fp', 'date:due_before', 'severity', 'warning', 'overridable', true,
      'title', 'Due date is before invoice date', 'detail', format('Invoice date %s, due date %s.', inv.invoice_date, inv.due_date), 'evidence', '{}');
  END IF;
  IF inv.invoice_date > current_date + 1 THEN
    ex := ex || jsonb_build_object('code', 'date_inconsistent', 'fp', 'date:future', 'severity', 'warning', 'overridable', true,
      'title', 'Invoice is dated in the future', 'detail', format('Invoice date %s is after today.', inv.invoice_date), 'evidence', '{}');
  END IF;

  -- ---- duplicates
  IF inv.vendor_id IS NOT NULL AND app_norm_ref(inv.invoice_number) IS NOT NULL THEN
    FOR r IN SELECT id, invoice_number, total_amount, invoice_date, status FROM invoices
             WHERE org_id = inv.org_id AND id <> inv.id AND vendor_id = inv.vendor_id AND status <> 'void'
               AND app_norm_ref(invoice_number) = app_norm_ref(inv.invoice_number) LOOP
      ex := ex || jsonb_build_object('code', 'duplicate', 'fp', 'dup:' || r.id,
        'severity', CASE WHEN r.status = 'rejected' THEN 'warning' ELSE 'blocking' END, 'overridable', true, 'resolver', 'admin',
        'title', 'Duplicate invoice number for this vendor',
        'detail', format('%s already has invoice %s (%s, %s, status %s). Paying both would double-pay the vendor. Void this copy, or a controller can override with a reason if the vendor really reused the number.',
          ven.name, r.invoice_number, r.invoice_date, r.total_amount, r.status),
        'evidence', jsonb_build_object('other_invoice_id', r.id, 'other_number', r.invoice_number, 'other_total', r.total_amount, 'other_status', r.status));
    END LOOP;
  END IF;
  IF inv.vendor_id IS NOT NULL AND inv.total_amount IS NOT NULL AND inv.invoice_date IS NOT NULL THEN
    FOR r IN SELECT id, invoice_number, total_amount, invoice_date, status FROM invoices
             WHERE org_id = inv.org_id AND id <> inv.id AND vendor_id = inv.vendor_id AND status NOT IN ('void', 'rejected')
               AND total_amount = inv.total_amount
               AND abs(invoice_date - inv.invoice_date) <= st.possible_duplicate_days
               AND app_norm_ref(invoice_number) IS DISTINCT FROM app_norm_ref(inv.invoice_number) LOOP
      ex := ex || jsonb_build_object('code', 'possible_duplicate', 'fp', 'pdup:' || r.id, 'severity', 'warning', 'overridable', true,
        'title', 'Possible duplicate: same vendor and amount',
        'detail', format('Invoice %s from the same vendor is also %s, dated %s (within %s days). Confirm these are separate charges.',
          r.invoice_number, r.total_amount, r.invoice_date, st.possible_duplicate_days),
        'evidence', jsonb_build_object('other_invoice_id', r.id, 'other_number', r.invoice_number, 'other_date', r.invoice_date));
    END LOOP;
  END IF;

  IF ven.id IS NOT NULL AND ven.status = 'inactive' THEN
    ex := ex || jsonb_build_object('code', 'vendor_inactive', 'fp', 'vendor_inactive', 'severity', 'warning', 'overridable', true,
      'title', 'Vendor is inactive', 'detail', ven.name || ' is marked inactive in the vendor list.', 'evidence', jsonb_build_object('vendor_id', ven.id));
  END IF;

  -- ---- commitment (PO / subcontract) matching
  IF com.id IS NULL THEN
    IF inv.po_number IS NOT NULL THEN
      ex := ex || jsonb_build_object('code', 'po_not_found', 'fp', 'po_not_found:' || coalesce(app_norm_ref(inv.po_number), ''),
        'severity', CASE WHEN st.require_po THEN 'blocking' ELSE 'warning' END, 'overridable', true, 'resolver', 'admin',
        'title', 'Referenced PO / subcontract not found',
        'detail', format('The invoice references "%s", but no commitment has that number. Import the commitment or pick the right one.', inv.po_number),
        'evidence', jsonb_build_object('po_number', inv.po_number));
    ELSIF st.require_po AND coalesce(inv.total_amount, 0) >= st.require_po_over_amount THEN
      ex := ex || jsonb_build_object('code', 'po_required', 'fp', 'po_required', 'severity', 'blocking', 'overridable', true, 'resolver', 'admin',
        'title', 'Purchase order or subcontract required',
        'detail', format('Company policy requires a commitment for invoices of %s or more. Link the commitment, or a controller can override with a reason.', st.require_po_over_amount),
        'evidence', jsonb_build_object('policy_threshold', st.require_po_over_amount, 'total', inv.total_amount));
    END IF;
  ELSE
    IF inv.vendor_id IS NOT NULL AND com.vendor_id <> inv.vendor_id THEN
      ex := ex || jsonb_build_object('code', 'po_vendor_mismatch', 'fp', 'po_vendor:' || com.id, 'severity', 'blocking', 'overridable', true, 'resolver', 'admin',
        'title', 'Commitment belongs to a different vendor',
        'detail', format('%s is issued to %s, not to %s.', com.number, (SELECT name FROM vendors WHERE id = com.vendor_id), ven.name),
        'evidence', jsonb_build_object('commitment_id', com.id, 'commitment_vendor_id', com.vendor_id, 'invoice_vendor_id', inv.vendor_id));
    END IF;
    IF com.status = 'closed' THEN
      ex := ex || jsonb_build_object('code', 'po_closed', 'fp', 'po_closed:' || com.id, 'severity', 'warning', 'overridable', true,
        'title', 'Commitment is closed', 'detail', com.number || ' is closed; billing against it is unusual.', 'evidence', jsonb_build_object('commitment_id', com.id));
    END IF;
    SELECT com.original_amount + coalesce(sum(amount) FILTER (WHERE status = 'approved'), 0) INTO v_revised
    FROM change_orders WHERE commitment_id = com.id;
    SELECT coalesce(sum(total_amount), 0) INTO v_billed FROM invoices
    WHERE commitment_id = com.id AND id <> inv.id AND status IN ('pending_approval', 'approved');
    v_overage := v_billed + coalesce(inv.total_amount, 0) - v_revised;
    v_tol := least(v_revised * st.variance_pct / 100, st.variance_amount);
    IF v_overage > v_tol + 0.005 THEN
      ex := ex || jsonb_build_object('code', 'overbilling', 'fp', 'over:' || com.id || ':' || round(v_overage, 2),
        'severity', 'blocking', 'overridable', true, 'resolver', 'admin',
        'title', 'Billing exceeds the commitment',
        'detail', format('%s is committed at %s (original %s plus approved change orders). Already billed: %s. This invoice: %s. That is %s over, beyond the allowed variance of %s (the lesser of %s%% or %s). Get a change order approved, short-pay, or a controller can override with a reason.',
          com.number, v_revised, com.original_amount, v_billed, inv.total_amount, round(v_overage, 2), round(v_tol, 2), st.variance_pct, st.variance_amount),
        'evidence', jsonb_build_object('commitment_id', com.id, 'commitment_number', com.number, 'original', com.original_amount,
          'revised', v_revised, 'billed_to_date', v_billed, 'this_invoice', inv.total_amount, 'overage', round(v_overage, 2), 'tolerance', round(v_tol, 2)));
    ELSIF v_overage > 0 THEN
      ex := ex || jsonb_build_object('code', 'overbilling_within_tolerance', 'fp', 'over_tol:' || com.id, 'severity', 'info', 'overridable', true,
        'title', 'Slightly over commitment, within tolerance',
        'detail', format('Billing exceeds %s by %s, inside the allowed variance of %s.', com.number, round(v_overage, 2), round(v_tol, 2)),
        'evidence', jsonb_build_object('commitment_id', com.id, 'overage', round(v_overage, 2), 'tolerance', round(v_tol, 2)));
    END IF;
    FOR r IN SELECT number, amount FROM change_orders WHERE commitment_id = com.id AND status = 'pending' LOOP
      ex := ex || jsonb_build_object('code', 'pending_change_order', 'fp', 'pco:' || com.id || ':' || r.number, 'severity', 'info', 'overridable', true,
        'title', 'Pending change order ' || r.number,
        'detail', format('Change order %s for %s on %s is not approved yet and is not counted in the committed amount.', r.number, r.amount, com.number),
        'evidence', jsonb_build_object('commitment_id', com.id, 'change_order', r.number, 'amount', r.amount));
    END LOOP;
    IF com.retainage_pct > 0 AND inv.retainage_amount IS NULL AND inv.total_amount IS NOT NULL THEN
      ex := ex || jsonb_build_object('code', 'retainage_expected', 'fp', 'ret:' || com.id, 'severity', 'info', 'overridable', true,
        'title', 'Retainage expected',
        'detail', format('%s carries %s%% retainage (%s on this invoice), but no retainage is recorded.', com.number, com.retainage_pct,
          round(inv.total_amount * com.retainage_pct / 100, 2)),
        'evidence', jsonb_build_object('retainage_pct', com.retainage_pct));
    END IF;
    -- Cost-code level: committed vs billed per cost code on this commitment.
    FOR r IN
      WITH committed AS (
        SELECT cost_code_id, sum(amount) AS amt FROM commitment_lines WHERE commitment_id = com.id AND cost_code_id IS NOT NULL GROUP BY 1),
      billed AS (
        SELECT a.cost_code_id, sum(a.amount) AS amt FROM invoice_allocations a JOIN invoices i ON i.id = a.invoice_id
        WHERE i.commitment_id = com.id AND (i.id = inv.id OR i.status IN ('pending_approval', 'approved')) GROUP BY 1)
      SELECT b.cost_code_id, cc.code, b.amt AS billed, c.amt AS committed
      FROM billed b LEFT JOIN committed c USING (cost_code_id) LEFT JOIN cost_codes cc ON cc.id = b.cost_code_id
      WHERE b.cost_code_id IS NOT NULL AND EXISTS (SELECT 1 FROM committed) AND (c.amt IS NULL OR b.amt > c.amt + 0.005)
    LOOP
      ex := ex || jsonb_build_object('code', 'cost_code_outside_commitment', 'fp', 'cc_over:' || com.id || ':' || r.cost_code_id || ':' || round(r.billed, 2),
        'severity', 'warning', 'overridable', true,
        'title', CASE WHEN r.committed IS NULL THEN 'Cost code ' || r.code || ' is not on ' || com.number ELSE 'Cost code ' || r.code || ' billed beyond its commitment line' END,
        'detail', CASE WHEN r.committed IS NULL THEN format('This invoice codes cost to %s, which has no line on %s.', r.code, com.number)
          ELSE format('Billed to date on %s for %s: %s against %s committed.', com.number, r.code, r.billed, r.committed) END,
        'evidence', jsonb_build_object('commitment_id', com.id, 'cost_code', r.code, 'billed', r.billed, 'committed', r.committed));
    END LOOP;
  END IF;

  -- ---- allocations (job / cost code / cost type / GL coding)
  SELECT coalesce(sum(amount), 0), count(*) INTO v_alloc_sum, v_alloc_count FROM invoice_allocations WHERE invoice_id = inv.id;
  IF v_alloc_count = 0 THEN
    ex := ex || jsonb_build_object('code', 'no_allocations', 'fp', 'no_alloc', 'severity', 'blocking', 'overridable', false,
      'title', 'Invoice is not coded', 'detail', 'Add at least one allocation with project, cost code, cost type and GL account.', 'evidence', '{}');
  ELSIF inv.total_amount IS NOT NULL AND abs(v_alloc_sum - inv.total_amount) > 0.005 THEN
    ex := ex || jsonb_build_object('code', 'allocation_unbalanced', 'fp', 'alloc_balance', 'severity', 'blocking', 'overridable', false,
      'title', 'Allocations do not equal the invoice total',
      'detail', format('Allocations total %s; the invoice total is %s (difference %s).', v_alloc_sum, inv.total_amount, inv.total_amount - v_alloc_sum),
      'evidence', jsonb_build_object('allocated', v_alloc_sum, 'total', inv.total_amount, 'difference', inv.total_amount - v_alloc_sum));
  END IF;
  FOR r IN SELECT a.*, p.code AS pcode, p.status AS pstatus, cc.project_id AS cc_project, cc.code AS cccode
           FROM invoice_allocations a LEFT JOIN projects p ON p.id = a.project_id LEFT JOIN cost_codes cc ON cc.id = a.cost_code_id
           WHERE a.invoice_id = inv.id LOOP
    IF r.project_id IS NULL OR r.cost_code_id IS NULL OR r.cost_type_id IS NULL OR r.gl_account_id IS NULL THEN
      ex := ex || jsonb_build_object('code', 'allocation_incomplete', 'fp', 'alloc_incomplete:' || r.id, 'severity', 'blocking', 'overridable', false,
        'title', 'Allocation is missing coding',
        'detail', format('The %s allocation is missing: %s.', r.amount, concat_ws(', ',
          CASE WHEN r.project_id IS NULL THEN 'project' END, CASE WHEN r.cost_code_id IS NULL THEN 'cost code' END,
          CASE WHEN r.cost_type_id IS NULL THEN 'cost type' END, CASE WHEN r.gl_account_id IS NULL THEN 'GL account' END)),
        'evidence', jsonb_build_object('allocation_id', r.id));
    END IF;
    IF r.cc_project IS NOT NULL AND r.project_id IS NOT NULL AND r.cc_project <> r.project_id THEN
      ex := ex || jsonb_build_object('code', 'cost_code_wrong_project', 'fp', 'cc_proj:' || r.id, 'severity', 'blocking', 'overridable', false,
        'title', 'Cost code belongs to another project',
        'detail', format('Cost code %s is specific to a different project than %s.', r.cccode, r.pcode), 'evidence', jsonb_build_object('allocation_id', r.id));
    END IF;
    IF r.pstatus = 'closed' THEN
      ex := ex || jsonb_build_object('code', 'project_closed', 'fp', 'proj_closed:' || r.project_id, 'severity', 'warning', 'overridable', true,
        'title', 'Project ' || r.pcode || ' is closed', 'detail', 'Cost is being coded to a closed project.', 'evidence', jsonb_build_object('project_id', r.project_id));
    END IF;
    IF com.id IS NOT NULL AND r.project_id IS NOT NULL AND r.project_id <> com.project_id THEN
      ex := ex || jsonb_build_object('code', 'project_outside_commitment', 'fp', 'proj_com:' || r.id, 'severity', 'warning', 'overridable', true,
        'title', 'Allocation project differs from the commitment',
        'detail', format('%s is for a different project than %s.', com.number, r.pcode), 'evidence', jsonb_build_object('allocation_id', r.id, 'commitment_id', com.id));
    END IF;
  END LOOP;

  -- ---- reconcile exception records with this run
  FOR e IN SELECT * FROM jsonb_array_elements(ex) LOOP
    INSERT INTO invoice_exceptions AS x (org_id, invoice_id, code, fingerprint, severity, overridable, title, detail, evidence, resolver)
    VALUES (inv.org_id, inv.id, e ->> 'code', e ->> 'fp', e ->> 'severity', (e ->> 'overridable')::boolean, e ->> 'title', e ->> 'detail',
      coalesce(e -> 'evidence', '{}'), coalesce(e ->> 'resolver', CASE WHEN e ->> 'severity' = 'blocking' AND (e ->> 'overridable')::boolean THEN 'admin' ELSE 'ap' END))
    ON CONFLICT (invoice_id, fingerprint) DO UPDATE SET
      severity = EXCLUDED.severity, overridable = EXCLUDED.overridable, title = EXCLUDED.title, detail = EXCLUDED.detail,
      evidence = EXCLUDED.evidence, resolver = EXCLUDED.resolver, updated_at = now(),
      status = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.status ELSE 'open' END,
      resolution_note = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.resolution_note END,
      resolved_by = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.resolved_by END,
      resolved_at = CASE WHEN x.status IN ('overridden', 'acknowledged') THEN x.resolved_at END;
  END LOOP;
  UPDATE invoice_exceptions SET status = 'resolved', resolution_note = 'Cleared on re-check: the condition is no longer present.',
    resolved_at = now(), resolved_by = NULL, updated_at = now()
  WHERE invoice_id = inv.id AND status <> 'resolved'
    AND fingerprint NOT IN (SELECT e2 ->> 'fp' FROM jsonb_array_elements(ex) e2);

  SELECT count(*) FILTER (WHERE severity = 'blocking' AND status = 'open'), count(*) FILTER (WHERE severity = 'warning' AND status = 'open')
  INTO v_blocking, v_warn FROM invoice_exceptions WHERE invoice_id = inv.id;

  IF p_log THEN
    INSERT INTO agent_runs (org_id, agent, kind, invoice_id, status, summary, input, output, triggered_by, finished_at)
    VALUES (inv.org_id, 'matching_engine', 'rules', inv.id, CASE WHEN v_blocking > 0 THEN 'needs_human' ELSE 'succeeded' END,
      format('Checked invoice %s: %s blocking, %s warnings', coalesce(inv.invoice_number, '(no number)'), v_blocking, v_warn),
      jsonb_build_object('invoice_id', inv.id), jsonb_build_object('matched', matched, 'exceptions', ex), app_uid(), now())
    RETURNING id INTO v_run;
  END IF;
  RETURN jsonb_build_object('blocking', v_blocking, 'warnings', v_warn, 'matched', matched, 'exception_count', jsonb_array_length(ex));
END $$;

CREATE OR REPLACE FUNCTION run_invoice_checks(p_invoice uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_org uuid;
BEGIN
  SELECT org_id INTO v_org FROM invoices WHERE id = p_invoice;
  PERFORM _require(v_org IS NOT NULL AND app_can(v_org, 'ap'), 'You do not have permission to process invoices');
  RETURN _invoice_checks(p_invoice, true);
END $$;

-- ================================================================ AI intake agent entry points
-- The intake agent runs as the signed-in user and may only use these functions
-- to record what it read. It cannot submit, approve, export or override.
CREATE OR REPLACE FUNCTION agent_begin_extraction(p_invoice uuid, p_session_id text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  ctx jsonb;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN
    RETURN jsonb_build_object('already_processed', true);
  END IF;
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  PERFORM set_config('app.actor_kind', 'agent', true);
  UPDATE invoices SET extraction_status = 'running', extraction_started_at = now(), extraction_error = NULL,
    agent_session_id = coalesce(p_session_id, agent_session_id)
  WHERE id = inv.id;
  INSERT INTO agent_runs (org_id, agent, kind, invoice_id, status, summary, input, triggered_by, session_id)
  VALUES (inv.org_id, 'invoice_intake', 'ai', inv.id, 'running', 'Reading ' || coalesce(inv.file_name, 'invoice'),
    jsonb_build_object('upload_id', inv.upload_id, 'file_name', inv.file_name), app_uid(), p_session_id);
  SELECT jsonb_build_object(
    'invoice', jsonb_build_object('id', inv.id, 'upload_id', inv.upload_id, 'file_name', inv.file_name),
    'vendors', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', v.id, 'code', v.code, 'name', v.name, 'tax_id', v.tax_id,
        'aliases', (SELECT jsonb_agg(alias) FROM vendor_aliases a WHERE a.vendor_id = v.id))), '[]')
      FROM (SELECT * FROM vendors WHERE org_id = inv.org_id AND status = 'active' ORDER BY name LIMIT 1000) v),
    'projects', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name, 'address', address)), '[]')
      FROM projects WHERE org_id = inv.org_id AND status = 'active'),
    'cost_codes', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name, 'project_id', project_id)), '[]')
      FROM (SELECT * FROM cost_codes WHERE org_id = inv.org_id ORDER BY code LIMIT 3000) c),
    'cost_types', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name)), '[]') FROM cost_types WHERE org_id = inv.org_id),
    'gl_accounts', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', id, 'code', code, 'name', name)), '[]') FROM gl_accounts WHERE org_id = inv.org_id AND active),
    'open_commitments', (SELECT coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'number', c.number, 'kind', c.kind, 'vendor_id', c.vendor_id,
        'project_id', c.project_id, 'amount', c.original_amount,
        'lines', (SELECT jsonb_agg(jsonb_build_object('line_no', l.line_no, 'description', l.description, 'cost_code_id', l.cost_code_id,
            'cost_type_id', l.cost_type_id, 'amount', l.amount) ORDER BY l.line_no) FROM commitment_lines l WHERE l.commitment_id = c.id))), '[]')
      FROM commitments c WHERE c.org_id = inv.org_id AND c.status = 'open'),
    -- How this company has coded each vendor before: the strongest signal for coding suggestions.
    'vendor_coding_history', (SELECT coalesce(jsonb_agg(h), '[]') FROM (
      SELECT i.vendor_id, a.project_id, a.cost_code_id, a.cost_type_id, a.gl_account_id, count(*) AS times, max(i.invoice_date) AS last_used
      FROM invoice_allocations a JOIN invoices i ON i.id = a.invoice_id
      WHERE i.org_id = inv.org_id AND i.status = 'approved'
      GROUP BY 1, 2, 3, 4, 5 ORDER BY times DESC LIMIT 400) h)
  ) INTO ctx;
  RETURN ctx;
END $$;

CREATE OR REPLACE FUNCTION _uuid_in_org(p_table text, p_org uuid, p_value text) RETURNS uuid
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v uuid;
BEGIN
  IF p_value IS NULL OR p_value !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' THEN RETURN NULL; END IF;
  EXECUTE format('SELECT id FROM %I WHERE id = $1 AND org_id = $2', p_table) INTO v USING p_value::uuid, p_org;
  RETURN v;
END $$;

-- payload: { vendor_name, vendor_id?, invoice_number, invoice_date, due_date, payment_terms, currency,
--   subtotal, tax_amount, retainage_amount, total_amount, po_number, project_reference, description, summary,
--   confidence: {field: 0..1}, lines: [{description, quantity, unit_price, amount}],
--   allocations: [{project_id, cost_code_id, cost_type_id, gl_account_id, amount, confidence, rationale}] }
CREATE OR REPLACE FUNCTION agent_submit_extraction(p_invoice uuid, p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  conf jsonb := '{}';
  k text;
  l jsonb;
  n int := 0;
  a jsonb;
  checks jsonb;
  v_vendor uuid;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN RETURN jsonb_build_object('already_processed', true); END IF;
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  PERFORM _require(jsonb_typeof(p) = 'object', 'Payload must be a JSON object');
  PERFORM set_config('app.actor_kind', 'agent', true);

  FOR k IN SELECT key FROM jsonb_each(coalesce(p -> 'confidence', '{}')) LOOP
    IF jsonb_typeof(p -> 'confidence' -> k) = 'number' THEN
      conf := conf || jsonb_build_object(CASE k WHEN 'vendor_name' THEN 'vendor' ELSE k END,
        greatest(0, least(1, (p -> 'confidence' ->> k)::numeric)));
    END IF;
  END LOOP;
  v_vendor := _uuid_in_org('vendors', inv.org_id, p ->> 'vendor_id');

  -- Fill only what a person has not already entered; never overwrite their work.
  UPDATE invoices SET
    vendor_name_extracted = coalesce(vendor_name_extracted, nullif(trim(p ->> 'vendor_name'), '')),
    vendor_id = coalesce(vendor_id, v_vendor),
    invoice_number = coalesce(invoice_number, nullif(trim(p ->> 'invoice_number'), '')),
    invoice_date = coalesce(invoice_date, _date(p ->> 'invoice_date')),
    due_date = coalesce(due_date, _date(p ->> 'due_date')),
    payment_terms = coalesce(payment_terms, nullif(trim(p ->> 'payment_terms'), '')),
    currency = coalesce(nullif(upper(trim(p ->> 'currency')), ''), currency),
    subtotal = coalesce(subtotal, _num(p ->> 'subtotal')),
    tax_amount = coalesce(tax_amount, _num(p ->> 'tax_amount')),
    retainage_amount = coalesce(retainage_amount, _num(p ->> 'retainage_amount')),
    total_amount = coalesce(total_amount, _num(p ->> 'total_amount')),
    po_number = coalesce(po_number, nullif(trim(p ->> 'po_number'), '')),
    project_reference = coalesce(project_reference, nullif(trim(p ->> 'project_reference'), '')),
    description = coalesce(description, nullif(trim(p ->> 'description'), '')),
    field_confidence = conf || field_confidence,
    ai_extraction = p,
    ai_summary = nullif(trim(p ->> 'summary'), ''),
    extraction_status = 'succeeded',
    extraction_error = NULL
  WHERE id = inv.id;

  IF NOT EXISTS (SELECT 1 FROM invoice_lines WHERE invoice_id = inv.id) THEN
    FOR l IN SELECT * FROM jsonb_array_elements(CASE WHEN jsonb_typeof(p -> 'lines') = 'array' THEN p -> 'lines' ELSE '[]' END) LOOP
      n := n + 1;
      INSERT INTO invoice_lines (org_id, invoice_id, line_no, description, quantity, unit_price, amount)
      VALUES (inv.org_id, inv.id, n, left(l ->> 'description', 1000), _num(l ->> 'quantity'), _num(l ->> 'unit_price'), _num(l ->> 'amount'));
    END LOOP;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM invoice_allocations WHERE invoice_id = inv.id) THEN
    FOR a IN SELECT * FROM jsonb_array_elements(CASE WHEN jsonb_typeof(p -> 'allocations') = 'array' THEN p -> 'allocations' ELSE '[]' END) LOOP
      IF _num(a ->> 'amount') IS NOT NULL THEN
        INSERT INTO invoice_allocations (org_id, invoice_id, project_id, cost_code_id, cost_type_id, gl_account_id, amount, description, source, confidence, rationale)
        VALUES (inv.org_id, inv.id,
          _uuid_in_org('projects', inv.org_id, a ->> 'project_id'), _uuid_in_org('cost_codes', inv.org_id, a ->> 'cost_code_id'),
          _uuid_in_org('cost_types', inv.org_id, a ->> 'cost_type_id'), _uuid_in_org('gl_accounts', inv.org_id, a ->> 'gl_account_id'),
          _num(a ->> 'amount'), left(a ->> 'description', 500), 'ai',
          CASE WHEN jsonb_typeof(a -> 'confidence') = 'number' THEN greatest(0, least(1, (a ->> 'confidence')::numeric)) END,
          left(a ->> 'rationale', 2000));
      END IF;
    END LOOP;
  END IF;

  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'ai_extracted', 'AI extracted invoice fields and proposed coding',
    jsonb_build_object('confidence', conf));
  checks := _invoice_checks(inv.id, true);
  UPDATE agent_runs SET status = 'succeeded', finished_at = now(),
    summary = format('Extracted %s %s for %s; %s blocking, %s warnings left for review',
      coalesce(p ->> 'vendor_name', 'unknown vendor'), coalesce(p ->> 'invoice_number', '(no number)'), coalesce(p ->> 'total_amount', '?'),
      checks ->> 'blocking', checks ->> 'warnings'),
    output = jsonb_build_object('extraction', p, 'checks', checks)
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
  RETURN checks;
END $$;

CREATE OR REPLACE FUNCTION agent_fail_extraction(p_invoice uuid, p_error text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  IF inv.extraction_status = 'succeeded' THEN RETURN; END IF;
  PERFORM set_config('app.actor_kind', 'agent', true);
  UPDATE invoices SET extraction_status = 'failed', extraction_error = left(coalesce(p_error, 'Extraction failed'), 2000) WHERE id = inv.id;
  UPDATE agent_runs SET status = 'failed', error = left(p_error, 2000), finished_at = now(), summary = 'Could not read the document'
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'ai_failed', 'AI could not read the document: ' || left(coalesce(p_error, ''), 300), '{}');
END $$;

-- A person takes over data entry (extraction failed, stalled, or not wanted).
CREATE OR REPLACE FUNCTION start_manual_entry(p_invoice uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  PERFORM _require(inv.status = 'needs_review', 'Invoice is no longer in review');
  IF inv.extraction_status IN ('pending', 'running', 'failed') THEN
    UPDATE invoices SET extraction_status = 'manual' WHERE id = inv.id;
    UPDATE agent_runs SET status = 'failed', error = 'Superseded by manual entry', finished_at = now()
    WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
    PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'manual_entry', 'Switched to manual data entry', '{}');
  END IF;
  RETURN _invoice_checks(inv.id, false);
END $$;

-- Re-queue AI extraction (e.g. after a failure or a stalled run).
CREATE OR REPLACE FUNCTION retry_extraction(p_invoice uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to process this invoice');
  PERFORM _require(inv.status = 'needs_review' AND inv.upload_id IS NOT NULL, 'Only uploaded invoices in review can be re-read');
  PERFORM _require(inv.extraction_status IN ('failed', 'manual')
      OR (inv.extraction_status = 'running' AND inv.extraction_started_at < now() - interval '10 minutes')
      OR (inv.extraction_status = 'pending' AND inv.updated_at < now() - interval '10 minutes'),
    'Extraction is already running or finished');
  UPDATE invoices SET extraction_status = 'pending', extraction_error = NULL, agent_session_id = NULL WHERE id = inv.id;
  UPDATE agent_runs SET status = 'failed', error = 'Retried', finished_at = now()
  WHERE invoice_id = inv.id AND agent = 'invoice_intake' AND status = 'running';
END $$;

-- ================================================================ approval workflow
CREATE OR REPLACE FUNCTION _can_decide_step(s approval_steps, inv invoices, st org_settings) RETURNS text
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  me org_members;
BEGIN
  SELECT * INTO me FROM org_members WHERE org_id = inv.org_id AND user_id = app_uid() AND active;
  IF me.user_id IS NULL THEN RETURN 'You are not a member of this company'; END IF;
  IF s.approver_user_id IS NOT NULL AND s.approver_user_id <> me.user_id THEN RETURN 'This step is assigned to someone else'; END IF;
  IF s.approver_user_id IS NULL AND NOT (me.role = s.approver_role OR (s.approver_role = 'controller' AND me.role = 'owner')) THEN
    RETURN 'This step needs a ' || replace(s.approver_role, '_', ' ');
  END IF;
  IF me.role = 'viewer' THEN RETURN 'Viewers cannot approve'; END IF;
  IF NOT st.allow_self_approval AND inv.submitted_by = me.user_id THEN RETURN 'You submitted this invoice; company policy requires someone else to approve it'; END IF;
  IF me.approval_limit IS NOT NULL AND inv.total_amount > me.approval_limit THEN
    RETURN format('The total %s exceeds your approval limit of %s', inv.total_amount, me.approval_limit);
  END IF;
  IF s.approver_user_id IS NULL AND EXISTS (SELECT 1 FROM approval_steps o WHERE o.invoice_id = inv.id AND o.round = s.round
      AND o.id <> s.id AND o.decided_by = me.user_id AND o.status = 'approved') THEN
    RETURN 'You already approved another step of this invoice; a different person must approve this one';
  END IF;
  RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION _invoice_snapshot(p_invoice uuid) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT jsonb_build_object(
    'invoice_id', i.id, 'vendor_code', v.code, 'vendor_name', v.name, 'vendor_external_id', v.external_id,
    'invoice_number', i.invoice_number, 'invoice_date', i.invoice_date, 'due_date', i.due_date, 'payment_terms', i.payment_terms,
    'currency', i.currency, 'subtotal', i.subtotal, 'tax_amount', i.tax_amount, 'retainage_amount', i.retainage_amount,
    'total_amount', i.total_amount, 'commitment_number', c.number, 'commitment_external_id', c.external_id, 'description', i.description,
    'allocations', (SELECT coalesce(jsonb_agg(jsonb_build_object(
        'project_code', p.code, 'project_external_id', p.external_id, 'cost_code', cc.code, 'cost_type', ct.code,
        'gl_account', g.code, 'amount', a.amount, 'description', a.description) ORDER BY a.created_at, a.id), '[]')
      FROM invoice_allocations a
      LEFT JOIN projects p ON p.id = a.project_id LEFT JOIN cost_codes cc ON cc.id = a.cost_code_id
      LEFT JOIN cost_types ct ON ct.id = a.cost_type_id LEFT JOIN gl_accounts g ON g.id = a.gl_account_id
      WHERE a.invoice_id = i.id))
  FROM invoices i LEFT JOIN vendors v ON v.id = i.vendor_id LEFT JOIN commitments c ON c.id = i.commitment_id
  WHERE i.id = p_invoice
$$;

CREATE OR REPLACE FUNCTION submit_invoice(p_invoice uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  st org_settings;
  checks jsonb;
  ru record;
  pr record;
  v_round int;
  v_user text;
  v_reason text;
  v_steps int;
  m org_members;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to submit invoices');
  PERFORM _require(inv.status = 'needs_review', 'Only invoices in review can be submitted (current status: ' || coalesce(inv.status, '?') || ')');
  PERFORM _require(inv.extraction_status NOT IN ('pending', 'running'), 'Wait for extraction to finish or switch to manual entry');
  SELECT * INTO st FROM org_settings WHERE org_id = inv.org_id;
  checks := _invoice_checks(inv.id, true);
  IF (checks ->> 'blocking')::int > 0 THEN
    RAISE EXCEPTION 'Resolve % blocking exception(s) before submitting', checks ->> 'blocking' USING ERRCODE = 'P0001';
  END IF;
  -- Values the AI was unsure of, and possible duplicates, need a person's confirmation before approvers see them.
  IF EXISTS (SELECT 1 FROM invoice_exceptions WHERE invoice_id = inv.id AND status = 'open'
             AND code IN ('low_confidence', 'possible_duplicate', 'totals_mismatch', 'duplicate')) THEN
    RAISE EXCEPTION 'Confirm or correct the flagged fields and possible duplicates before submitting' USING ERRCODE = 'P0001';
  END IF;
  SELECT * INTO inv FROM invoices WHERE id = p_invoice;
  v_round := inv.approval_round + 1;

  FOR ru IN SELECT * FROM approval_rules
            WHERE org_id = inv.org_id AND active AND inv.total_amount >= min_amount
              AND (vendor_id IS NULL OR vendor_id = inv.vendor_id)
              AND (project_id IS NULL OR EXISTS (SELECT 1 FROM invoice_allocations a WHERE a.invoice_id = inv.id AND a.project_id = approval_rules.project_id))
            ORDER BY step_order, created_at LOOP
    IF ru.approver_kind = 'role' THEN
      IF NOT EXISTS (SELECT 1 FROM approval_steps WHERE invoice_id = inv.id AND round = v_round AND approver_role = ru.approver_role AND step_order = ru.step_order) THEN
        INSERT INTO approval_steps (org_id, invoice_id, round, step_order, approver_role, rule_id, reason)
        VALUES (inv.org_id, inv.id, v_round, ru.step_order, ru.approver_role, ru.id, 'Rule: ' || ru.name);
      END IF;
      CONTINUE;
    END IF;
    FOR pr IN SELECT DISTINCT p.id, p.code, p.project_manager_user_id FROM invoice_allocations a JOIN projects p ON p.id = a.project_id
              WHERE ru.approver_kind = 'project_manager' AND a.invoice_id = inv.id AND (ru.project_id IS NULL OR p.id = ru.project_id)
              UNION ALL SELECT NULL, NULL, ru.approver_user_id WHERE ru.approver_kind = 'user' LOOP
      v_user := pr.project_manager_user_id;
      v_reason := CASE WHEN ru.approver_kind = 'project_manager' THEN 'Project manager of ' || pr.code ELSE 'Named approver' END || ' (rule: ' || ru.name || ')';
      SELECT * INTO m FROM org_members WHERE org_id = inv.org_id AND user_id = v_user AND active;
      IF v_user IS NULL OR m.user_id IS NULL THEN
        v_reason := CASE WHEN ru.approver_kind = 'project_manager' THEN 'Project ' || pr.code || ' has no active project manager' ELSE 'Named approver is not an active member' END
          || '; routed to controllers (rule: ' || ru.name || ')';
        v_user := NULL;
      ELSIF m.role = 'viewer' THEN
        v_reason := m.email || ' is a viewer and cannot approve; routed to controllers (rule: ' || ru.name || ')'; v_user := NULL;
      ELSIF NOT st.allow_self_approval AND v_user = app_uid() THEN
        v_reason := m.email || ' submitted this invoice and cannot approve it; routed to controllers (rule: ' || ru.name || ')'; v_user := NULL;
      ELSIF m.approval_limit IS NOT NULL AND inv.total_amount > m.approval_limit THEN
        v_reason := format('%s''s approval limit (%s) is below the total; routed to controllers (rule: %s)', m.email, m.approval_limit, ru.name); v_user := NULL;
      END IF;
      IF v_user IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM approval_steps WHERE invoice_id = inv.id AND round = v_round AND approver_user_id = v_user) THEN
          INSERT INTO approval_steps (org_id, invoice_id, round, step_order, approver_user_id, rule_id, reason)
          VALUES (inv.org_id, inv.id, v_round, ru.step_order, v_user, ru.id, v_reason);
        END IF;
      ELSIF NOT EXISTS (SELECT 1 FROM approval_steps WHERE invoice_id = inv.id AND round = v_round AND approver_role = 'controller' AND step_order = ru.step_order) THEN
        INSERT INTO approval_steps (org_id, invoice_id, round, step_order, approver_role, rule_id, reason)
        VALUES (inv.org_id, inv.id, v_round, ru.step_order, 'controller', ru.id, v_reason);
      END IF;
    END LOOP;
  END LOOP;

  SELECT count(*) INTO v_steps FROM approval_steps WHERE invoice_id = inv.id AND round = v_round;
  IF v_steps = 0 THEN
    INSERT INTO approval_steps (org_id, invoice_id, round, step_order, approver_role, reason)
    VALUES (inv.org_id, inv.id, v_round, 1, 'controller', 'No approval rule matched; a controller must approve');
    v_steps := 1;
  END IF;

  UPDATE invoices SET status = 'pending_approval', approval_round = v_round, submitted_by = app_uid(), submitted_at = now(), rejected_reason = NULL
  WHERE id = inv.id;
  INSERT INTO agent_runs (org_id, agent, kind, invoice_id, status, summary, output, triggered_by, finished_at)
  VALUES (inv.org_id, 'approval_router', 'rules', inv.id, 'succeeded', format('Routed to %s approval step(s)', v_steps),
    jsonb_build_object('steps', (SELECT jsonb_agg(jsonb_build_object('step_order', step_order, 'user', approver_user_id, 'role', approver_role, 'reason', reason))
      FROM approval_steps WHERE invoice_id = inv.id AND round = v_round)), app_uid(), now());
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'submitted', format('Submitted for approval (%s step(s))', v_steps), jsonb_build_object('round', v_round));
  RETURN jsonb_build_object('steps', v_steps, 'round', v_round);
END $$;

CREATE OR REPLACE FUNCTION decide_invoice(p_invoice uuid, p_decision text, p_comment text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  inv invoices;
  st org_settings;
  s approval_steps;
  v_min int;
  v_why text;
  v_last_why text;
  v_remaining int;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'read'), 'Invoice not found');
  PERFORM _require(p_decision IN ('approve', 'reject'), 'Decision must be approve or reject');
  PERFORM _require(inv.status = 'pending_approval', 'This invoice is not awaiting approval');
  PERFORM _require(p_decision = 'approve' OR length(trim(coalesce(p_comment, ''))) >= 3, 'A reason is required to reject an invoice');
  SELECT * INTO st FROM org_settings WHERE org_id = inv.org_id;
  SELECT min(step_order) INTO v_min FROM approval_steps WHERE invoice_id = inv.id AND round = inv.approval_round AND status = 'pending';
  FOR s IN SELECT * FROM approval_steps WHERE invoice_id = inv.id AND round = inv.approval_round AND status = 'pending' AND step_order = v_min
           ORDER BY (approver_user_id = app_uid()) DESC NULLS LAST, created_at LOOP
    v_why := _can_decide_step(s, inv, st);
    IF v_why IS NULL THEN EXIT; END IF;
    v_last_why := v_why;
    s := NULL;
  END LOOP;
  IF s.id IS NULL THEN
    RAISE EXCEPTION 'You cannot decide this invoice: %', coalesce(v_last_why, 'no step is waiting on you') USING ERRCODE = '42501';
  END IF;

  IF p_decision = 'approve' THEN
    UPDATE approval_steps SET status = 'approved', decided_by = app_uid(), decided_at = now(), comment = nullif(trim(p_comment), '') WHERE id = s.id;
    PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'step_approved', 'Approved: ' || s.reason, jsonb_build_object('step_id', s.id, 'comment', p_comment));
    SELECT count(*) INTO v_remaining FROM approval_steps WHERE invoice_id = inv.id AND round = inv.approval_round AND status = 'pending';
    IF v_remaining = 0 THEN
      UPDATE invoices SET status = 'approved', approved_at = now(), sync_status = 'ready', approved_snapshot = _invoice_snapshot(inv.id) WHERE id = inv.id;
      PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'approved', 'Invoice fully approved and ready for export', '{}');
    END IF;
    RETURN jsonb_build_object('status', CASE WHEN v_remaining = 0 THEN 'approved' ELSE 'pending_approval' END, 'remaining_steps', v_remaining);
  ELSE
    UPDATE approval_steps SET status = 'rejected', decided_by = app_uid(), decided_at = now(), comment = trim(p_comment) WHERE id = s.id;
    UPDATE approval_steps SET status = 'skipped' WHERE invoice_id = inv.id AND round = inv.approval_round AND status = 'pending';
    UPDATE invoices SET status = 'rejected', rejected_reason = trim(p_comment) WHERE id = inv.id;
    PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'rejected', 'Rejected: ' || trim(p_comment), jsonb_build_object('step_id', s.id));
    RETURN jsonb_build_object('status', 'rejected');
  END IF;
END $$;

-- Hand a pending step to someone else (delegation or escalation).
CREATE OR REPLACE FUNCTION reassign_approval(p_step uuid, p_user text, p_reason text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  s approval_steps;
  inv invoices;
  m org_members;
BEGIN
  SELECT * INTO s FROM approval_steps WHERE id = p_step FOR UPDATE;
  SELECT * INTO inv FROM invoices WHERE id = s.invoice_id;
  PERFORM _require(s.id IS NOT NULL AND s.status = 'pending', 'Step is not pending');
  PERFORM _require(app_can(inv.org_id, 'admin') OR s.approver_user_id = app_uid(), 'Only the assigned approver or a controller can reassign');
  PERFORM _require(length(trim(coalesce(p_reason, ''))) >= 3, 'Give a reason for reassigning');
  SELECT * INTO m FROM org_members WHERE org_id = inv.org_id AND user_id = p_user AND active;
  PERFORM _require(m.user_id IS NOT NULL AND m.role <> 'viewer', 'Choose an active member who can approve');
  UPDATE approval_steps SET approver_user_id = p_user, approver_role = NULL, reason = s.reason || ' → reassigned to ' || m.email || ': ' || trim(p_reason)
  WHERE id = s.id;
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'reassigned', 'Approval reassigned to ' || m.email || ': ' || trim(p_reason), jsonb_build_object('step_id', s.id));
END $$;

-- Back to review: recall a pending invoice, rework a rejected one, or (controllers) reopen an approved one not yet exported.
CREATE OR REPLACE FUNCTION reopen_invoice(p_invoice uuid, p_reason text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to reopen invoices');
  PERFORM _require(length(trim(coalesce(p_reason, ''))) >= 3, 'Give a reason for reopening');
  IF inv.status = 'approved' THEN
    PERFORM _require(app_can(inv.org_id, 'admin'), 'Only a controller or owner can reopen an approved invoice');
    PERFORM _require(inv.sync_status IN ('ready', 'failed'), 'This invoice was already exported; it cannot be reopened. Record a correction in the accounting system.');
  ELSE
    PERFORM _require(inv.status IN ('pending_approval', 'rejected'), 'This invoice cannot be reopened');
  END IF;
  UPDATE approval_steps SET status = 'skipped' WHERE invoice_id = inv.id AND status = 'pending';
  UPDATE invoices SET status = 'needs_review', sync_status = 'not_ready', approved_snapshot = NULL, approved_at = NULL WHERE id = inv.id;
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'reopened', 'Reopened for review: ' || trim(p_reason), jsonb_build_object('from_status', inv.status));
END $$;

CREATE OR REPLACE FUNCTION void_invoice(p_invoice uuid, p_reason text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv invoices;
BEGIN
  SELECT * INTO inv FROM invoices WHERE id = p_invoice FOR UPDATE;
  PERFORM _require(inv.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to void invoices');
  PERFORM _require(length(trim(coalesce(p_reason, ''))) >= 3, 'Give a reason for voiding');
  PERFORM _require(inv.status IN ('needs_review', 'rejected') OR (inv.status = 'approved' AND inv.sync_status IN ('ready', 'failed') AND app_can(inv.org_id, 'admin')),
    'This invoice cannot be voided in its current state');
  UPDATE approval_steps SET status = 'skipped' WHERE invoice_id = inv.id AND status = 'pending';
  UPDATE invoices SET status = 'void', sync_status = 'not_ready' WHERE id = inv.id;
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'voided', 'Voided: ' || trim(p_reason), '{}');
END $$;

CREATE OR REPLACE FUNCTION resolve_exception(p_exception uuid, p_action text, p_note text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  x invoice_exceptions;
  inv invoices;
BEGIN
  SELECT * INTO x FROM invoice_exceptions WHERE id = p_exception FOR UPDATE;
  SELECT * INTO inv FROM invoices WHERE id = x.invoice_id;
  PERFORM _require(x.id IS NOT NULL AND app_can(inv.org_id, 'ap'), 'You do not have permission to resolve exceptions');
  PERFORM _require(inv.status = 'needs_review', 'Exceptions can only be resolved while the invoice is in review');
  PERFORM _require(x.status = 'open', 'This exception is not open');
  PERFORM _require(p_action IN ('acknowledge', 'override'), 'Unknown action');
  PERFORM _require(x.overridable, 'This exception cannot be overridden; correct the data instead');
  IF x.severity = 'blocking' THEN
    PERFORM _require(p_action = 'override', 'Blocking exceptions must be overridden, not acknowledged');
    PERFORM _require(app_can(inv.org_id, 'admin'), 'Only a controller or owner can override a blocking exception');
    PERFORM _require(length(trim(coalesce(p_note, ''))) >= 10, 'Explain the override (at least 10 characters)');
  ELSE
    PERFORM _require(length(trim(coalesce(p_note, ''))) >= 3 OR x.severity = 'info', 'Add a short note');
  END IF;
  UPDATE invoice_exceptions SET status = CASE WHEN p_action = 'override' THEN 'overridden' ELSE 'acknowledged' END,
    resolution_note = trim(p_note), resolved_by = app_uid(), resolved_at = now(), updated_at = now()
  WHERE id = x.id;
  PERFORM _audit(inv.org_id, 'invoice', inv.id, inv.id, 'exception_' || p_action || 'd',
    initcap(p_action) || 'd "' || x.title || '": ' || coalesce(trim(p_note), ''), jsonb_build_object('exception_id', x.id, 'code', x.code, 'severity', x.severity));
END $$;

-- ================================================================ accounting export & sync
CREATE OR REPLACE FUNCTION _can_sync(p_org uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT app_can(p_org, 'admin') OR (app_can(p_org, 'ap') AND (SELECT ap_can_sync FROM org_settings WHERE org_id = p_org))
$$;

CREATE OR REPLACE FUNCTION create_export_batch(p_org uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_batch uuid;
  v_no int;
  v_count int;
  v_inv_total numeric;
  v_alloc_total numeric;
  st org_settings;
BEGIN
  PERFORM _require(_can_sync(p_org), 'You do not have permission to export to accounting');
  PERFORM pg_advisory_xact_lock(hashtext('export:' || p_org));
  SELECT * INTO st FROM org_settings WHERE org_id = p_org;
  CREATE TEMP TABLE _ready ON COMMIT DROP AS
    SELECT i.id, i.total_amount, i.approved_snapshot FROM invoices i
    WHERE i.org_id = p_org AND i.status = 'approved' AND i.sync_status IN ('ready', 'failed')
      AND NOT EXISTS (SELECT 1 FROM sync_records r WHERE r.invoice_id = i.id AND r.status IN ('exported', 'synced'))
    FOR UPDATE OF i;
  SELECT count(*), coalesce(sum(total_amount), 0),
    coalesce(sum((SELECT sum((a ->> 'amount')::numeric) FROM jsonb_array_elements(approved_snapshot -> 'allocations') a)), 0)
  INTO v_count, v_inv_total, v_alloc_total FROM _ready;
  PERFORM _require(v_count > 0, 'Nothing is ready to export');
  IF abs(v_inv_total - v_alloc_total) > 0.005 THEN
    RAISE EXCEPTION 'Export refused: invoice totals (%) and allocation totals (%) do not reconcile', v_inv_total, v_alloc_total;
  END IF;
  SELECT coalesce(max(batch_number), 0) + 1 INTO v_no FROM export_batches WHERE org_id = p_org;
  INSERT INTO export_batches (org_id, batch_number, target, invoice_count, invoice_total, allocation_total, created_by)
  VALUES (p_org, v_no, st.export_target, v_count, v_inv_total, v_alloc_total, app_uid()) RETURNING id INTO v_batch;
  INSERT INTO sync_records (org_id, invoice_id, batch_id, target, idempotency_key, attempt, payload)
  SELECT p_org, r.id, v_batch, st.export_target, 'INV-' || r.id,
    coalesce((SELECT max(attempt) FROM sync_records s WHERE s.invoice_id = r.id), 0) + 1, r.approved_snapshot
  FROM _ready r;
  UPDATE invoices SET sync_status = 'exported' WHERE id IN (SELECT id FROM _ready);
  PERFORM _audit(p_org, 'export_batch', v_batch, NULL, 'exported',
    format('Export batch #%s: %s invoice(s), %s', v_no, v_count, v_inv_total), jsonb_build_object('invoice_total', v_inv_total, 'allocation_total', v_alloc_total));
  INSERT INTO audit_events (org_id, entity_type, entity_id, invoice_id, action, actor_user_id, actor_kind, summary, details)
  SELECT p_org, 'invoice', id, id, 'exported', app_uid(), _actor_kind(), format('Included in export batch #%s', v_no), jsonb_build_object('batch_id', v_batch) FROM _ready;
  RETURN jsonb_build_object('batch_id', v_batch, 'batch_number', v_no, 'invoice_count', v_count, 'invoice_total', v_inv_total, 'allocation_total', v_alloc_total);
END $$;

-- results: [{ key (idempotency key or invoice id), status: 'synced' | 'failed', external_id, error }]
CREATE OR REPLACE FUNCTION record_sync_results(p_batch uuid, p_results jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  b export_batches;
  r jsonb;
  rec sync_records;
  v_key text;
  v_status text;
  synced int := 0;
  failed int := 0;
  unchanged int := 0;
  problems jsonb := '[]';
BEGIN
  SELECT * INTO b FROM export_batches WHERE id = p_batch FOR UPDATE;
  PERFORM _require(b.id IS NOT NULL AND _can_sync(b.org_id), 'You do not have permission to record sync results');
  PERFORM _require(jsonb_typeof(p_results) = 'array', 'Results must be a list');
  FOR r IN SELECT * FROM jsonb_array_elements(p_results) LOOP
    v_key := trim(coalesce(r ->> 'key', ''));
    v_status := lower(trim(coalesce(r ->> 'status', '')));
    SELECT * INTO rec FROM sync_records WHERE batch_id = b.id AND (idempotency_key = v_key OR invoice_id::text = v_key) FOR UPDATE;
    IF rec.id IS NULL THEN
      problems := problems || jsonb_build_object('key', v_key, 'problem', 'Not part of this batch'); CONTINUE;
    END IF;
    IF v_status NOT IN ('synced', 'failed') THEN
      problems := problems || jsonb_build_object('key', v_key, 'problem', 'Status must be synced or failed'); CONTINUE;
    END IF;
    IF rec.status = 'synced' THEN
      IF v_status = 'synced' AND coalesce(nullif(trim(r ->> 'external_id'), ''), rec.external_id) = rec.external_id THEN
        unchanged := unchanged + 1;
      ELSE
        problems := problems || jsonb_build_object('key', v_key, 'problem', 'Already recorded as synced (' || coalesce(rec.external_id, '') || '); not changed');
      END IF;
      CONTINUE;
    END IF;
    IF EXISTS (SELECT 1 FROM sync_records o WHERE o.invoice_id = rec.invoice_id AND o.attempt > rec.attempt) THEN
      problems := problems || jsonb_build_object('key', v_key, 'problem', 'A newer export attempt exists; record the result on that batch'); CONTINUE;
    END IF;
    IF v_status = 'synced' THEN
      IF nullif(trim(r ->> 'external_id'), '') IS NULL THEN
        problems := problems || jsonb_build_object('key', v_key, 'problem', 'external_id is required to mark synced'); CONTINUE;
      END IF;
      IF EXISTS (SELECT 1 FROM sync_records o WHERE o.org_id = b.org_id AND o.target = rec.target AND o.status = 'synced' AND o.external_id = trim(r ->> 'external_id')) THEN
        problems := problems || jsonb_build_object('key', v_key, 'problem', 'External id ' || trim(r ->> 'external_id') || ' is already used by another invoice'); CONTINUE;
      END IF;
      UPDATE sync_records SET status = 'synced', external_id = trim(r ->> 'external_id'), error = NULL, updated_at = now() WHERE id = rec.id;
      UPDATE invoices SET sync_status = 'synced' WHERE id = rec.invoice_id;
      PERFORM _audit(b.org_id, 'invoice', rec.invoice_id, rec.invoice_id, 'synced', 'Posted in accounting system as ' || trim(r ->> 'external_id'), jsonb_build_object('batch_id', b.id));
      synced := synced + 1;
    ELSE
      UPDATE sync_records SET status = 'failed', error = coalesce(nullif(trim(r ->> 'error'), ''), 'Rejected by accounting system'), updated_at = now() WHERE id = rec.id;
      UPDATE invoices SET sync_status = 'failed' WHERE id = rec.invoice_id;
      PERFORM _audit(b.org_id, 'invoice', rec.invoice_id, rec.invoice_id, 'sync_failed',
        'Accounting import failed: ' || coalesce(nullif(trim(r ->> 'error'), ''), 'no reason given'), jsonb_build_object('batch_id', b.id));
      failed := failed + 1;
    END IF;
  END LOOP;
  UPDATE export_batches SET status = (
    SELECT CASE WHEN bool_and(status = 'synced') THEN 'reconciled'
                WHEN bool_and(status = 'failed') THEN 'failed'
                WHEN bool_or(status = 'failed') THEN 'partially_failed'
                ELSE 'exported' END FROM sync_records WHERE batch_id = b.id)
  WHERE id = b.id;
  PERFORM _audit(b.org_id, 'export_batch', b.id, NULL, 'sync_results', format('Batch #%s results: %s synced, %s failed, %s problems', b.batch_number, synced, failed, jsonb_array_length(problems)), jsonb_build_object('problems', problems));
  RETURN jsonb_build_object('synced', synced, 'failed', failed, 'unchanged', unchanged, 'problems', problems);
END $$;

-- ================================================================ permissions on functions
DO $$
DECLARE f regprocedure;
BEGIN
  FOR f IN SELECT p.oid::regprocedure FROM pg_proc p
           WHERE p.pronamespace = 'public'::regnamespace
             AND NOT EXISTS (SELECT 1 FROM pg_depend d WHERE d.objid = p.oid AND d.deptype = 'e') LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC', f);
  END LOOP;
END $$;
GRANT EXECUTE ON FUNCTION app_uid(), app_role(uuid), app_pm_linked(uuid), app_can(uuid, text), app_invoice_visible(uuid), app_invoice_editable(uuid),
  app_norm_name(text), app_norm_ref(text),
  create_organization(text, text), accept_invitations(), invite_member(uuid, text, text, numeric), revoke_invite(uuid),
  update_member(uuid, text, text, numeric, boolean),
  run_invoice_checks(uuid), agent_begin_extraction(uuid, text), agent_submit_extraction(uuid, jsonb), agent_fail_extraction(uuid, text),
  start_manual_entry(uuid), retry_extraction(uuid), submit_invoice(uuid), decide_invoice(uuid, text, text),
  reassign_approval(uuid, text, text), reopen_invoice(uuid, text), void_invoice(uuid, text), resolve_exception(uuid, text, text),
  create_export_batch(uuid), record_sync_results(uuid, jsonb)
TO authenticated;

-- ================================================================ optional demo workspace
-- Synthetic data for evaluation only. The workspace is flagged is_demo and named
-- as such; real companies start from create_organization and import their own data.
CREATE OR REPLACE FUNCTION create_demo_organization() RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_org uuid;
  me record;
  p1 uuid; p2 uuid;
  ctL uuid; ctM uuid; ctS uuid; ctE uuid;
  g1 uuid; g2 uuid; g3 uuid; g4 uuid; g5 uuid;
  v1 uuid; v2 uuid; v3 uuid; v4 uuid; v5 uuid;
  c03 uuid; c09 uuid; c15 uuid; c22 uuid; c26 uuid; c31 uuid; c03b uuid; c09b uuid;
  po1 uuid; sc1 uuid; po2 uuid;
  i1 uuid;
BEGIN
  PERFORM _require(app_uid() IS NOT NULL, 'Sign in first');
  PERFORM _require((SELECT count(*) FROM orgs WHERE created_by = app_uid() AND is_demo) < 3, 'You already have demo workspaces');
  SELECT * INTO me FROM _current_user_identity();
  INSERT INTO orgs (name, legal_entity, is_demo, created_by) VALUES ('DEMO – Summit Ridge Builders (synthetic data)', 'Summit Ridge Builders LLC (fictional)', true, app_uid())
  RETURNING id INTO v_org;
  INSERT INTO org_members (org_id, user_id, email, display_name, role) VALUES (v_org, app_uid(), coalesce(me.email, ''), coalesce(me.name, ''), 'owner');
  PERFORM _seed_org(v_org);
  -- A one-person demo needs self-approval to walk through the full workflow.
  UPDATE org_settings SET allow_self_approval = true, require_po = true, require_po_over_amount = 2500 WHERE org_id = v_org;
  SELECT id INTO ctL FROM cost_types WHERE org_id = v_org AND code = 'L';
  SELECT id INTO ctM FROM cost_types WHERE org_id = v_org AND code = 'M';
  SELECT id INTO ctS FROM cost_types WHERE org_id = v_org AND code = 'S';
  SELECT id INTO ctE FROM cost_types WHERE org_id = v_org AND code = 'E';
  INSERT INTO gl_accounts (org_id, code, name, account_type) VALUES (v_org, '5010', 'Job Cost – Materials', 'cost_of_goods') RETURNING id INTO g1;
  INSERT INTO gl_accounts (org_id, code, name, account_type) VALUES (v_org, '5020', 'Job Cost – Subcontractors', 'cost_of_goods') RETURNING id INTO g2;
  INSERT INTO gl_accounts (org_id, code, name, account_type) VALUES (v_org, '5030', 'Job Cost – Equipment Rental', 'cost_of_goods') RETURNING id INTO g3;
  INSERT INTO gl_accounts (org_id, code, name, account_type) VALUES (v_org, '5040', 'Job Cost – Labor', 'cost_of_goods') RETURNING id INTO g4;
  INSERT INTO gl_accounts (org_id, code, name, account_type) VALUES (v_org, '6100', 'Office Supplies', 'expense') RETURNING id INTO g5;
  INSERT INTO projects (org_id, code, name, address, project_manager_user_id) VALUES (v_org, '24-101', 'Riverside Medical Office Building', '410 River Rd', app_uid()) RETURNING id INTO p1;
  INSERT INTO projects (org_id, code, name, address, project_manager_user_id) VALUES (v_org, '24-117', 'Oakwood Elementary Renovation', '22 Oakwood Ave', app_uid()) RETURNING id INTO p2;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '03-300', 'Cast-in-Place Concrete') RETURNING id INTO c03;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '09-250', 'Gypsum Board') RETURNING id INTO c09;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '01-540', 'Equipment Rental') RETURNING id INTO c15;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '22-100', 'Plumbing') RETURNING id INTO c22;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '26-050', 'Electrical') RETURNING id INTO c26;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '31-200', 'Earthwork') RETURNING id INTO c31;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '03-200', 'Concrete Reinforcing') RETURNING id INTO c03b;
  INSERT INTO cost_codes (org_id, code, name) VALUES (v_org, '06-100', 'Rough Carpentry') RETURNING id INTO c09b;
  INSERT INTO vendors (org_id, code, name, payment_terms, default_gl_account_id, default_cost_type_id) VALUES (v_org, 'V-1001', 'Granite State Ready Mix', 'Net 30', g1, ctM) RETURNING id INTO v1;
  INSERT INTO vendors (org_id, code, name, payment_terms, default_gl_account_id, default_cost_type_id) VALUES (v_org, 'V-1002', 'Apex Electrical Contractors', 'Net 45', g2, ctS) RETURNING id INTO v2;
  INSERT INTO vendors (org_id, code, name, payment_terms, default_gl_account_id, default_cost_type_id) VALUES (v_org, 'V-1003', 'Northline Equipment Rentals', 'Net 30', g3, ctE) RETURNING id INTO v3;
  INSERT INTO vendors (org_id, code, name, payment_terms, default_gl_account_id, default_cost_type_id) VALUES (v_org, 'V-1004', 'Builders Supply Co', 'Net 30', g1, ctM) RETURNING id INTO v4;
  INSERT INTO vendors (org_id, code, name, payment_terms, default_gl_account_id, default_cost_type_id) VALUES (v_org, 'V-1005', 'ClearFlow Plumbing', 'Net 30', g2, ctS) RETURNING id INTO v5;
  INSERT INTO commitments (org_id, kind, number, vendor_id, project_id, description, original_amount) VALUES (v_org, 'purchase_order', 'PO-24101-007', v1, p1, 'Ready-mix concrete, foundations and slab', 48000) RETURNING id INTO po1;
  INSERT INTO commitment_lines (org_id, commitment_id, line_no, description, cost_code_id, cost_type_id, amount) VALUES
    (v_org, po1, 1, '4000 PSI ready mix', c03, ctM, 42000), (v_org, po1, 2, 'Rebar chairs and accessories', c03b, ctM, 6000);
  INSERT INTO commitments (org_id, kind, number, vendor_id, project_id, description, original_amount, retainage_pct) VALUES (v_org, 'subcontract', 'SC-24101-003', v2, p1, 'Electrical rough-in and finish', 185000, 10) RETURNING id INTO sc1;
  INSERT INTO commitment_lines (org_id, commitment_id, line_no, description, cost_code_id, cost_type_id, amount) VALUES (v_org, sc1, 1, 'Electrical scope', c26, ctS, 185000);
  INSERT INTO change_orders (org_id, commitment_id, number, description, amount, status, approved_date) VALUES
    (v_org, sc1, 'CO-01', 'Additional exam room circuits', 12500, 'approved', current_date - 20),
    (v_org, sc1, 'CO-02', 'Generator transfer switch upgrade', 8200, 'pending', NULL);
  INSERT INTO commitments (org_id, kind, number, vendor_id, project_id, description, original_amount) VALUES (v_org, 'purchase_order', 'PO-24117-002', v3, p2, 'Excavator and lift rental', 15000) RETURNING id INTO po2;
  INSERT INTO commitment_lines (org_id, commitment_id, line_no, description, cost_code_id, cost_type_id, amount) VALUES (v_org, po2, 1, 'Equipment rental', c15, ctE, 15000);
  -- Prior approved billing on the concrete PO, so matching has history to compare against.
  INSERT INTO invoices (org_id, source, status, extraction_status, sync_status, vendor_id, invoice_number, invoice_date, due_date, payment_terms,
    subtotal, tax_amount, total_amount, po_number, commitment_id, description, approval_round, submitted_by, submitted_at, approved_at, created_by)
  VALUES (v_org, 'manual', 'approved', 'manual', 'synced', v1, 'GSR-88120', current_date - 40, current_date - 10, 'Net 30',
    41000, 0, 41000, 'PO-24101-007', po1, 'Foundation pours (demo history)', 1, app_uid(), now() - interval '39 days', now() - interval '38 days', app_uid())
  RETURNING id INTO i1;
  INSERT INTO invoice_allocations (org_id, invoice_id, project_id, cost_code_id, cost_type_id, gl_account_id, amount, source)
  VALUES (v_org, i1, p1, c03, ctM, g1, 41000, 'user');
  PERFORM _audit(v_org, 'org', v_org, NULL, 'created', 'Demo workspace created with synthetic data', '{}');
  RETURN v_org;
END $$;
GRANT EXECUTE ON FUNCTION create_demo_organization() TO authenticated;
