# Trestle

Trestle helps a construction company handle the bills it receives from suppliers and subcontractors.

Before a bill is paid, someone has to read it, decide which job and budget line it belongs to, check that it is not wrong or a repeat, get it approved, and type it into the accounting software. Trestle does the reading, sorting and checking, and keeps a record of every step. People still make every approval.

```
 IN (you give it)                 TRESTLE (it does)                 OUT (you get)
 ---------------------------      -----------------------------     ----------------------------------
 Bills: PDF or phone photo   -->  1. Reads each bill           -->  Every bill entered and sorted,
 Vendors, jobs, budget lines      2. Assigns job + budget line      unsure values marked for checking
   (spreadsheet / CSV file)       3. Checks for repeats,            A list of problems, with reasons
 Purchase orders and                 overcharges, missing POs       Who approved what, and when
   subcontracts                   4. Sends it to the right          A spreadsheet (CSV) to load into
 Who approves what                   person to approve                your accounting software
                                                                    Totals per job and per contract
```

What it never does: pay anyone, approve a bill on its own, or change your accounting software directly.

This folder is the complete app. It runs on your own computer or server. Your data stays there.

## What you need

| Input | Needed? | What it is for | Where to get it |
| --- | --- | --- | --- |
| Docker Desktop | Required | Runs Trestle and its database on your computer | https://www.docker.com/products/docker-desktop/ (install it, then start it) |
| Anthropic API key | Optional | Turns on AI reading of bills and the AI assistant. Without it you type each bill's details in by hand. | https://console.anthropic.com/settings/keys (starts with `sk-ant-`) |
| Passwords | Made for you | Protect the database and sign-in tokens | The setup script creates them. You never type them. |

## Start it

Open a terminal in this folder and run the setup script:

- Mac or Linux: `./setup.sh`
- Windows: right-click `setup.ps1` and choose **Run with PowerShell**

It walks through four steps:

1. **Docker.** It checks that Docker is installed and running.
2. **Passwords.** It creates random ones and saves them in a file called `.env`.
3. **Anthropic API key.** It asks you to paste your key, checks it with Anthropic, and saves it. Press Enter to skip; you can run the setup again later to add one.
4. **Start.** It offers to start Trestle, waits until it is ready, and prints the address to open: http://localhost:8080 .

The first start downloads and builds everything, which takes a few minutes. Inside the app, a yellow notice tells you when AI is off.

If you prefer to do it by hand: copy `.env.example` to `.env`, replace each `change-me...` value with a long random string, paste your key after `ANTHROPIC_API_KEY=`, then run `docker compose up --build`.

## First use

1. Click **Try it with sample bills** and create an account. Accounts are stored only in your database.
2. Choose **Create demo workspace**. You get a fictional company with 15 sample bills in different states: some need review, some wait for approval, some are flagged as possible repeats or overcharges, some are ready to export.
3. Try the loop: open a bill in review, fix what is flagged, submit it, approve it, then go to **Accounting exports** to download the CSV.
4. To upload a bill of your own, go to **Invoices** and click **Upload invoices**. A sample bill is included at `apps/untitled-app-6ac8544d7b02af3fede23b8b/public/demo/sample-invoice.pdf`.
5. When you are ready for real use, click **Add a real company**, import your vendors, jobs and budget lines from CSV, and invite your team in **Settings**.

## Everyday commands

| To | Run |
| --- | --- |
| Start in the background | `docker compose up -d` |
| Stop | `docker compose down` |
| See what it is doing | `docker compose logs -f app` |
| Back up the database | `docker compose exec db pg_dump -U postgres trestle > backup.sql` |
| Delete everything, including all data | `docker compose down -v` |

Your data lives in two Docker volumes: `db-data` (the database) and `uploads` (the bill files). Stopping and restarting keeps them.

## Good to know

- **Who can sign up.** Anyone who can open the page can create an account. Once your team has accounts, set `ALLOW_SIGNUP=false` in `.env` and run `docker compose up -d` again.
- **Invitations.** This edition does not send email. When an owner invites someone, that person creates an account with the invited email address and joins automatically. So keep the server on a private network, or turn off sign-up after inviting.
- **Who sees what.** Each company's data is separated inside the database itself (Postgres row level security). Roles decide who can do what: owner, controller, AP specialist, project manager, viewer.
- **The AI.** Invoice documents are sent to Anthropic for reading when a key is set. Every value the AI fills in carries a confidence score, and low-confidence values are flagged for a person. The AI cannot approve, reject, pay or export. The assistant can only read data, and only what the signed-in user is allowed to see.
- **Internet access.** For use beyond your own computer, put Trestle behind a web server that provides HTTPS (for example Caddy or nginx).
- **Not built yet.** Expense tracking and compliance documents (insurance certificates, lien waivers). There is no direct connection to any accounting software: Trestle produces a CSV you import, then you record which rows posted.

## How it is built (for technical readers)

| Part | What it is |
| --- | --- |
| `apps/untitled-app-6ac8544d7b02af3fede23b8b/` | The web app (React, TypeScript, Vite) |
| `prisma/migrations/` | The database: tables, access rules and workflow functions, in plain SQL |
| `backend/selfhost/server.ts` | The server: accounts, file storage, live updates, AI calls; serves the app |
| `backend/routes/` | Read and write routes shared with the hosted edition |
| `packages/` | Shared code: queries, database types, business objects |
| PostgREST (Docker image) | Exposes the database's tables and functions over HTTP as the signed-in user |

All business rules (approval routing, duplicate checks, commitment checks, export batches) live in the database migrations, so they apply the same way whichever part of the system makes a change.

To run without Docker you need Postgres 15 or newer, PostgREST 12, and Bun 1.4. Then: `bun install`, `bun run selfhost:build`, start the server with the variables from `.env.example` plus `DATABASE_URL` and `POSTGREST_URL`, and point PostgREST at the same database as described in `docker-compose.yml`.
