import type { ReactNode } from 'react';
import { ArrowDown, ArrowRight, HardHat } from 'lucide-react';

const INPUTS = [
  'Bills from your suppliers and subcontractors (PDF or a phone photo)',
  'Your lists of vendors, jobs and budget lines (a spreadsheet file)',
  'Your purchase orders and subcontracts',
  'Who approves what (for example, "over $10,000 needs the controller")',
];

const STEPS = [
  'Reads each bill: who sent it, how much, for what',
  'Assigns it to a job and a budget line',
  'Checks it: a repeat? more than the contract allows? a missing purchase order?',
  'Sends it to the right person to approve',
];

const OUTPUTS = [
  'Every bill entered and sorted, with unsure values marked for a person to check',
  'A short list of problems, each with the reason',
  'A record of who approved each bill, and when',
  'A spreadsheet file ready to load into your accounting software',
  'Totals per job and per contract: spent so far and what is left',
];

/** Public page for signed-out visitors: the problem, what goes in, what Trestle does, what comes out. */
export function Landing({ onStart }: { onStart: (mode: 'signIn' | 'signUp') => void }) {
  return (
    <main className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-md bg-amber-500 text-slate-900"><HardHat className="size-4" /></div>
            <span className="font-semibold text-slate-900">Trestle</span>
          </div>
          <button type="button" className="rounded-md px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100" onClick={() => onStart('signIn')}>Sign in</button>
        </div>
      </header>

      <section className="mx-auto max-w-3xl px-5 pb-8 pt-12 text-center">
        <h1 className="text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl">Bills in. Checked, approved bills out.</h1>
        <p className="mx-auto mt-4 max-w-2xl text-slate-600">
          A construction company gets a steady stream of bills. Before one is paid, someone has to read it, decide which
          job it belongs to, check it is not wrong or a repeat, get it approved, and type it into the accounting software.
          Trestle does the reading, sorting and checking. People still make every approval.
        </p>
      </section>

      <section className="mx-auto grid max-w-5xl items-stretch gap-3 px-5 md:grid-cols-[1fr_auto_1fr_auto_1fr]" aria-label="How Trestle works">
        <Box label="In" tone="in" title="You give it" items={INPUTS} />
        <Arrow />
        <Box label="Trestle" tone="work" title="It does" items={STEPS} numbered />
        <Arrow />
        <Box label="Out" tone="out" title="You get" items={OUTPUTS} />
      </section>

      <section className="mx-auto max-w-3xl px-5 py-10 text-center">
        <button type="button" className="inline-flex items-center gap-2 rounded-md bg-amber-500 px-5 py-2.5 text-sm font-semibold text-slate-900 hover:bg-amber-400" onClick={() => onStart('signUp')}>
          Try it with sample bills <ArrowRight className="size-4" />
        </button>
        <p className="mt-2 text-xs text-slate-500">Create an account, then choose "Create demo workspace". The sample company and its bills are fictional.</p>
        <p className="mx-auto mt-8 max-w-2xl text-sm text-slate-600">
          <span className="font-medium text-slate-900">What it never does:</span> pay anyone, approve a bill on its own, or change
          your accounting software directly. You load the file it gives you, then tell it what was accepted.
        </p>
      </section>
    </main>
  );
}

const TONES = {
  in: { box: 'border-sky-200 bg-white', tag: 'bg-sky-100 text-sky-800' },
  work: { box: 'border-amber-300 bg-amber-50', tag: 'bg-amber-200 text-amber-900' },
  out: { box: 'border-emerald-200 bg-white', tag: 'bg-emerald-100 text-emerald-800' },
};

function Box({ label, tone, title, items, numbered }: { label: string; tone: keyof typeof TONES; title: string; items: string[]; numbered?: boolean }) {
  const t = TONES[tone];
  return (
    <div className={`rounded-lg border p-5 ${t.box}`}>
      <span className={`inline-block rounded px-2 py-0.5 text-xs font-semibold uppercase tracking-wide ${t.tag}`}>{label}</span>
      <h2 className="mt-2 text-lg font-semibold text-slate-900">{title}</h2>
      <ul className="mt-3 flex flex-col gap-2.5 text-sm text-slate-700">
        {items.map((item, i) => (
          <li key={item} className="flex gap-2">
            <span className="shrink-0 text-slate-400">{numbered ? `${i + 1}.` : '•'}</span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Arrow(): ReactNode {
  return (
    <div className="flex items-center justify-center text-slate-400" aria-hidden>
      <ArrowRight className="hidden size-6 md:block" />
      <ArrowDown className="size-6 md:hidden" />
    </div>
  );
}
