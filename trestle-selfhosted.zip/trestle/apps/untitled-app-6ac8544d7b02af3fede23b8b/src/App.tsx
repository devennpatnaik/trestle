import { useEffect, useState } from 'react';
import { HardHat } from 'lucide-react';
import { client, useSession } from './client';
import { refreshData, useRows } from './db';
import { queries } from '@project/queries';
import { rpc, errorText } from './lib/api';
import { Button, ErrorNote, Field, Input, Loading, Notice } from './components/ui';
import { OrgProvider } from './org';
import { Landing } from './landing';
import { Shell } from './shell';
import type { Membership } from './types';

export function App() {
  const { data: session, isPending } = useSession();
  if (isPending) return <div className="p-6"><Loading /></div>;
  if (!session?.user) return <SignedOut />;
  // The sign-in form's own address is not a workspace page; land on the overview after signing in.
  if (/^#\/sign-(in|up)$/.test(window.location.hash)) window.history.replaceState(null, '', '#/');
  return <Workspace userId={session.user.id} email={session.user.email} verified={Boolean(session.user.emailVerified)} />;
}

function Workspace({ userId, email, verified }: { userId: string; email: string; verified: boolean }) {
  const [invites, setInvites] = useState<{ joined: number; pending_unverified: number } | null>(null);
  const [inviteError, setInviteError] = useState('');
  const { rows: memberships, loading, error } = useRows<Membership>(
    queries.memberships, [userId]);

  useEffect(() => {
    rpc<{ joined: number; pending_unverified: number }>('accept_invitations').then(v => { setInvites(v); refreshData(); }).catch(e => setInviteError(errorText(e)));
  }, [verified]);

  if (loading) return <div className="p-6"><Loading label="Loading your companies…" /></div>;
  if (error && memberships.length === 0) return <div className="p-6"><ErrorNote>Could not load your companies: {error}</ErrorNote><Button className="mt-3" onClick={refreshData}>Try again</Button></div>;
  if (memberships.length === 0) return <Onboarding userId={userId} email={email} invites={invites} inviteError={inviteError} onInvitesChanged={setInvites} />;
  return (
    <OrgProvider userId={userId} email={email} memberships={memberships}>
      <Shell />
    </OrgProvider>
  );
}

function Onboarding({ userId, email, invites, inviteError, onInvitesChanged }: {
  userId: string; email: string; invites: { joined: number; pending_unverified: number } | null; inviteError: string;
  onInvitesChanged: (v: { joined: number; pending_unverified: number }) => void;
}) {
  const [name, setName] = useState('');
  const [entity, setEntity] = useState('');
  const [busy, setBusy] = useState<'' | 'create' | 'demo'>('');
  const [error, setError] = useState('');
  const create = async (demo: boolean) => {
    setBusy(demo ? 'demo' : 'create'); setError('');
    try {
      const id = demo ? await rpc<string>('create_demo_organization') : await rpc<string>('create_organization', { p_name: name, p_legal_entity: entity || null });
      localStorage.setItem(`finops:org:${userId}`, id); window.location.hash = '#/'; window.location.reload();
    } catch (e) { setError(errorText(e)); } finally { setBusy(''); }
  };
  return (
    <main className="min-h-screen bg-slate-50 px-4 py-10">
      <div className="mx-auto flex max-w-xl flex-col gap-5">
        <Brand />
        <div className="flex items-center justify-between text-sm text-slate-500">
          <span>Signed in as {email}</span>
          <button type="button" className="underline" onClick={() => client.auth.signOut()}>Sign out</button>
        </div>
        {invites && invites.pending_unverified > 0 && <VerifyEmail email={email} onVerified={onInvitesChanged} />}
        <ErrorNote>{inviteError}</ErrorNote>
        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-slate-900">Set up your company</h2>
          <p className="mt-1 text-sm text-slate-500">You become the owner. Next you import your vendors, jobs, cost codes, GL accounts and commitments from CSV (any ERP export works), then invite your team.</p>
          <form className="mt-4 flex flex-col gap-3" onSubmit={e => { e.preventDefault(); create(false); }}>
            <Field label="Company name"><Input aria-label="Company name" value={name} onChange={e => setName(e.target.value)} required /></Field>
            <Field label="Legal entity (optional)" hint="Shown on exports. Additional entities can be recorded per project."><Input aria-label="Legal entity" value={entity} onChange={e => setEntity(e.target.value)} /></Field>
            <Button type="submit" variant="primary" busy={busy === 'create'} disabled={!name.trim()}>Create company</Button>
          </form>
        </section>
        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-slate-900">Just evaluating?</h2>
          <p className="mt-1 text-sm text-slate-500">Create a separate demo workspace filled with clearly labeled 15 fictional invoices across review, approval and export, plus vendors, jobs, commitments and change orders. It never mixes with a real company.</p>
          <Button className="mt-3" busy={busy === 'demo'} onClick={() => create(true)}>Create demo workspace</Button>
        </section>
        <p className="text-xs text-slate-500">Joining an existing company? Ask its owner to invite {email}; the invitation appears here once your email is verified.</p>
        <ErrorNote>{error}</ErrorNote>
      </div>
    </main>
  );
}

type OtpAuth = {
  emailOtp?: {
    sendVerificationOtp: (a: { email: string; type: 'email-verification' }) => Promise<{ error?: { message?: string } | null }>;
    verifyEmail: (a: { email: string; otp: string }) => Promise<{ error?: { message?: string } | null }>;
  };
};

function VerifyEmail({ email, onVerified }: { email: string; onVerified: (v: { joined: number; pending_unverified: number }) => void }) {
  const [sent, setSent] = useState(false);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const auth = client.auth as unknown as OtpAuth;
  const send = async () => {
    setBusy(true); setError('');
    try {
      const r = await auth.emailOtp!.sendVerificationOtp({ email, type: 'email-verification' });
      if (r?.error) throw new Error(r.error.message ?? 'Could not send the code');
      setSent(true);
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  const verify = async () => {
    setBusy(true); setError('');
    try {
      const r = await auth.emailOtp!.verifyEmail({ email, otp: code.trim() });
      if (r?.error) throw new Error(r.error.message ?? 'That code did not work');
      onVerified(await rpc('accept_invitations'));
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  return (
    <Notice tone="amber">
      <p className="font-medium">You have a pending invitation.</p>
      <p className="mt-1">Verify {email} to join. This stops anyone else from claiming an invitation meant for you.</p>
      {!sent ? <Button className="mt-2" busy={busy} onClick={send}>Email me a code</Button> : (
        <div className="mt-2 flex gap-2">
          <Input aria-label="Verification code" placeholder="6-digit code" value={code} onChange={e => setCode(e.target.value)} className="max-w-40" />
          <Button variant="primary" busy={busy} disabled={code.trim().length < 4} onClick={verify}>Verify and join</Button>
        </div>
      )}
      {error && <p className="mt-2 text-red-700">{error}</p>}
    </Notice>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-2">
      <div className="flex size-9 items-center justify-center rounded-md bg-amber-500 text-slate-900"><HardHat className="size-5" /></div>
      <div>
        <p className="font-semibold leading-tight text-slate-900">Trestle</p>
        <p className="text-xs text-slate-500">AP automation for construction finance teams</p>
      </div>
    </div>
  );
}

/** Signed-out visitors see the landing page first; #/sign-in and #/sign-up open the form directly. */
function SignedOut() {
  const fromHash = (): 'signIn' | 'signUp' | null => window.location.hash === '#/sign-up' ? 'signUp' : window.location.hash === '#/sign-in' ? 'signIn' : null;
  const [mode, setMode] = useState(fromHash);
  useEffect(() => {
    const onHash = () => setMode(fromHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  if (!mode) return <Landing onStart={m => { window.location.hash = m === 'signUp' ? '#/sign-up' : '#/sign-in'; }} />;
  return <SignIn key={mode} initialMode={mode} />;
}

function SignIn({ initialMode }: { initialMode: 'signIn' | 'signUp' }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [mode, setMode] = useState<'signIn' | 'signUp'>(initialMode);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true); setError('');
    try {
      const result = mode === 'signUp'
        ? await client.auth.signUp.email({ email, password, name: name || email })
        : await client.auth.signIn.email({ email, password });
      setError(result.error?.message ?? '');
    } catch (caught) {
      setError(caught instanceof Error && caught.message ? caught.message : 'Sign in failed');
    } finally { setBusy(false); }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
      <div className="flex w-full max-w-sm flex-col gap-5">
        <Brand />
        <form onSubmit={e => { e.preventDefault(); submit(); }} className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-5">
          <h1 className="font-semibold text-slate-900">{mode === 'signIn' ? 'Sign in' : 'Create your account'}</h1>
          {mode === 'signUp' && <Field label="Full name"><Input aria-label="Full name" value={name} onChange={e => setName(e.target.value)} /></Field>}
          <Field label="Work email"><Input aria-label="Work email" type="email" value={email} onChange={e => setEmail(e.target.value)} required /></Field>
          <Field label="Password"><Input aria-label="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} minLength={8} required /></Field>
          <Button type="submit" variant="primary" busy={busy}>{mode === 'signIn' ? 'Sign in' : 'Create account'}</Button>
          <button type="button" className="text-sm text-slate-600 underline" onClick={() => { setMode(mode === 'signIn' ? 'signUp' : 'signIn'); setError(''); }}>
            {mode === 'signIn' ? 'New here? Create an account' : 'Have an account? Sign in'}
          </button>
          <ErrorNote>{error}</ErrorNote>
        </form>
        <a href="#/" className="text-center text-sm text-slate-500 underline">What is Trestle?</a>
      </div>
    </main>
  );
}
