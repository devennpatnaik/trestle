import { useCallback, useState } from 'react';
import { authHeaders, backendUrl, readJson } from './runtime';
import type { AgentChat, ChatMessage } from './use-agent-chat';

/**
 * The assistant chat in the self-hosted edition: each question goes to the server's /assistant route with the
 * conversation so far, and the answer comes back whole. The conversation lives in the page, not on the server.
 */
export function useLocalChat(): Pick<AgentChat, 'messages' | 'toolCalls' | 'status' | 'error' | 'send' | 'newChat'> {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [status, setStatus] = useState<AgentChat['status']>('idle');
  const [error, setError] = useState<string | null>(null);

  const send = useCallback(async (message: string) => {
    if (status === 'running') return;
    const turnId = crypto.randomUUID();
    const next: ChatMessage[] = [...messages, { id: `user:${turnId}`, turnId, role: 'user', content: message, status: 'complete' }];
    setMessages(next);
    setStatus('running');
    setError(null);
    try {
      const response = await fetch(backendUrl('/assistant'), {
        method: 'POST',
        headers: { ...(await authHeaders()), 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.map(m => ({ role: m.role, content: m.content })) }),
      });
      const { reply } = await readJson<{ reply: string }>(response);
      setMessages([...next, { id: `assistant:${turnId}`, turnId, role: 'assistant', content: reply, status: 'complete' }]);
      setStatus('idle');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
      setStatus('error');
    }
  }, [messages, status]);

  const newChat = useCallback(() => { setMessages([]); setError(null); setStatus('idle'); }, []);

  return { messages, toolCalls: [], status, error, send, newChat };
}
