import { useState } from 'react';
import { Download } from 'lucide-react';
import { client } from '../client';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg } from '../org';
import { downloadText, errorText, fmtDateTime, fmtMoney, must, rpc, toCsv } from '../lib/api';
import { Badge, Button, Card, Empty, ErrorNote, Input, Modal, Notice, PageHeader, Select, Table, Td, Th } from '../components/ui';
import { CsvImport, req, type Mapped } from '../components/csv-import';
import { SyncBadge } from './shared';

type Batch = { id: string; batch_number: number; target: string; status: string; invoice_count: number; invoice_total: string; allocation_total: string; created_by: string; created_at: string; synced: number; failed: number; exported: number };
type Ready = { n: number; amount: string; failed: number; failed_amount: string };

const BATCHES_SQL = queries.syncBatches;

const READY_SQL = queries.syncReady;

type SyncRecord = { id: string; invoice_id: string; idempotency_key: string; attempt: number; status: string; external_id: string | null; error: string | null; payload: Snapshot };
type Snapshot = {
  invoice_id: string; vendor_code: string | null; vendor_name: string | null; vendor_external_id: string | null; invoice_number: string | null; invoice_date: string | null;
  due_date: string | null; payment_terms: string | null; currency: string; subtotal: string | null; tax_amount: string | null; retainage_amount: string | null; total_amount: string;
  commitment_number: string | null; commitment_external_id: string | null; description: string | null;
  allocations: { project_code: string | null; project_external_id: string | null; cost_code: string | null; cost_type: string | null; gl_account: string | null; amount: string; description: string | null }[];
};

export const EXPORT_COLUMNS = ['idempotency_key', 'batch_number', 'attempt', 'vendor_code', 'vendor_external_id', 'vendor_name', 'invoice_number', 'invoice_date', 'due_date', 'payment_terms', 'currency',
  'invoice_subtotal', 'invoice_tax', 'invoice_retainage', 'invoice_total', 'commitment_number', 'commitment_external_id', 'line_no', 'job', 'job_external_id', 'cost_code', 'cost_type', 'gl_account', 'line_amount', 'line_description'];

function flatten(batchNumber: number, records: SyncRecord[]) {
  return records.flatMap(r => {
    const p = r.payload;
    const allocations = p.allocations?.length ? p.allocations : [{ project_code: null, project_external_id: null, cost_code: null, cost_type: null, gl_account: null, amount: p.total_amount, description: null }];
    return allocations.map((a, i) => ({
      idempotency_key: r.idempotency_key, batch_number: batchNumber, attempt: r.attempt, vendor_code: p.vendor_code, vendor_external_id: p.vendor_external_id, vendor_name: p.vendor_name,
      invoice_number: p.invoice_number, invoice_date: p.invoice_date, due_date: p.due_date, payment_terms: p.payment_terms, currency: p.currency,
      invoice_subtotal: p.subtotal, invoice_tax: p.tax_amount, invoice_retainage: p.retainage_amount, invoice_total: p.total_amount,
      commitment_number: p.commitment_number, commitment_external_id: p.commitment_external_id, line_no: i + 1, job: a.project_code, job_external_id: a.project_external_id,
      cost_code: a.cost_code, cost_type: a.cost_type, gl_account: a.gl_account, line_amount: a.amount, line_description: a.description ?? p.description,
    }));
  });
}

async function loadRecords(batchId: string): Promise<SyncRecord[]> {
  return await must(client.from('sync_records').select('id, invoice_id, idempotency_key, attempt, status, external_id, error, payload').eq('batch_id', batchId).order('idempotency_key')) as SyncRecord[];
}

export default function Integrations() {
  const { orgId, lookups, can, memberName, role } = useOrg();
  const canSync = can('admin') || (role === 'ap_clerk' && Boolean(lookups.settings?.ap_can_sync));
  const { rows: batches } = useRows<Batch>(BATCHES_SQL, [orgId]);
  const { rows: ready } = useRows<Ready>(READY_SQL, [orgId]);
  const r = ready[0];
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [detail, setDetail] = useState<Batch | null>(null);

  const createBatch = async () => {
    setBusy(true); setError(''); setNotice('');
    try {
      const res = await rpc<{ batch_id: string; batch_number: number; invoice_count: number; invoice_total: string }>('create_export_batch', { p_org: orgId });
      const records = await loadRecords(res.batch_id);
      downloadText(`ap-export-batch-${res.batch_number}.csv`, toCsv(flatten(res.batch_number, records), EXPORT_COLUMNS));
      setNotice(`Batch #${res.batch_number} created with ${res.invoice_count} invoice(s), ${fmtMoney(res.invoice_total)}. The CSV downloaded. Import it into your accounting system, then upload the results file here.`);
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  const download = async (b: Batch) => {
    setError('');
    try { downloadText(`ap-export-batch-${b.batch_number}.csv`, toCsv(flatten(b.batch_number, await loadRecords(b.id)), EXPORT_COLUMNS)); } catch (e) { setError(errorText(e)); }
  };

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Accounting exports" subtitle="Prepare approved invoices as CSV, import them into your accounting system, then record the result. Failed imports can be retried with the same invoice key." />
      {lookups.org?.is_demo && <Notice tone="amber">Demo only: historical posting results are simulated. Do not import these fictional invoices into a real ledger. Use a SIMULATED- reference when practicing confirmation.</Notice>}
      <Card title="Accounting connection">
        <div className="flex flex-col gap-2 text-sm text-slate-700">
          <p><Badge tone="blue">CSV export / import</Badge> <span className="ml-1">Generic CSV output. Map its columns to your accounting system’s supported import template and test a small batch first. Compatibility depends on that system’s format.</span></p>
          <p><Badge>Not available</Badge> <span className="ml-1">Direct API connectors (Procore, Sage, Viewpoint, QuickBooks Online). Nothing is posted to an external system automatically; you import the file yourself and upload the results.</span></p>
          <p className="text-xs text-slate-500">Target label on exports: <strong>{lookups.settings?.export_target ?? 'generic_csv'}</strong> (change in Settings). Each invoice row carries an idempotency key (INV-…) so your import can reject repeats.</p>
        </div>
      </Card>
      {!canSync && <Notice tone="amber">Only controllers and owners can export to accounting{role === 'ap_clerk' ? ' (an owner can allow AP specialists in Settings)' : ''}.</Notice>}
      {r && (
        <Card title="Ready to export" actions={canSync && <Button variant="primary" busy={busy} disabled={r.n + r.failed === 0} onClick={createBatch}><Download className="size-4" />Create export batch</Button>}>
          <div className="flex flex-wrap gap-6 text-sm">
            <div><p className="text-xs text-slate-500">Approved, never exported</p><p className="text-lg font-semibold tabular-nums">{r.n} · {fmtMoney(r.amount)}</p></div>
            <div><p className="text-xs text-slate-500">Failed previously, will be retried</p><p className={`text-lg font-semibold tabular-nums ${r.failed ? 'text-red-700' : ''}`}>{r.failed} · {fmtMoney(r.failed_amount)}</p></div>
          </div>
          <p className="mt-2 text-xs text-slate-500">A batch takes every approved invoice that is not already exported or posted, using the coding exactly as approved. Export is refused if invoice and allocation totals do not reconcile.</p>
        </Card>
      )}
      <ErrorNote>{error}</ErrorNote>
      {notice && <Notice tone="green">{notice}</Notice>}
      <Card title="Export batches" bodyClassName="p-0">
        {batches.length === 0 ? <div className="p-4"><Empty title="No exports yet">Approved invoices appear under “Ready to export”.</Empty></div> : (
          <Table>
            <thead><tr><Th>Batch</Th><Th>Created</Th><Th className="text-right">Invoices</Th><Th className="text-right">Total</Th><Th>Status</Th><Th>Results</Th><Th /></tr></thead>
            <tbody>{batches.map(b => (
              <tr key={b.id}>
                <Td className="font-medium">#{b.batch_number}<div className="text-xs font-normal text-slate-500">{b.target}</div></Td>
                <Td className="text-xs">{fmtDateTime(b.created_at)}<div className="text-slate-500">{memberName(b.created_by)}</div></Td>
                <Td className="text-right">{b.invoice_count}</Td>
                <Td className="text-right tabular-nums">{fmtMoney(b.invoice_total)}</Td>
                <Td><Badge tone={b.status === 'reconciled' ? 'green' : b.status === 'exported' ? 'amber' : 'red'}>{b.status === 'exported' ? 'awaiting results' : b.status.replace('_', ' ')}</Badge></Td>
                <Td className="text-xs">{b.synced} posted · {b.failed} failed · {b.exported} pending</Td>
                <Td className="whitespace-nowrap text-right"><Button size="sm" onClick={() => download(b)}>CSV</Button> <Button size="sm" onClick={() => setDetail(b)}>Results</Button></Td>
              </tr>
            ))}</tbody>
          </Table>
        )}
      </Card>
      <BatchDetail batch={detail} onClose={() => setDetail(null)} canSync={canSync} />
    </div>
  );
}

function BatchDetail({ batch, onClose, canSync }: { batch: Batch | null; onClose: () => void; canSync: boolean }) {
  const { rows } = useRows<{ id: string; invoice_id: string; idempotency_key: string; attempt: number; status: string; external_id: string | null; error: string | null; invoice_number: string | null; vendor: string | null; total: string | null; newer: boolean }>(
    queries.syncRecords, [batch?.id ?? '00000000-0000-0000-0000-000000000000']);
  const [result, setResult] = useState<{ synced: number; failed: number; unchanged: number; problems: { key: string; problem: string }[] } | null>(null);
  const [manual, setManual] = useState<Record<string, { status: string; value: string }>>({});
  const [error, setError] = useState('');
  type Res = { key: string; status: string; external_id: string | null; error: string | null };
  const mapRow = (r: Record<string, string>): Mapped<Res> => {
    const key = req(r, 'idempotency_key') ?? req(r, 'key');
    const status = (req(r, 'status') ?? '').toLowerCase();
    if (!key) return { ok: false, error: 'idempotency_key is empty' };
    if (!['synced', 'failed'].includes(status)) return { ok: false, error: 'status must be synced or failed' };
    if (status === 'synced' && !req(r, 'external_id')) return { ok: false, error: 'external_id is required for synced rows' };
    return { ok: true, value: { key, status, external_id: req(r, 'external_id'), error: req(r, 'error') } };
  };
  const submit = async (results: Res[]) => {
    const res = await rpc<{ synced: number; failed: number; unchanged: number; problems: { key: string; problem: string }[] }>('record_sync_results', { p_batch: batch!.id, p_results: results });
    setResult(res);
    return `${res.synced} posted, ${res.failed} failed, ${res.unchanged} unchanged${res.problems.length ? `, ${res.problems.length} not applied (see below)` : ''}.`;
  };
  const keys = [...new Set(rows.map(r => r.idempotency_key))];
  return (
    <Modal open={!!batch} wide title={`Batch #${batch?.batch_number ?? ''} results`} onClose={() => { setResult(null); setManual({}); onClose(); }}>
      <p className="text-sm text-slate-600">After importing the CSV into your accounting system, upload a results file with one row per invoice: <code>idempotency_key, status (synced|failed), external_id, error</code>. Or record results one by one below.</p>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={() => downloadText(`batch-${batch?.batch_number}-results-template.csv`, toCsv(keys.map(k => ({ idempotency_key: k, status: '', external_id: '', error: '' })), ['idempotency_key', 'status', 'external_id', 'error']))}>Download results template</Button>
        {canSync && <CsvImport title="Import sync results" buttonLabel="Upload results file" mapRow={mapRow} onImport={submit}
          columns={[{ name: 'idempotency_key', required: true, example: 'INV-…' }, { name: 'status', required: true, example: 'synced' }, { name: 'external_id', example: 'AP-000123' }, { name: 'error' }]} />}
      </div>
      {result && result.problems.length > 0 && <Notice tone="amber"><p className="font-medium">Not applied:</p><ul className="list-inside list-disc">{result.problems.map(p => <li key={p.key}>{p.key}: {p.problem}</li>)}</ul></Notice>}
      <ErrorNote>{error}</ErrorNote>
      <Table>
        <thead><tr><Th>Invoice</Th><Th className="text-right">Total</Th><Th>Status</Th><Th>External ID / error</Th>{canSync && <Th>Record</Th>}</tr></thead>
        <tbody>{rows.map(r => {
          const m = manual[r.id] ?? { status: 'synced', value: '' };
          return (
            <tr key={r.id}>
              <Td><a className="font-medium hover:underline" href={`#/invoices/${r.invoice_id}`} onClick={onClose}>{r.invoice_number ?? r.idempotency_key}</a><div className="text-xs text-slate-500">{r.vendor} · attempt {r.attempt}</div></Td>
              <Td className="text-right tabular-nums">{fmtMoney(r.total)}</Td>
              <Td><SyncBadge status={r.status} />{r.newer && <div className="text-xs text-slate-500">Retried in a later batch</div>}</Td>
              <Td className="text-xs">{r.external_id ?? r.error ?? '—'}</Td>
              {canSync && <Td>{r.status === 'exported' && !r.newer && (
                <div className="flex gap-1">
                  <Select aria-label="Result status" className="w-24" value={m.status} onChange={e => setManual({ ...manual, [r.id]: { ...m, status: e.target.value } })}><option value="synced">Posted</option><option value="failed">Failed</option></Select>
                  <Input aria-label={m.status === 'synced' ? 'External ID' : 'Error'} placeholder={m.status === 'synced' ? 'External ID' : 'Error'} className="w-32" value={m.value} onChange={e => setManual({ ...manual, [r.id]: { ...m, value: e.target.value } })} />
                  <Button size="sm" disabled={!m.value.trim()} onClick={async () => {
                    setError('');
                    try { await submit([{ key: r.idempotency_key, status: m.status, external_id: m.status === 'synced' ? m.value.trim() : null, error: m.status === 'failed' ? m.value.trim() : null }]); } catch (e) { setError(errorText(e)); }
                  }}>Save</Button>
                </div>)}</Td>}
            </tr>
          );
        })}</tbody>
      </Table>
    </Modal>
  );
}
