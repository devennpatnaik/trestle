import { Fragment, useState } from 'react';
import { Bot, Cog, User } from 'lucide-react';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg } from '../org';
import { downloadText, fmtDateTime, toCsv } from '../lib/api';
import { Badge, Button, Card, Empty, Loading, PageHeader, Select, Table, Tabs, Td, Th } from '../components/ui';
import type { AgentRun, AuditEvent } from '../types';

const AGENTS: Record<string, { label: string; kind: string; what: string }> = {
  invoice_intake: { label: 'Invoice intake agent', kind: 'AI (language model)', what: 'Reads the document, extracts fields with confidence scores, proposes vendor and job cost coding. Cannot submit, approve or export.' },
  matching_engine: { label: 'Matching & controls engine', kind: 'Deterministic rules', what: 'Matches vendors and commitments, checks duplicates, totals, overbilling, retainage, coding and required fields.' },
  approval_router: { label: 'Approval router', kind: 'Deterministic rules', what: 'Builds approval steps from your rules, project managers and approval limits.' },
};

export default function Activity() {
  const [tab, setTab] = useState<'runs' | 'audit'>('runs');
  return (
    <div>
      <PageHeader title="Agent activity" subtitle="Everything the AI agent and the rules engines did, and the full audit log of people's actions." />
      <div className="mb-4 grid gap-3 md:grid-cols-3">
        {Object.entries(AGENTS).map(([k, a]) => (
          <div key={k} className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
            <div className="flex items-center gap-2 font-medium">{k === 'invoice_intake' ? <Bot className="size-4 text-violet-600" /> : <Cog className="size-4 text-slate-500" />}{a.label}</div>
            <Badge tone={k === 'invoice_intake' ? 'violet' : 'gray'} className="mt-1">{a.kind}</Badge>
            <p className="mt-1 text-xs text-slate-500">{a.what}</p>
          </div>
        ))}
      </div>
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'runs', label: 'Agent runs' }, { id: 'audit', label: 'Audit log' }]} />
      {tab === 'runs' ? <Runs /> : <Audit />}
    </div>
  );
}

function Runs() {
  const { orgId, memberName } = useOrg();
  const [agent, setAgent] = useState('all');
  const { rows, loading } = useRows<AgentRun & { invoice_number: string | null }>(queries.agentRuns, [orgId, agent]);
  const [open, setOpen] = useState<string | null>(null);
  return (
    <Card bodyClassName="p-0" actions={<Select aria-label="Agent" className="w-56" value={agent} onChange={e => setAgent(e.target.value)}><option value="all">All agents</option>{Object.entries(AGENTS).map(([k, a]) => <option key={k} value={k}>{a.label}</option>)}</Select>} title="Recent runs">
      {loading ? <div className="px-4"><Loading /></div> : rows.length === 0 ? <div className="p-4"><Empty title="No agent runs yet">Runs appear when invoices are uploaded and checked.</Empty></div> : (
        <Table>
          <thead><tr><Th>When</Th><Th>Agent</Th><Th>Invoice</Th><Th>Result</Th><Th>Triggered by</Th><Th /></tr></thead>
          <tbody>{rows.map(r => (<Fragment key={r.id}>
            <tr className="hover:bg-slate-50">
              <Td className="whitespace-nowrap text-xs">{fmtDateTime(r.started_at)}{r.finished_at && <div className="text-slate-500">{Math.max(0, Math.round((new Date(r.finished_at).getTime() - new Date(r.started_at).getTime()) / 100) / 10)}s</div>}</Td>
              <Td>{AGENTS[r.agent]?.label ?? r.agent} <Badge tone={r.kind === 'ai' ? 'violet' : 'gray'}>{r.kind === 'ai' ? 'AI' : 'rules'}</Badge></Td>
              <Td>{r.invoice_id ? <a className="hover:underline" href={`#/invoices/${r.invoice_id}`}>{r.invoice_number ?? 'invoice'}</a> : '—'}</Td>
              <Td><Badge tone={r.status === 'succeeded' ? 'green' : r.status === 'failed' ? 'red' : 'amber'}>{r.status}</Badge> <span className="text-xs text-slate-600">{r.summary ?? r.error}</span></Td>
              <Td className="text-xs">{memberName(r.triggered_by)}</Td>
              <Td><Button size="sm" variant="ghost" onClick={() => setOpen(open === r.id ? null : r.id)}>{open === r.id ? 'Hide' : 'Details'}</Button></Td>
            </tr>
            {open === r.id && <tr key={`${r.id}-d`}><Td colSpan={6}><pre className="max-h-80 overflow-auto rounded bg-slate-50 p-2 text-xs">{JSON.stringify({ output: r.output, error: r.error }, null, 2)}</pre></Td></tr>}
          </Fragment>))}</tbody>
        </Table>
      )}
    </Card>
  );
}

function Audit() {
  const { orgId, memberName } = useOrg();
  const [actor, setActor] = useState('all');
  const { rows, loading } = useRows<AuditEvent & { invoice_number: string | null }>(queries.auditEvents, [orgId, actor]);
  return (
    <Card bodyClassName="p-0" title="Audit log" actions={<>
      <Select aria-label="Actor" className="w-40" value={actor} onChange={e => setActor(e.target.value)}><option value="all">Everyone</option><option value="user">People</option><option value="agent">AI agent</option><option value="system">Rules engine</option></Select>
      <Button disabled={!rows.length} onClick={() => downloadText('audit-log.csv', toCsv(rows.map(r => ({ time: r.created_at, actor_kind: r.actor_kind, actor: memberName(r.actor_user_id), action: r.action, entity: r.entity_type, invoice: r.invoice_number, summary: r.summary, details: JSON.stringify(r.details) }))))}>Export CSV</Button>
    </>}>
      <p className="px-4 pt-3 text-xs text-slate-500">Audit events are written by the database itself and cannot be edited or deleted from the app.</p>
      {loading ? <div className="px-4"><Loading /></div> : (
        <Table className="mt-2">
          <thead><tr><Th>When</Th><Th>Who</Th><Th>What</Th><Th>Record</Th></tr></thead>
          <tbody>{rows.map(e => (
            <tr key={e.id}>
              <Td className="whitespace-nowrap text-xs">{fmtDateTime(e.created_at)}</Td>
              <Td className="text-xs"><span className="inline-flex items-center gap-1">{e.actor_kind === 'agent' ? <Bot className="size-3.5 text-violet-600" /> : e.actor_kind === 'system' ? <Cog className="size-3.5" /> : <User className="size-3.5" />}{e.actor_kind === 'agent' ? 'AI agent' : e.actor_kind === 'system' ? 'Rules engine' : memberName(e.actor_user_id)}</span></Td>
              <Td>{e.summary}</Td>
              <Td className="text-xs">{e.invoice_id ? <a className="hover:underline" href={`#/invoices/${e.invoice_id}`}>{e.invoice_number ?? 'invoice'}</a> : e.entity_type}</Td>
            </tr>
          ))}</tbody>
        </Table>
      )}
    </Card>
  );
}
