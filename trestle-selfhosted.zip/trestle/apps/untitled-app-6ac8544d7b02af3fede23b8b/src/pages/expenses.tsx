import { PageHeader } from '../components/ui';
import { Phase3 } from './shared';

export default function Expenses() {
  return (
    <div>
      <PageHeader title="Expenses" subtitle="Card transactions, receipts and reimbursements." />
      <Phase3 title="Expense and card management">
        <p>Receipt capture, card feed import, job coding of card spend and reimbursements are planned for a later phase. None of it is built yet, so this page has no data and does nothing.</p>
        <p>For now, vendor bills for job costs go through <a className="underline" href="#/invoices">Invoices</a>, which supports PDF and photo uploads, AI coding and approval.</p>
      </Phase3>
    </div>
  );
}
