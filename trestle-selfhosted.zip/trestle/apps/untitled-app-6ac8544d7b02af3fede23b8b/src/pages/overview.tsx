import { DemoGuide } from '../components/demo-guide';
import { useRows } from '../db';
import { ATTENTION_WHERE, queries } from '@project/queries';
import { useOrg, go } from '../org';
import { fmtMoney, num } from '../lib/api';
import { Button, Card, Empty, Loading, Notice, PageHeader, Stat } from '../components/ui';
import { InvoiceTable, invoiceListSql, type InvoiceRow } from './invoices';

type Stats = {
  in_review: number; blocked: number; flagged: number; duplicates: number; extracting: number; extraction_failed: number;
  awaiting_approval: number; awaiting_amount: string; oldest_awaiting_hours: number | null;
  ready_count: number; ready_amount: string; exported_count: number; sync_failed: number;
  received_30d: number; approved_30d: number; approved_amount_30d: string;
  median_hours_to_approve: number | null; fields_extracted_30d: number; fields_corrected_30d: number;
};

const STATS_SQL = queries.overviewStats;

export default function Overview() {
  const { orgId, lookups, can, lookupsLoading } = useOrg();
  const { rows, loading } = useRows<Stats>(STATS_SQL, [orgId]);
  const { rows: attention } = useRows<InvoiceRow>(invoiceListSql(ATTENTION_WHERE), [orgId, '']);
  const s = rows[0];
  const setup = [
    { done: lookups.vendors.length > 0, label: 'Import vendors', href: 'vendors' },
    { done: lookups.projects.length > 0, label: 'Import jobs and assign project managers', href: 'projects' },
    { done: lookups.cost_codes.length > 0, label: 'Import cost codes', href: 'projects' },
    { done: lookups.commitments.length > 0, label: 'Import purchase orders and subcontracts', href: 'projects' },
    { done: lookups.members.length > 1, label: 'Invite your team', href: 'settings' },
  ];
  const setupLeft = setup.filter(x => !x.done);
  if (loading || lookupsLoading) return <Loading />;
  const correctionRate = s && s.fields_extracted_30d > 0 ? Math.round((s.fields_corrected_30d / s.fields_extracted_30d) * 1000) / 10 : null;

  return (
    <div className="flex flex-col gap-4">
      <PageHeader title="Overview" subtitle={`${lookups.org?.name ?? ''} · accounts payable work queues`} actions={can('ap') && <Button variant="primary" onClick={() => go('invoices')}>Upload or review invoices</Button>} />
      <DemoGuide />
      {!lookups.org?.is_demo && setupLeft.length > 0 && can('ap') && (
        <Notice>
          <p className="font-medium">Finish setting up</p>
          <ul className="mt-1 list-inside list-disc">{setupLeft.map(x => <li key={x.label}><a className="underline" href={`#/${x.href}`}>{x.label}</a></li>)}</ul>
        </Notice>
      )}
      {s && <>
        <section>
          <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Review</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <Stat label="In review" value={s.in_review} onClick={() => go('invoices?filter=needs_review')} />
            <Stat label="Blocked by exceptions" value={s.blocked} tone={s.blocked ? 'red' : 'gray'} onClick={() => go('invoices?filter=blocked')} />
            <Stat label="Fields to verify" value={s.flagged} tone={s.flagged ? 'amber' : 'gray'} hint="Invoices with low-confidence AI fields" onClick={() => go('invoices?filter=needs_review')} />
            <Stat label="Possible duplicates" value={s.duplicates} tone={s.duplicates ? 'amber' : 'gray'} onClick={() => go('invoices?filter=duplicates')} />
            <Stat label="AI reading" value={s.extracting} tone="violet" />
            <Stat label="AI could not read" value={s.extraction_failed} tone={s.extraction_failed ? 'red' : 'gray'} />
          </div>
        </section>
        <section>
          <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Approval and accounting</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <Stat label="Awaiting approval" value={s.awaiting_approval} tone="amber" onClick={() => go('approvals')} />
            <Stat label="Amount awaiting approval" value={fmtMoney(s.awaiting_amount)} />
            <Stat label="Oldest waiting" value={s.oldest_awaiting_hours === null ? '—' : s.oldest_awaiting_hours < 48 ? `${s.oldest_awaiting_hours}h` : `${Math.round(s.oldest_awaiting_hours / 24)}d`} tone={num(s.oldest_awaiting_hours) > (lookups.settings?.approval_reminder_hours ?? 48) ? 'red' : 'gray'} />
            <Stat label="Approved, ready to export" value={s.ready_count} tone="blue" onClick={() => go('integrations')} hint={fmtMoney(s.ready_amount)} />
            <Stat label="Exported, awaiting confirmation" value={s.exported_count} onClick={() => go('integrations')} />
            <Stat label="Sync failed" value={s.sync_failed} tone={s.sync_failed ? 'red' : 'gray'} onClick={() => go('invoices?filter=sync_failed')} />
          </div>
        </section>
        <section>
          <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">{lookups.org?.is_demo ? 'Last 30 days · illustrative demo records' : 'Last 30 days · measured from your records'}</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Stat label="Invoices received" value={s.received_30d} />
            <Stat label="Invoices approved" value={`${s.approved_30d} · ${fmtMoney(s.approved_amount_30d)}`} />
            <Stat label="Median receipt → approval" value={s.median_hours_to_approve === null ? '—' : `${s.median_hours_to_approve}h`} />
            <Stat label="AI fields corrected by people" value={correctionRate === null ? '—' : `${correctionRate}%`} hint={`${s.fields_corrected_30d} of ${s.fields_extracted_30d} extracted fields`} />
          </div>
        </section>
      </>}
      <Card title="Needs attention" bodyClassName="p-0">
        {attention.length === 0 ? <div className="p-4"><Empty title="Nothing needs attention">Invoices with exceptions or extraction problems show up here.</Empty></div> : <InvoiceTable rows={attention.slice(0, 15)} />}
      </Card>
    </div>
  );
}
