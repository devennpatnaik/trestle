import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { client } from '../client';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg, lookupLabel } from '../org';
import { downloadText, errorText, fmtMoney, must, num, round2, toCsv } from '../lib/api';
import { Badge, Button, Card, Empty, ErrorNote, Field, Input, Modal, Notice, PageHeader, Select, Table, Tabs, Td, Th } from '../components/ui';
import { CsvImport, parseMoney, req, type Mapped } from '../components/csv-import';
import { EntityManager } from '../components/entity';
import type { Commitment } from '../types';

type Tab = 'projects' | 'cost_codes' | 'cost_types' | 'gl' | 'commitments' | 'change_orders';

export default function Projects() {
  const [tab, setTab] = useState<Tab>('projects');
  return (
    <div>
      <PageHeader title="Projects & cost codes" subtitle="Jobs, cost codes, cost types, GL accounts and commitments. Import them from your ERP as CSV; codes must match it for exports to post." />
      <Tabs value={tab} onChange={setTab} tabs={[
        { id: 'projects', label: 'Jobs' }, { id: 'cost_codes', label: 'Cost codes' }, { id: 'cost_types', label: 'Cost types' },
        { id: 'gl', label: 'GL accounts' }, { id: 'commitments', label: 'Commitments' }, { id: 'change_orders', label: 'Change orders' },
      ]} />
      {tab === 'projects' && <ProjectsTab />}
      {tab === 'cost_codes' && <CostCodesTab />}
      {tab === 'cost_types' && <CostTypesTab />}
      {tab === 'gl' && <GlTab />}
      {tab === 'commitments' && <CommitmentsTab />}
      {tab === 'change_orders' && <ChangeOrdersTab />}
    </div>
  );
}

function ProjectsTab() {
  const { lookups, orgId, can } = useOrg();
  const pmOptions = lookups.members.filter(m => m.active && m.role !== 'viewer').map(m => ({ value: m.user_id, label: `${m.display_name || m.email} (${m.role})` }));
  type Row = { code: string; name: string; status: string; legal_entity: string | null; address: string | null; external_id: string | null; project_manager_user_id: string | null };
  const mapRow = (r: Record<string, string>): Mapped<Row> => {
    const code = req(r, 'code') ?? req(r, 'job_number') ?? req(r, 'job');
    const name = req(r, 'name') ?? req(r, 'job_name');
    if (!code || !name) return { ok: false, error: 'code and name are required' };
    const status = (req(r, 'status') ?? 'active').toLowerCase();
    if (!['active', 'closed'].includes(status)) return { ok: false, error: 'status must be active or closed' };
    const pmEmail = req(r, 'pm_email')?.toLowerCase();
    const pm = pmEmail ? lookups.members.find(m => m.email.toLowerCase() === pmEmail) : undefined;
    if (pmEmail && !pm) return { ok: false, error: `pm_email ${pmEmail} is not a member of this company; invite them first` };
    return { ok: true, value: { code, name, status, legal_entity: req(r, 'legal_entity'), address: req(r, 'address'), external_id: req(r, 'external_id'), project_manager_user_id: pm?.user_id ?? null } };
  };
  return (
    <EntityManager title="Jobs" table="projects" orgId={orgId} rows={lookups.projects} canEdit={can('ap')} searchKeys={['code', 'name', 'address']} defaults={{ status: 'active' }}
      emptyHint="Import your job list, or add jobs one by one. Assign a project manager so invoices route to them for approval."
      toolbar={<>
        <Button disabled={!lookups.projects.length} onClick={() => downloadText('jobs.csv', toCsv(lookups.projects.map(p => ({ code: p.code, name: p.name, status: p.status, pm_email: lookups.members.find(m => m.user_id === p.project_manager_user_id)?.email ?? '', legal_entity: p.legal_entity, address: p.address, external_id: p.external_id }))))}>Export CSV</Button>
        <CsvImport title="Import jobs" disabled={!can('ap')} mapRow={mapRow}
          columns={[{ name: 'code', required: true, example: '24-101' }, { name: 'name', required: true, example: 'Riverside Medical Office' }, { name: 'status', example: 'active' }, { name: 'pm_email', hint: 'Must be a member already' }, { name: 'legal_entity' }, { name: 'address' }, { name: 'external_id' }]}
          onImport={async rows => {
            await must(client.from('projects').upsert(rows.map(r => ({ ...r, org_id: orgId })), { onConflict: 'org_id,code' }).select('id'));
            return `Imported ${rows.length} jobs.`;
          }} />
      </>}
      fields={[
        { key: 'code', label: 'Job number', required: true },
        { key: 'name', label: 'Name', required: true },
        { key: 'status', label: 'Status', kind: 'select', required: true, options: [{ value: 'active', label: 'Active' }, { value: 'closed', label: 'Closed' }], render: r => <Badge tone={r.status === 'active' ? 'green' : 'gray'}>{String(r.status)}</Badge> },
        { key: 'project_manager_user_id', label: 'Project manager', kind: 'select', options: pmOptions, hint: 'Approves invoices coded to this job.' },
        { key: 'legal_entity', label: 'Legal entity', inList: false },
        { key: 'address', label: 'Site address', inList: false, wide: true },
        { key: 'external_id', label: 'External ID', inList: false },
      ]} />
  );
}

function CostCodesTab() {
  const { lookups, orgId, can } = useOrg();
  const projOptions = lookups.projects.map(p => ({ value: p.id, label: `${p.code} · ${p.name}` }));
  type Row = { code: string; name: string; project_id: string | null; budget_amount: number | null };
  const mapRow = (r: Record<string, string>): Mapped<Row> => {
    const code = req(r, 'code') ?? req(r, 'cost_code');
    const name = req(r, 'name') ?? req(r, 'description');
    if (!code || !name) return { ok: false, error: 'code and name are required' };
    const pc = req(r, 'project_code') ?? req(r, 'job');
    const project = pc ? lookups.projects.find(p => p.code === pc) : undefined;
    if (pc && !project) return { ok: false, error: `job ${pc} not found; import jobs first` };
    const budget = parseMoney(r.budget_amount ?? r.budget);
    if (budget === 'invalid') return { ok: false, error: 'budget is not a number' };
    return { ok: true, value: { code, name, project_id: project?.id ?? null, budget_amount: budget } };
  };
  return (
    <EntityManager title="Cost codes" table="cost_codes" orgId={orgId} rows={lookups.cost_codes} canEdit={can('ap')} searchKeys={['code', 'name']}
      emptyHint="Import your cost code list (CSI divisions or your own). Leave job blank for company-wide codes."
      toolbar={<>
        <Button disabled={!lookups.cost_codes.length} onClick={() => downloadText('cost-codes.csv', toCsv(lookups.cost_codes.map(c => ({ code: c.code, name: c.name, project_code: lookups.projects.find(p => p.id === c.project_id)?.code ?? '', budget_amount: c.budget_amount }))))}>Export CSV</Button>
        <CsvImport title="Import cost codes" disabled={!can('ap')} mapRow={mapRow}
          columns={[{ name: 'code', required: true, example: '03-300' }, { name: 'name', required: true, example: 'Cast-in-place concrete' }, { name: 'project_code', hint: 'Blank = all jobs', example: '' }, { name: 'budget_amount' }]}
          onImport={async rows => {
            for (let i = 0; i < rows.length; i += 300) await must(client.from('cost_codes').upsert(rows.slice(i, i + 300).map(r => ({ ...r, org_id: orgId })), { onConflict: 'org_id,project_id,code' }).select('id'));
            return `Imported ${rows.length} cost codes.`;
          }} />
      </>}
      fields={[
        { key: 'code', label: 'Code', required: true },
        { key: 'name', label: 'Name', required: true },
        { key: 'project_id', label: 'Job', kind: 'select', options: projOptions, hint: 'Blank = available on every job.', render: r => r.project_id ? lookupLabel(lookups.projects, r.project_id as string) : <span className="text-slate-400">All jobs</span> },
        { key: 'budget_amount', label: 'Budget', kind: 'money', render: r => fmtMoney(r.budget_amount as string) },
      ]} />
  );
}

function CostTypesTab() {
  const { lookups, orgId, can } = useOrg();
  return (
    <EntityManager title="Cost types" table="cost_types" orgId={orgId} rows={lookups.cost_types} canEdit={can('ap')} searchKeys={['code', 'name']}
      fields={[{ key: 'code', label: 'Code', required: true }, { key: 'name', label: 'Name', required: true }]} />
  );
}

function GlTab() {
  const { lookups, orgId, can } = useOrg();
  type Row = { code: string; name: string; account_type: string; active: boolean };
  const types = ['expense', 'cost_of_goods', 'asset', 'liability', 'other'];
  const mapRow = (r: Record<string, string>): Mapped<Row> => {
    const code = req(r, 'code') ?? req(r, 'account');
    const name = req(r, 'name') ?? req(r, 'description');
    if (!code || !name) return { ok: false, error: 'code and name are required' };
    const t = (req(r, 'account_type') ?? 'expense').toLowerCase().replace(/\s+/g, '_');
    if (!types.includes(t)) return { ok: false, error: `account_type must be one of ${types.join(', ')}` };
    return { ok: true, value: { code, name, account_type: t, active: (req(r, 'active') ?? 'true').toLowerCase() !== 'false' } };
  };
  return (
    <EntityManager title="GL accounts" table="gl_accounts" orgId={orgId} rows={lookups.gl_accounts} canEdit={can('ap')} searchKeys={['code', 'name']} defaults={{ account_type: 'cost_of_goods', active: true }}
      toolbar={<CsvImport title="Import GL accounts" disabled={!can('ap')} mapRow={mapRow}
        columns={[{ name: 'code', required: true, example: '5100' }, { name: 'name', required: true, example: 'Job cost - materials' }, { name: 'account_type', example: 'cost_of_goods' }, { name: 'active', example: 'true' }]}
        onImport={async rows => { await must(client.from('gl_accounts').upsert(rows.map(r => ({ ...r, org_id: orgId })), { onConflict: 'org_id,code' }).select('id')); return `Imported ${rows.length} GL accounts.`; }} />}
      fields={[
        { key: 'code', label: 'Account', required: true }, { key: 'name', label: 'Name', required: true },
        { key: 'account_type', label: 'Type', kind: 'select', required: true, options: types.map(t => ({ value: t, label: t.replace(/_/g, ' ') })) },
        { key: 'active', label: 'Active', kind: 'bool' },
      ]} />
  );
}

// ------------------------------------------------------------------ commitments
type CommitmentRow = Commitment & { approved_cos: string; pending_cos: string; billed: string; lines: { id: string; line_no: number; description: string | null; cost_code_id: string | null; cost_type_id: string | null; amount: string }[] };

function CommitmentsTab() {
  const { orgId, lookups, can } = useOrg();
  const { rows, loading } = useRows<CommitmentRow>(queries.commitments, [orgId]);
  const [editing, setEditing] = useState<CommitmentRow | 'new' | null>(null);
  const [q, setQ] = useState('');
  const shown = rows.filter(r => !q || `${r.number} ${r.description ?? ''} ${lookups.vendors.find(v => v.id === r.vendor_id)?.name ?? ''}`.toLowerCase().includes(q.toLowerCase()));

  type Imp = { number: string; kind: string; vendor_id: string; project_id: string; description: string | null; original_amount: number; retainage_pct: number; status: string; external_id: string | null; line?: { line_no: number; description: string | null; cost_code_id: string | null; cost_type_id: string | null; amount: number } };
  const mapRow = (r: Record<string, string>): Mapped<Imp> => {
    const number = req(r, 'number') ?? req(r, 'po_number') ?? req(r, 'commitment_number');
    if (!number) return { ok: false, error: 'number is required' };
    const kindRaw = (req(r, 'kind') ?? req(r, 'type') ?? 'purchase_order').toLowerCase();
    const kind = kindRaw.startsWith('sub') ? 'subcontract' : kindRaw.startsWith('p') ? 'purchase_order' : '';
    if (!kind) return { ok: false, error: 'kind must be purchase_order or subcontract' };
    const vendor = lookups.vendors.find(v => v.code === req(r, 'vendor_code'));
    if (!vendor) return { ok: false, error: `vendor_code ${req(r, 'vendor_code') ?? '(empty)'} not found` };
    const project = lookups.projects.find(p => p.code === (req(r, 'project_code') ?? req(r, 'job')));
    if (!project) return { ok: false, error: `project_code ${req(r, 'project_code') ?? '(empty)'} not found` };
    const amount = parseMoney(r.original_amount ?? r.amount);
    if (amount === 'invalid' || amount === null) return { ok: false, error: 'original_amount is required and must be a number' };
    const ret = parseMoney(r.retainage_pct);
    if (ret === 'invalid' || (ret !== null && (ret < 0 || ret > 100))) return { ok: false, error: 'retainage_pct must be 0–100' };
    const value: Imp = { number, kind, vendor_id: vendor.id, project_id: project.id, description: req(r, 'description'), original_amount: amount, retainage_pct: ret ?? 0, status: (req(r, 'status') ?? 'open').toLowerCase() === 'closed' ? 'closed' : 'open', external_id: req(r, 'external_id') };
    const lineNo = req(r, 'line_no');
    if (lineNo) {
      const la = parseMoney(r.line_amount);
      if (la === 'invalid' || la === null) return { ok: false, error: 'line_amount required when line_no is set' };
      const cc = req(r, 'cost_code');
      const code = cc ? (lookups.cost_codes.find(c => c.code === cc && c.project_id === project.id) ?? lookups.cost_codes.find(c => c.code === cc && !c.project_id)) : undefined;
      if (cc && !code) return { ok: false, error: `cost_code ${cc} not found` };
      const ct = req(r, 'cost_type');
      const type = ct ? lookups.cost_types.find(t => t.code === ct) : undefined;
      if (ct && !type) return { ok: false, error: `cost_type ${ct} not found` };
      value.line = { line_no: Number(lineNo), description: req(r, 'line_description'), cost_code_id: code?.id ?? null, cost_type_id: type?.id ?? null, amount: la };
    }
    return { ok: true, value };
  };

  return (
    <Card bodyClassName="p-0" title={`Commitments (${rows.length})`} actions={<>
      <CsvImport title="Import commitments" disabled={!can('admin')} mapRow={mapRow}
        note="One row per commitment line. Repeat the commitment columns on every line. Rows without line_no create the commitment header only."
        columns={[{ name: 'number', required: true, example: 'PO-24101-007' }, { name: 'kind', example: 'purchase_order' }, { name: 'vendor_code', required: true, example: 'V-1001' }, { name: 'project_code', required: true, example: '24-101' },
          { name: 'description' }, { name: 'original_amount', required: true, example: '48000' }, { name: 'retainage_pct', example: '0' }, { name: 'status', example: 'open' }, { name: 'external_id' },
          { name: 'line_no', example: '1' }, { name: 'line_description' }, { name: 'cost_code', example: '03-300' }, { name: 'cost_type', example: 'M' }, { name: 'line_amount', example: '48000' }]}
        onImport={async items => {
          const headers = new Map<string, Imp>();
          for (const it of items) headers.set(it.number, it);
          const saved = await must(client.from('commitments').upsert([...headers.values()].map(({ line: _l, ...h }) => ({ ...h, org_id: orgId })), { onConflict: 'org_id,number' }).select('id, number')) as { id: string; number: string }[];
          const ids = new Map(saved.map(s => [s.number, s.id]));
          const lines = items.filter(i => i.line).map(i => ({ ...i.line!, org_id: orgId, commitment_id: ids.get(i.number)! }));
          if (lines.length) await must(client.from('commitment_lines').upsert(lines, { onConflict: 'commitment_id,line_no' }).select('id'));
          return `Imported ${headers.size} commitments and ${lines.length} lines.`;
        }} />
      {can('admin') && <Button variant="primary" onClick={() => setEditing('new')}><Plus className="size-4" />Add</Button>}
    </>}>
      {!can('admin') && <p className="px-4 pt-3 text-xs text-slate-500">Commitment values drive the overbilling control, so only controllers and owners can change them.</p>}
      <div className="border-b border-slate-100 p-3"><Input aria-label="Search commitments" placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} className="max-w-xs" /></div>
      {!loading && rows.length === 0 ? <div className="p-4"><Empty title="No commitments yet">Import purchase orders and subcontracts so invoices can be matched and checked for overbilling.</Empty></div> : (
        <Table>
          <thead><tr><Th>Number</Th><Th>Vendor</Th><Th>Job</Th><Th className="text-right">Original</Th><Th className="text-right">Approved COs</Th><Th className="text-right">Revised</Th><Th className="text-right">Billed</Th><Th className="text-right">Remaining</Th><Th /></tr></thead>
          <tbody>{shown.map(c => {
            const revised = num(c.original_amount) + num(c.approved_cos);
            const remaining = round2(revised - num(c.billed));
            return (
              <tr key={c.id} className="hover:bg-slate-50">
                <Td><span className="font-medium">{c.number}</span> <Badge>{c.kind === 'subcontract' ? 'Sub' : 'PO'}</Badge>{c.status === 'closed' && <Badge className="ml-1">closed</Badge>}<div className="text-xs text-slate-500">{c.description}</div></Td>
                <Td>{lookups.vendors.find(v => v.id === c.vendor_id)?.name}</Td>
                <Td>{lookups.projects.find(p => p.id === c.project_id)?.code}</Td>
                <Td className="text-right tabular-nums">{fmtMoney(c.original_amount)}</Td>
                <Td className="text-right tabular-nums">{fmtMoney(c.approved_cos)}{num(c.pending_cos) !== 0 && <div className="text-xs text-amber-700">+{fmtMoney(c.pending_cos)} pending</div>}</Td>
                <Td className="text-right tabular-nums">{fmtMoney(revised)}</Td>
                <Td className="text-right tabular-nums">{fmtMoney(c.billed)}</Td>
                <Td className={`text-right tabular-nums ${remaining < 0 ? 'text-red-700' : ''}`}>{fmtMoney(remaining)}</Td>
                <Td>{can('admin') && <Button size="sm" variant="ghost" onClick={() => setEditing(c)}>Edit</Button>}</Td>
              </tr>
            );
          })}</tbody>
        </Table>
      )}
      <CommitmentForm open={editing !== null} commitment={editing === 'new' ? null : editing} onClose={() => setEditing(null)} />
    </Card>
  );
}

type LineDraft = { key: string; id?: string; line_no: string; description: string; cost_code_id: string; cost_type_id: string; amount: string };

function CommitmentForm({ open, commitment, onClose }: { open: boolean; commitment: CommitmentRow | null; onClose: () => void }) {
  const { lookups, orgId } = useOrg();
  const [f, setF] = useState({ number: '', kind: 'purchase_order', vendor_id: '', project_id: '', description: '', original_amount: '', retainage_pct: '0', status: 'open', external_id: '' });
  const [lines, setLines] = useState<LineDraft[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!open) return;
    setError('');
    const c = commitment;
    setF({ number: c?.number ?? '', kind: c?.kind ?? 'purchase_order', vendor_id: c?.vendor_id ?? '', project_id: c?.project_id ?? '', description: c?.description ?? '',
      original_amount: c?.original_amount ?? '', retainage_pct: c?.retainage_pct ?? '0', status: c?.status ?? 'open', external_id: c?.external_id ?? '' });
    setLines((c?.lines ?? []).map(l => ({ key: l.id, id: l.id, line_no: String(l.line_no), description: l.description ?? '', cost_code_id: l.cost_code_id ?? '', cost_type_id: l.cost_type_id ?? '', amount: l.amount })));
  }, [open, commitment]);
  const lineSum = round2(lines.reduce((s, l) => s + num(l.amount), 0));
  const save = async () => {
    setBusy(true); setError('');
    try {
      if (!f.number.trim() || !f.vendor_id || !f.project_id) throw new Error('Number, vendor and job are required');
      const amt = Number(f.original_amount);
      if (!Number.isFinite(amt)) throw new Error('Original amount must be a number');
      const values = { ...f, number: f.number.trim(), original_amount: amt, retainage_pct: Number(f.retainage_pct || 0), description: f.description || null, external_id: f.external_id || null };
      let id = commitment?.id;
      if (id) await must(client.from('commitments').update(values).eq('id', id).select('id'));
      else id = ((await must(client.from('commitments').insert({ ...values, org_id: orgId }).select('id'))) as { id: string }[])[0].id;
      const removed = (commitment?.lines ?? []).filter(l => !lines.some(d => d.id === l.id));
      for (const l of removed) await must(client.from('commitment_lines').delete().eq('id', l.id).select('id'));
      for (const l of lines) {
        const v = { line_no: Number(l.line_no), description: l.description || null, cost_code_id: l.cost_code_id || null, cost_type_id: l.cost_type_id || null, amount: Number(l.amount || 0) };
        if (l.id) await must(client.from('commitment_lines').update(v).eq('id', l.id).select('id'));
        else await must(client.from('commitment_lines').insert({ ...v, org_id: orgId, commitment_id: id }).select('id'));
      }
      onClose();
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} wide title={commitment ? `Edit ${commitment.number}` : 'Add commitment'} onClose={onClose} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" busy={busy} onClick={save}>Save</Button></>}>
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Number *"><Input aria-label="Commitment number" value={f.number} onChange={e => setF({ ...f, number: e.target.value })} /></Field>
        <Field label="Kind"><Select aria-label="Kind" value={f.kind} onChange={e => setF({ ...f, kind: e.target.value })}><option value="purchase_order">Purchase order</option><option value="subcontract">Subcontract</option></Select></Field>
        <Field label="Status"><Select aria-label="Status" value={f.status} onChange={e => setF({ ...f, status: e.target.value })}><option value="open">Open</option><option value="closed">Closed</option></Select></Field>
        <Field label="Vendor *"><Select aria-label="Commitment vendor" value={f.vendor_id} onChange={e => setF({ ...f, vendor_id: e.target.value })}><option value="">Choose…</option>{lookups.vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</Select></Field>
        <Field label="Job *"><Select aria-label="Commitment job" value={f.project_id} onChange={e => setF({ ...f, project_id: e.target.value })}><option value="">Choose…</option>{lookups.projects.map(p => <option key={p.id} value={p.id}>{p.code} · {p.name}</option>)}</Select></Field>
        <Field label="Original amount *"><Input aria-label="Original amount" inputMode="decimal" value={f.original_amount} onChange={e => setF({ ...f, original_amount: e.target.value })} /></Field>
        <Field label="Retainage %"><Input aria-label="Retainage percent" inputMode="decimal" value={f.retainage_pct} onChange={e => setF({ ...f, retainage_pct: e.target.value })} /></Field>
        <Field label="Description" className="sm:col-span-2"><Input aria-label="Commitment description" value={f.description} onChange={e => setF({ ...f, description: e.target.value })} /></Field>
      </div>
      <div className="flex items-center justify-between"><p className="text-sm font-medium">Lines</p><Button size="sm" onClick={() => setLines(ls => [...ls, { key: crypto.randomUUID(), line_no: String(ls.length + 1), description: '', cost_code_id: '', cost_type_id: '', amount: '' }])}><Plus className="size-3.5" />Add line</Button></div>
      {lines.map(l => (
        <div key={l.key} className="grid grid-cols-12 gap-2">
          <Input aria-label="Line number" className="col-span-1" value={l.line_no} onChange={e => setLines(ls => ls.map(x => x.key === l.key ? { ...x, line_no: e.target.value } : x))} />
          <Input aria-label="Line description" placeholder="Description" className="col-span-3" value={l.description} onChange={e => setLines(ls => ls.map(x => x.key === l.key ? { ...x, description: e.target.value } : x))} />
          <Select aria-label="Line cost code" className="col-span-3" value={l.cost_code_id} onChange={e => setLines(ls => ls.map(x => x.key === l.key ? { ...x, cost_code_id: e.target.value } : x))}><option value="">Cost code…</option>{lookups.cost_codes.filter(c => !c.project_id || c.project_id === f.project_id).map(c => <option key={c.id} value={c.id}>{c.code} · {c.name}</option>)}</Select>
          <Select aria-label="Line cost type" className="col-span-2" value={l.cost_type_id} onChange={e => setLines(ls => ls.map(x => x.key === l.key ? { ...x, cost_type_id: e.target.value } : x))}><option value="">Type…</option>{lookups.cost_types.map(t => <option key={t.id} value={t.id}>{t.code}</option>)}</Select>
          <Input aria-label="Line amount" className="col-span-2 text-right" inputMode="decimal" value={l.amount} onChange={e => setLines(ls => ls.map(x => x.key === l.key ? { ...x, amount: e.target.value } : x))} />
          <button type="button" aria-label="Remove line" className="col-span-1 text-slate-400 hover:text-red-600" onClick={() => setLines(ls => ls.filter(x => x.key !== l.key))}><Trash2 className="size-4" /></button>
        </div>
      ))}
      {lines.length > 0 && Math.abs(lineSum - num(f.original_amount)) >= 0.005 && <Notice tone="amber">Lines add up to {fmtMoney(lineSum)}, not the original amount {fmtMoney(f.original_amount)}.</Notice>}
      <ErrorNote>{error}</ErrorNote>
    </Modal>
  );
}

function ChangeOrdersTab() {
  const { orgId, lookups, can } = useOrg();
  const { rows } = useRows<{ id: string; commitment_id: string; number: string; description: string | null; amount: string; status: string; approved_date: string | null }>(
    queries.changeOrders, [orgId]);
  const [adding, setAdding] = useState(false);
  const [f, setF] = useState({ commitment_id: '', number: '', description: '', amount: '', status: 'pending' });
  const [error, setError] = useState('');
  const setStatus = async (id: string, status: string) => {
    setError('');
    try { await must(client.from('change_orders').update({ status, approved_date: status === 'approved' ? new Date().toISOString().slice(0, 10) : null }).eq('id', id).select('id')); } catch (e) { setError(errorText(e)); }
  };
  type Imp = { commitment_id: string; number: string; description: string | null; amount: number; status: string; approved_date: string | null };
  const mapRow = (r: Record<string, string>): Mapped<Imp> => {
    const c = lookups.commitments.find(x => x.number === req(r, 'commitment_number'));
    if (!c) return { ok: false, error: `commitment_number ${req(r, 'commitment_number') ?? ''} not found` };
    const number = req(r, 'number') ?? req(r, 'co_number');
    if (!number) return { ok: false, error: 'number is required' };
    const amount = parseMoney(r.amount);
    if (amount === null || amount === 'invalid') return { ok: false, error: 'amount must be a number' };
    const status = (req(r, 'status') ?? 'pending').toLowerCase();
    if (!['pending', 'approved', 'rejected'].includes(status)) return { ok: false, error: 'status must be pending, approved or rejected' };
    return { ok: true, value: { commitment_id: c.id, number, description: req(r, 'description'), amount, status, approved_date: req(r, 'approved_date') } };
  };
  return (
    <Card bodyClassName="p-0" title={`Change orders (${rows.length})`} actions={<>
      <CsvImport title="Import change orders" disabled={!can('admin')} mapRow={mapRow}
        columns={[{ name: 'commitment_number', required: true, example: 'SC-24101-002' }, { name: 'number', required: true, example: 'CO-01' }, { name: 'description' }, { name: 'amount', required: true, example: '6500' }, { name: 'status', example: 'approved' }, { name: 'approved_date', example: '2026-09-15' }]}
        onImport={async items => { await must(client.from('change_orders').upsert(items.map(i => ({ ...i, org_id: orgId })), { onConflict: 'commitment_id,number' }).select('id')); return `Imported ${items.length} change orders.`; }} />
      {can('admin') && <Button variant="primary" onClick={() => { setAdding(true); setF({ commitment_id: '', number: '', description: '', amount: '', status: 'pending' }); }}><Plus className="size-4" />Add</Button>}
    </>}>
      <p className="px-4 pt-3 text-xs text-slate-500">Only approved change orders increase the revised commitment used by the overbilling check. Pending ones are shown as warnings on invoices.</p>
      <ErrorNote>{error}</ErrorNote>
      <Table className="mt-2">
        <thead><tr><Th>Commitment</Th><Th>CO</Th><Th>Description</Th><Th className="text-right">Amount</Th><Th>Status</Th><Th /></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><Td colSpan={6} className="text-slate-500">No change orders.</Td></tr>}
          {rows.map(o => (
            <tr key={o.id}>
              <Td>{lookups.commitments.find(c => c.id === o.commitment_id)?.number}</Td><Td>{o.number}</Td><Td>{o.description}</Td>
              <Td className="text-right tabular-nums">{fmtMoney(o.amount)}</Td>
              <Td><Badge tone={o.status === 'approved' ? 'green' : o.status === 'rejected' ? 'red' : 'amber'}>{o.status}</Badge></Td>
              <Td className="whitespace-nowrap text-right">{can('admin') && o.status === 'pending' && <><Button size="sm" onClick={() => setStatus(o.id, 'approved')}>Mark approved</Button> <Button size="sm" variant="ghost" onClick={() => setStatus(o.id, 'rejected')}>Rejected</Button></>}</Td>
            </tr>
          ))}
        </tbody>
      </Table>
      <Modal open={adding} title="Add change order" onClose={() => setAdding(false)} footer={<><Button onClick={() => setAdding(false)}>Cancel</Button><Button variant="primary" disabled={!f.commitment_id || !f.number || !f.amount} onClick={async () => {
        setError('');
        try { await must(client.from('change_orders').insert({ ...f, amount: Number(f.amount), org_id: orgId, description: f.description || null, approved_date: f.status === 'approved' ? new Date().toISOString().slice(0, 10) : null }).select('id')); setAdding(false); } catch (e) { setError(errorText(e)); }
      }}>Save</Button></>}>
        <Field label="Commitment"><Select aria-label="CO commitment" value={f.commitment_id} onChange={e => setF({ ...f, commitment_id: e.target.value })}><option value="">Choose…</option>{lookups.commitments.map(c => <option key={c.id} value={c.id}>{c.number}</option>)}</Select></Field>
        <Field label="CO number"><Input aria-label="CO number" value={f.number} onChange={e => setF({ ...f, number: e.target.value })} /></Field>
        <Field label="Description"><Input aria-label="CO description" value={f.description} onChange={e => setF({ ...f, description: e.target.value })} /></Field>
        <Field label="Amount"><Input aria-label="CO amount" inputMode="decimal" value={f.amount} onChange={e => setF({ ...f, amount: e.target.value })} /></Field>
        <Field label="Status"><Select aria-label="CO status" value={f.status} onChange={e => setF({ ...f, status: e.target.value })}><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></Select></Field>
        <ErrorNote>{error}</ErrorNote>
      </Modal>
    </Card>
  );
}
