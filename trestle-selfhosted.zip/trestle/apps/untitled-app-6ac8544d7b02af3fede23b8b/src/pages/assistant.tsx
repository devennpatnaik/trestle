import { useEffect, useRef, useState } from 'react';
import { Loader2, Send, Sparkles } from 'lucide-react';
import { useAgentChat } from '../use-agent-chat';
import { useLocalChat } from '../use-local-chat';
import { SELFHOST } from '../selfhost';
import { useOrg } from '../org';
import { Button, Card, ErrorNote, PageHeader, Textarea } from '../components/ui';
import { Markdown } from '../components/markdown';

const CONTEXT_RE = /^\[context:[^\]]*\]\s*/;
const SUGGESTIONS = [
  'What is blocking invoices in review right now?',
  'Which commitments are over 90% billed?',
  'Summarize invoices waiting on approval by approver and age.',
  'Why was the most recent duplicate flagged?',
];

export default function Assistant() {
  const { orgId, lookups, role, userId } = useOrg();
  const key = `finops:assistant:${userId}:${orgId}`;
  // SELFHOST is fixed at build time, so the same hook runs on every render.
  const chat = SELFHOST ? useLocalChat() : useAgentChat({ agentName: 'finops-assistant', initialSessionId: localStorage.getItem(key), onSessionIdChange: id => (id ? localStorage.setItem(key, id) : localStorage.removeItem(key)) });
  const [text, setText] = useState('');
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [chat.messages.length, chat.status]);
  const busy = chat.status === 'running' || chat.status === 'loading';
  const send = async (msg: string) => {
    if (!msg.trim() || busy) return;
    setText('');
    await chat.send(`[context: org_id=${orgId}; company=${lookups.org?.name ?? ''}; role=${role}]\n${msg.trim()}`);
  };
  const running = chat.toolCalls.filter(t => t.status === 'running');
  return (
    <div className="flex flex-col gap-3">
      <PageHeader title="AI assistant" subtitle="Ask about invoices, vendors, jobs, commitments and approvals. It reads your records with your permissions and cannot approve, override or export anything."
        actions={<Button onClick={() => chat.newChat()} disabled={busy}>New chat</Button>} />
      <Card bodyClassName="flex min-h-[55vh] flex-col gap-3">
        {chat.messages.length === 0 && (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
            <Sparkles className="size-6 text-violet-600" />
            <p className="text-sm text-slate-600">Answers cite your records. Anything the assistant infers is labeled as its assessment.</p>
            <div className="flex max-w-2xl flex-wrap justify-center gap-2">{SUGGESTIONS.map(s => <Button key={s} size="sm" onClick={() => send(s)}>{s}</Button>)}</div>
          </div>
        )}
        {chat.messages.map(m => (
          <div key={m.id} className={m.role === 'user' ? 'ml-auto max-w-[85%] rounded-lg bg-slate-900 px-3 py-2 text-sm text-white' : 'max-w-full rounded-lg bg-slate-50 px-3 py-2 text-sm text-slate-800'}>
            {m.role === 'user' ? <p className="whitespace-pre-wrap">{m.content.replace(CONTEXT_RE, '')}</p> : <Markdown text={m.content} />}
          </div>
        ))}
        {busy && <p className="flex items-center gap-2 text-xs text-slate-500"><Loader2 className="size-3.5 animate-spin" />{running.length ? toolStatus(running[0].label) : 'Thinking…'}</p>}
        <ErrorNote>{chat.error}</ErrorNote>
        <div ref={end} />
      </Card>
      <form className="flex gap-2" onSubmit={e => { e.preventDefault(); void send(text); }}>
        <Textarea aria-label="Message" rows={2} value={text} placeholder="Ask a question…" onChange={e => setText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(text); } }} />
        <Button type="submit" variant="primary" disabled={busy || !text.trim()} aria-label="Send"><Send className="size-4" /></Button>
      </form>
    </div>
  );
}

// Tool labels are internal identifiers (for example bourne__run_app_sql); show people what is happening instead.
function toolStatus(label: string | undefined): string {
  const l = (label ?? '').toLowerCase();
  if (l.includes('sql') || l.includes('query') || l.includes('read')) return 'Reading your company’s records…';
  return 'Working…';
}
