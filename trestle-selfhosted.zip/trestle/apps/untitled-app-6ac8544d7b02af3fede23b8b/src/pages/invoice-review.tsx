import { DemoDocument } from '../components/demo-document';
import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Bot, Check, Plus, RefreshCw, Trash2, User, X } from 'lucide-react';
import { client } from '../client';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg, lookupLabel } from '../org';
import { errorText, fmtDateTime, fmtMoney, must, num, round2, rpc } from '../lib/api';
import { Badge, Button, Card, ErrorNote, Field, Input, Loading, Modal, Notice, ReasonDialog, Select, Table, Td, Textarea, Th } from '../components/ui';
import { ConfidencePill, DocumentViewer, ExtractionBadge, InvoiceStatusBadge, SeverityBadge, SyncBadge } from './shared';
import type { Allocation, ApprovalStep, AuditEvent, Invoice, InvoiceException } from '../types';

type CommitmentSummary = {
  id: string; number: string; kind: string; status: string; original: string; retainage_pct: string; approved_cos: string; pending_cos: string; billed_other: string;
  description: string | null; vendor_id: string; project_id: string;
  lines: { id: string; line_no: number; description: string | null; cost_code_id: string | null; cost_type_id: string | null; amount: string }[];
};
type SyncRow = { id: string; attempt: number; status: string; external_id: string | null; error: string | null; batch_number: number; idempotency_key: string; created_at: string; updated_at: string };
type Line = { id: string; line_no: number; description: string | null; quantity: string | null; unit_price: string | null; amount: string | null };
type Detail = {
  invoice: Invoice; allocations: Allocation[]; lines: Line[]; exceptions: InvoiceException[]; steps: ApprovalStep[];
  audit: AuditEvent[]; sync: SyncRow[]; commitment: CommitmentSummary | null;
};

const DETAIL_SQL = queries.invoiceDetail;

const FIELDS: { key: keyof Invoice; label: string; type?: 'date' | 'money' | 'text' }[] = [
  { key: 'invoice_number', label: 'Invoice number' },
  { key: 'invoice_date', label: 'Invoice date', type: 'date' },
  { key: 'due_date', label: 'Due date', type: 'date' },
  { key: 'payment_terms', label: 'Payment terms' },
  { key: 'po_number', label: 'PO / subcontract no.' },
  { key: 'project_reference', label: 'Job reference on document' },
  { key: 'subtotal', label: 'Subtotal', type: 'money' },
  { key: 'tax_amount', label: 'Tax', type: 'money' },
  { key: 'retainage_amount', label: 'Retainage withheld', type: 'money' },
  { key: 'total_amount', label: 'Invoice total (before retainage)', type: 'money' },
  { key: 'currency', label: 'Currency' },
  { key: 'description', label: 'Description' },
];

export default function InvoiceReview({ id }: { id: string }) {
  const { orgId } = useOrg();
  const { rows, loading, error } = useRows<Detail>(DETAIL_SQL, [id, orgId]);
  const d = rows[0];
  if (loading) return <Loading />;
  if (!d) return (
    <div className="flex flex-col gap-3">
      <BackLink />
      <Notice tone="amber">{error ? `Could not load this invoice: ${error}` : 'This invoice does not exist in this company, or your role cannot see it.'}</Notice>
    </div>
  );
  return <Review key={id} d={d} liveError={error} />;
}

function BackLink() {
  return <a href="#/invoices" className="inline-flex items-center gap-1 text-sm text-slate-600 hover:text-slate-900"><ArrowLeft className="size-4" />Invoices</a>;
}

function Review({ d, liveError }: { d: Detail; liveError: string | null }) {
  const { lookups, can, memberName, userId, role } = useOrg();
  const inv = d.invoice;
  const settings = lookups.settings;
  const threshold = num(settings?.low_confidence_threshold ?? 0.8);
  const extracting = inv.extraction_status === 'pending' || inv.extraction_status === 'running';
  const editable = can('ap') && inv.status === 'needs_review' && !extracting;
  const vendor = lookups.vendors.find(v => v.id === inv.vendor_id);
  const openEx = d.exceptions.filter(x => x.status === 'open');
  const blocking = openEx.filter(x => x.severity === 'blocking');
  const needsConfirmation = openEx.filter(x => ['low_confidence', 'possible_duplicate', 'totals_mismatch', 'duplicate'].includes(x.code));
  const demoSource = lookups.org?.is_demo && inv.ai_extraction?.demo_document;
  const currentSteps = d.steps.filter(s => s.round === inv.approval_round);
  const [actionError, setActionError] = useState('');
  const [busy, setBusy] = useState('');
  const [dialog, setDialog] = useState<'' | 'reject' | 'void' | 'reopen'>('');

  const run = async (label: string, fn: () => Promise<unknown>) => {
    setBusy(label); setActionError('');
    try { await fn(); } catch (e) { setActionError(errorText(e)); } finally { setBusy(''); }
  };

  const myStep = currentSteps.find(s => s.status === 'pending' && (
    s.approver_user_id === userId || (!s.approver_user_id && (s.approver_role === role || (s.approver_role === 'controller' && role === 'owner')))));
  const minOrder = Math.min(...currentSteps.filter(s => s.status === 'pending').map(s => s.step_order));
  const canDecide = inv.status === 'pending_approval' && myStep && myStep.step_order === minOrder;
  const selfBlocked = canDecide && !settings?.allow_self_approval && inv.submitted_by === userId;
  const stale = inv.extraction_status === 'running' && inv.extraction_started_at && Date.now() - new Date(inv.extraction_started_at).getTime() > 10 * 60_000
    || inv.extraction_status === 'pending' && Date.now() - new Date(inv.updated_at).getTime() > 10 * 60_000;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-col gap-1">
          <BackLink />
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl font-semibold text-slate-900">{inv.invoice_number ? `Invoice ${inv.invoice_number}` : 'Invoice (no number yet)'}</h1>
            <InvoiceStatusBadge status={inv.status} />
            <ExtractionBadge status={inv.extraction_status} />
            {inv.status === 'approved' && <SyncBadge status={inv.sync_status} />}
          </div>
          <p className="text-sm text-slate-500">{vendor?.name ?? inv.vendor_name_extracted ?? 'Vendor not identified'} · {fmtMoney(inv.total_amount, inv.currency)} · received {fmtDateTime(inv.created_at)}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {inv.status === 'needs_review' && can('ap') && <>
            {extracting && <Button onClick={() => run('manual', () => rpc('start_manual_entry', { p_invoice: inv.id }))} busy={busy === 'manual'}>Enter manually instead</Button>}
            {(inv.extraction_status === 'failed' || stale) && inv.upload_id && <Button onClick={() => run('retry', () => rpc('retry_extraction', { p_invoice: inv.id }))} busy={busy === 'retry'}><RefreshCw className="size-4" />Retry AI extraction</Button>}
            {inv.extraction_status === 'failed' && <Button onClick={() => run('manual', () => rpc('start_manual_entry', { p_invoice: inv.id }))} busy={busy === 'manual'}>Enter manually</Button>}
            {!extracting && <Button onClick={() => run('checks', () => rpc('run_invoice_checks', { p_invoice: inv.id }))} busy={busy === 'checks'}>Re-run checks</Button>}
            <Button variant="ghost" onClick={() => setDialog('void')}>Void</Button>
            {!extracting && <Button variant="primary" busy={busy === 'submit'} disabled={blocking.length > 0 || needsConfirmation.length > 0} onClick={() => run('submit', () => rpc('submit_invoice', { p_invoice: inv.id }))}
              title={blocking.length ? 'Resolve blocking exceptions first' : undefined}>Submit for approval</Button>}
          </>}
          {canDecide && <>
            <Button variant="danger" onClick={() => setDialog('reject')}><X className="size-4" />Reject</Button>
            <Button variant="success" busy={busy === 'approve'} disabled={!!selfBlocked} title={selfBlocked ? 'You submitted this invoice; another person must approve it' : undefined}
              onClick={() => run('approve', () => rpc('decide_invoice', { p_invoice: inv.id, p_decision: 'approve', p_comment: null }))}><Check className="size-4" />Approve</Button>
          </>}
          {((inv.status === 'pending_approval' || inv.status === 'rejected') && can('ap')) || (inv.status === 'approved' && can('admin') && ['ready', 'failed'].includes(inv.sync_status))
            ? <Button onClick={() => setDialog('reopen')}>{inv.status === 'pending_approval' ? 'Pull back to review' : 'Reopen for correction'}</Button> : null}
        </div>
      </div>
      <ErrorNote>{actionError}</ErrorNote>
      {editable && <Notice tone={blocking.length || needsConfirmation.length ? 'amber' : 'green'}>
        <strong>Next step: </strong>{blocking.length ? `Resolve ${blocking.length} blocking issue(s) below before submitting.` : needsConfirmation.length ? 'Confirm or correct the flagged fields against the source before submitting.' : 'Compare the source and job coding, then submit for approval. No payment is made here.'}
      </Notice>}
      {inv.status === 'approved' && <Notice tone={inv.sync_status === 'failed' ? 'amber' : 'green'}>
        {inv.sync_status === 'ready' ? 'Approved. Prepare a CSV batch in Accounting exports.' : inv.sync_status === 'exported' ? 'CSV prepared. Record the import result after checking your accounting system; this is not yet confirmed posted.' : inv.sync_status === 'failed' ? 'Accounting import failed. Review the error below, correct the mapping, then retry from Accounting exports.' : 'Accounting posting confirmed. This status does not mean the invoice has been paid.'}
        {' '}<a href="#/integrations" className="underline">Accounting exports</a>
      </Notice>}
      {liveError && <Notice tone="amber">Live updates paused: {liveError}</Notice>}
      {inv.extraction_status === 'running' && <Notice>The AI agent is reading this document. Fields fill in automatically when it finishes; nothing is submitted without a person.</Notice>}
      {inv.extraction_status === 'pending' && <Notice>Queued for AI extraction{stale ? ' — this is taking longer than expected; retry or enter it manually.' : '.'}</Notice>}
      {inv.extraction_status === 'failed' && <Notice tone="amber">AI extraction failed: {inv.extraction_error ?? 'unknown error'}. Retry, or enter the fields by hand.</Notice>}
      {inv.status === 'rejected' && <Notice tone="amber">Rejected: {inv.rejected_reason}</Notice>}
      {inv.status === 'void' && <Notice tone="amber">This invoice is void and excluded from approvals, exports and duplicate totals.</Notice>}

      <div className="grid gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
        <div className="lg:sticky lg:top-4 lg:self-start">
          <Card title={demoSource ? "Illustrative source invoice" : "Original document"} bodyClassName="p-3">{demoSource ? <DemoDocument source={demoSource} /> : <DocumentViewer uploadId={inv.upload_id} fileName={inv.file_name} />}</Card>
          {inv.ai_summary && <Card className="mt-4" title={<span className="inline-flex items-center gap-1.5"><Bot className="size-4" />AI summary</span>}><p className="text-sm text-slate-700">{inv.ai_summary}</p><p className="mt-2 text-xs text-slate-500">{demoSource ? 'Seeded training example; no AI run was performed.' : 'Generated by the intake agent from the document. Not a verified record.'}</p></Card>}
        </div>
        <div className="flex min-w-0 flex-col gap-4">
          <ExceptionsPanel exceptions={d.exceptions} invoice={inv} />
          <FieldsPanel inv={inv} editable={editable} threshold={threshold} />
          <MatchPanel inv={inv} commitment={d.commitment} />
          <AllocationsPanel inv={inv} allocations={d.allocations} editable={editable} threshold={threshold} commitment={d.commitment} />
          {d.lines.length > 0 && <LinesPanel lines={d.lines} currency={inv.currency} />}
          <ApprovalsPanel inv={inv} steps={d.steps} />
          {d.sync.length > 0 && <SyncPanel rows={d.sync} />}
          <AuditPanel events={d.audit} memberName={memberName} />
        </div>
      </div>

      <ReasonDialog open={dialog === 'reject'} title="Reject invoice" label="Reason (sent back to AP)" confirmLabel="Reject" variant="danger" onClose={() => setDialog('')}
        onConfirm={async reason => { await rpc('decide_invoice', { p_invoice: inv.id, p_decision: 'reject', p_comment: reason }); }} />
      <ReasonDialog open={dialog === 'void'} title="Void invoice" label="Why is this invoice void?" confirmLabel="Void invoice" variant="danger" onClose={() => setDialog('')}
        onConfirm={async reason => { await rpc('void_invoice', { p_invoice: inv.id, p_reason: reason }); }} />
      <ReasonDialog open={dialog === 'reopen'} title="Reopen invoice" label="What needs to change?" confirmLabel="Reopen" onClose={() => setDialog('')}
        onConfirm={async reason => { await rpc('reopen_invoice', { p_invoice: inv.id, p_reason: reason }); }}>
        <p className="text-sm text-slate-600">The invoice returns to review. Any approvals already given are cleared and it must be approved again after changes.</p>
      </ReasonDialog>
    </div>
  );
}

// ------------------------------------------------------------------ exceptions
function ExceptionsPanel({ exceptions, invoice }: { exceptions: InvoiceException[]; invoice: Invoice }) {
  const { can, memberName } = useOrg();
  const [target, setTarget] = useState<{ ex: InvoiceException; action: 'acknowledge' | 'override' } | null>(null);
  const [showClosed, setShowClosed] = useState(false);
  const open = exceptions.filter(x => x.status === 'open');
  const closed = exceptions.filter(x => x.status !== 'open');
  const actionable = invoice.status === 'needs_review' || invoice.status === 'pending_approval';
  const title = open.length ? `Exceptions (${open.length} open)` : 'Exceptions';
  return (
    <Card title={title} actions={closed.length > 0 && <Button size="sm" variant="ghost" onClick={() => setShowClosed(s => !s)}>{showClosed ? 'Hide' : 'Show'} {closed.length} closed</Button>}>
      {open.length === 0 && <p className="text-sm text-emerald-700">{invoice.extraction_status === 'pending' || invoice.extraction_status === 'running' ? 'Checks run after extraction.' : 'No open exceptions. The controls engine found nothing that needs attention.'}</p>}
      <ul className="flex flex-col gap-2">
        {[...open, ...(showClosed ? closed : [])].map(x => (
          <li key={x.id} className={`rounded-md border p-3 ${x.status === 'open' ? (x.severity === 'blocking' ? 'border-red-200 bg-red-50/40' : 'border-amber-200 bg-amber-50/40') : 'border-slate-200 bg-slate-50'}`}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                {x.status === 'open' ? <SeverityBadge severity={x.severity} /> : <Badge>{x.status}</Badge>}
                <span className="text-sm font-medium text-slate-900">{x.title}</span>
              </div>
              {x.status === 'open' && actionable && (
                <div className="flex gap-1.5">
                  {x.severity !== 'blocking' && can('ap') && <Button size="sm" onClick={() => setTarget({ ex: x, action: 'acknowledge' })}>{x.code === 'low_confidence' ? 'Confirm value' : 'Acknowledge'}</Button>}
                  {x.severity === 'blocking' && x.overridable && can('admin') && <Button size="sm" variant="danger" onClick={() => setTarget({ ex: x, action: 'override' })}>Override</Button>}
                </div>
              )}
            </div>
            <p className="mt-1 text-sm text-slate-700">{x.detail}</p>
            {x.severity === 'blocking' && x.status === 'open' && (
              <p className="mt-1 text-xs text-slate-500">{x.overridable ? 'Fix the data and re-run checks, or a controller/owner can override with a reason.' : 'Cannot be overridden. Correct the data, or void the invoice.'}</p>
            )}
            {x.status !== 'open' && x.resolution_note && <p className="mt-1 text-xs text-slate-500">{x.status === 'resolved' ? '' : `${memberName(x.resolved_by)}: `}{x.resolution_note} {x.resolved_at && `· ${fmtDateTime(x.resolved_at)}`}</p>}
            <Evidence evidence={x.evidence} />
          </li>
        ))}
      </ul>
      <ReasonDialog open={!!target} onClose={() => setTarget(null)}
        title={target?.action === 'override' ? 'Override blocking exception' : 'Acknowledge'}
        label={target?.action === 'override' ? 'Justification (recorded in the audit log)' : 'Note'}
        minLength={target?.action === 'override' ? 10 : 3}
        confirmLabel={target?.action === 'override' ? 'Override' : 'Confirm'} variant={target?.action === 'override' ? 'danger' : 'primary'}
        onConfirm={async note => { await rpc('resolve_exception', { p_exception: target!.ex.id, p_action: target!.action, p_note: note }); }}>
        {target && <p className="text-sm text-slate-600"><strong>{target.ex.title}.</strong> {target.ex.detail}</p>}
      </ReasonDialog>
    </Card>
  );
}

function Evidence({ evidence }: { evidence: Record<string, unknown> }) {
  const entries = Object.entries(evidence ?? {}).filter(([, v]) => v !== null && v !== '' && typeof v !== 'object');
  if (!entries.length) return null;
  return (
    <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-0.5 text-xs sm:grid-cols-3">
      {entries.slice(0, 9).map(([k, v]) => (
        <div key={k} className="min-w-0"><dt className="inline text-slate-500">{k.replace(/_/g, ' ')}: </dt><dd className="inline font-medium text-slate-700">{/amount|total|remaining|billed|limit|commitment|tolerance|variance/.test(k) && !Number.isNaN(Number(v)) ? fmtMoney(v as string) : String(v)}</dd></div>
      ))}
    </dl>
  );
}

// ------------------------------------------------------------------ header fields
function FieldsPanel({ inv, editable, threshold }: { inv: Invoice; editable: boolean; threshold: number }) {
  const { lookups, can, orgId } = useOrg();
  const initial = useMemo(() => ({
    vendor_id: inv.vendor_id ?? '', commitment_id: inv.commitment_id ?? '',
    ...Object.fromEntries(FIELDS.map(f => [f.key, (inv[f.key] as string | null) ?? ''])),
  }) as Record<string, string>, [inv]);
  const [draft, setDraft] = useState(initial);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [newVendor, setNewVendor] = useState(false);
  useEffect(() => setDraft(initial), [initial]);
  const changed = Object.keys(draft).filter(k => (draft[k] ?? '') !== (initial[k] ?? ''));
  const conf = inv.field_confidence ?? {};

  const save = async () => {
    setSaving(true); setError('');
    try {
      const patch: Record<string, unknown> = {};
      for (const k of changed) patch[k] = draft[k].trim() === '' ? null : draft[k].trim();
      if ('commitment_id' in patch && patch.commitment_id) {
        const c = lookups.commitments.find(x => x.id === patch.commitment_id);
        if (c && !draft.po_number) patch.po_number = c.number;
      }
      await must(client.from('invoices').update(patch).eq('id', inv.id).select('id'));
      await rpc('run_invoice_checks', { p_invoice: inv.id });
    } catch (e) { setError(errorText(e)); } finally { setSaving(false); }
  };

  const commitments = lookups.commitments.filter(c => !draft.vendor_id || c.vendor_id === draft.vendor_id || c.id === draft.commitment_id);
  const lowFields = FIELDS.filter(f => conf[f.key as string] !== undefined && conf[f.key as string] < threshold).length + (conf.vendor_name !== undefined && conf.vendor_name < threshold ? 1 : 0);

  return (
    <Card title="Invoice details" actions={<>
      {lowFields > 0 && <Badge tone="amber">{lowFields} field{lowFields > 1 ? 's' : ''} need checking</Badge>}
      {editable && changed.length > 0 && <><Button size="sm" variant="ghost" onClick={() => setDraft(initial)}>Discard</Button><Button size="sm" variant="primary" busy={saving} onClick={save}>Save {changed.length} change{changed.length > 1 ? 's' : ''}</Button></>}
    </>}>
      {!editable && inv.status === 'needs_review' && !can('ap') && <p className="mb-3 text-xs text-slate-500">Your role can view but not edit invoice data.</p>}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Vendor" className="sm:col-span-2" hint={
          <span className="flex flex-wrap items-center gap-2">
            {inv.vendor_name_extracted && <span>On document: “{inv.vendor_name_extracted}”</span>}
            <ConfidencePill value={conf.vendor_name} threshold={threshold} />
            {editable && !draft.vendor_id && inv.vendor_name_extracted && can('ap') && <button type="button" className="underline" onClick={() => setNewVendor(true)}>Create vendor from this name</button>}
          </span>}>
          <Select aria-label="Vendor" disabled={!editable} value={draft.vendor_id} onChange={e => setDraft({ ...draft, vendor_id: e.target.value })}
            className={!draft.vendor_id ? 'border-amber-400' : ''}>
            <option value="">— Not matched —</option>
            {lookups.vendors.filter(v => v.status === 'active' || v.id === draft.vendor_id).map(v => <option key={v.id} value={v.id}>{v.name} ({v.code}){v.status !== 'active' ? ' · inactive' : ''}</option>)}
          </Select>
        </Field>
        <Field label="Commitment (PO / subcontract)" className="sm:col-span-2">
          <Select aria-label="Commitment" disabled={!editable} value={draft.commitment_id} onChange={e => setDraft({ ...draft, commitment_id: e.target.value })}>
            <option value="">— None —</option>
            {commitments.map(c => <option key={c.id} value={c.id}>{c.number} · {lookupLabel(lookups.projects, c.project_id)} · {fmtMoney(c.original_amount)}{c.status !== 'open' ? ' · closed' : ''}</option>)}
          </Select>
        </Field>
        {FIELDS.map(f => {
          const k = f.key as string;
          const c = conf[k];
          const low = c !== undefined && c < threshold;
          return (
            <Field key={k} label={f.label} className={f.key === 'description' ? 'sm:col-span-2' : ''} hint={<ConfidencePill value={c} threshold={threshold} />}>
              <Input aria-label={f.label} disabled={!editable} type={f.type === 'date' ? 'date' : 'text'} inputMode={f.type === 'money' ? 'decimal' : undefined}
                value={draft[k] ?? ''} onChange={e => setDraft({ ...draft, [k]: e.target.value })}
                className={`${low && (draft[k] ?? '') === (initial[k] ?? '') ? 'border-amber-400 bg-amber-50' : ''} ${f.type === 'money' ? 'text-right tabular-nums' : ''}`} />
            </Field>
          );
        })}
      </div>
      <ErrorNote>{error}</ErrorNote>
      <NewVendorDialog open={newVendor} onClose={() => setNewVendor(false)} name={inv.vendor_name_extracted ?? ''} orgId={orgId}
        onCreated={async vendorId => { await must(client.from('invoices').update({ vendor_id: vendorId }).eq('id', inv.id).select('id')); await rpc('run_invoice_checks', { p_invoice: inv.id }); }} />
    </Card>
  );
}

function NewVendorDialog({ open, onClose, name, orgId, onCreated }: { open: boolean; onClose: () => void; name: string; orgId: string; onCreated: (id: string) => Promise<void> }) {
  const [form, setForm] = useState({ name, code: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { if (open) { setForm({ name, code: name.toUpperCase().replace(/[^A-Z0-9]+/g, '').slice(0, 10) }); setError(''); } }, [open, name]);
  return (
    <Modal open={open} title="Create vendor" onClose={onClose} footer={<>
      <Button onClick={onClose}>Cancel</Button>
      <Button variant="primary" busy={busy} disabled={!form.name.trim() || !form.code.trim()} onClick={async () => {
        setBusy(true); setError('');
        try {
          const rows = await must(client.from('vendors').insert({ org_id: orgId, name: form.name.trim(), code: form.code.trim() }).select('id'));
          await onCreated((rows as { id: string }[])[0].id); onClose();
        } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
      }}>Create and match</Button>
    </>}>
      <Notice tone="amber">Check this is genuinely a new vendor and not a variant name of an existing one. New vendors should be verified (W-9, bank details) under your normal vendor onboarding process.</Notice>
      <Field label="Vendor name"><Input aria-label="Vendor name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></Field>
      <Field label="Vendor code" hint="Must match the vendor ID in your accounting system for exports."><Input aria-label="Vendor code" value={form.code} onChange={e => setForm({ ...form, code: e.target.value })} /></Field>
      <ErrorNote>{error}</ErrorNote>
    </Modal>
  );
}

// ------------------------------------------------------------------ commitment match
function MatchPanel({ inv, commitment: c }: { inv: Invoice; commitment: CommitmentSummary | null }) {
  const { lookups } = useOrg();
  if (!c) {
    return (
      <Card title="Commitment match">
        <p className="text-sm text-slate-600">{inv.po_number ? `The document references “${inv.po_number}”, which does not match an open commitment in this company.` : 'Not matched to a purchase order or subcontract.'}
          {lookups.settings?.require_po ? ' Your settings require a commitment for invoices over ' + fmtMoney(lookups.settings.require_po_over_amount) + '.' : ''}</p>
      </Card>
    );
  }
  const revised = num(c.original) + num(c.approved_cos);
  const thisInv = num(inv.total_amount);
  const billedAfter = num(c.billed_other) + thisInv;
  const remaining = round2(revised - billedAfter);
  const pct = revised > 0 ? Math.min(100, (billedAfter / revised) * 100) : 0;
  const expectedRet = round2(thisInv * num(c.retainage_pct) / 100);
  return (
    <Card title={`Commitment ${c.number}`} actions={<Badge>{c.kind === 'subcontract' ? 'Subcontract' : 'Purchase order'}</Badge>}>
      <p className="text-sm text-slate-600">{lookupLabel(lookups.projects, c.project_id)} · {lookups.vendors.find(v => v.id === c.vendor_id)?.name}{c.description ? ` · ${c.description}` : ''}</p>
      <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
        <Metric label="Original" value={fmtMoney(c.original)} />
        <Metric label="Approved change orders" value={fmtMoney(c.approved_cos)} />
        <Metric label="Revised commitment" value={fmtMoney(revised)} strong />
        <Metric label="Billed before this invoice" value={fmtMoney(c.billed_other)} />
        <Metric label="This invoice" value={fmtMoney(thisInv)} />
        <Metric label="Remaining after this invoice" value={fmtMoney(remaining)} strong tone={remaining < 0 ? 'text-red-700' : 'text-emerald-700'} />
      </dl>
      <div className="mt-3 h-2 overflow-hidden rounded bg-slate-100"><div className={`h-full ${billedAfter > revised ? 'bg-red-500' : 'bg-emerald-500'}`} style={{ width: `${pct}%` }} /></div>
      <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-500">
        {num(c.pending_cos) !== 0 && <span className="text-amber-700">Pending change orders: {fmtMoney(c.pending_cos)} (not counted until approved)</span>}
        {num(c.retainage_pct) > 0 && <span>Retainage {num(c.retainage_pct)}% → expected {fmtMoney(expectedRet)}; invoice shows {fmtMoney(inv.retainage_amount)}</span>}
        <span>Billed totals include invoices awaiting approval and approved; void and rejected are excluded.</span>
      </div>
    </Card>
  );
}

function Metric({ label, value, strong, tone }: { label: string; value: string; strong?: boolean; tone?: string }) {
  return <div><dt className="text-xs text-slate-500">{label}</dt><dd className={`tabular-nums ${strong ? 'font-semibold' : ''} ${tone ?? 'text-slate-900'}`}>{value}</dd></div>;
}

// ------------------------------------------------------------------ allocations
type Draft = { key: string; id?: string; project_id: string; cost_code_id: string; cost_type_id: string; gl_account_id: string; amount: string; description: string; source: string; confidence: string | null; rationale: string | null };

function toDraft(a: Allocation): Draft {
  return { key: a.id, id: a.id, project_id: a.project_id ?? '', cost_code_id: a.cost_code_id ?? '', cost_type_id: a.cost_type_id ?? '', gl_account_id: a.gl_account_id ?? '',
    amount: a.amount ?? '0', description: a.description ?? '', source: a.source, confidence: a.confidence, rationale: a.rationale };
}
const sameDraft = (x: Draft, a: Allocation) => x.project_id === (a.project_id ?? '') && x.cost_code_id === (a.cost_code_id ?? '') && x.cost_type_id === (a.cost_type_id ?? '')
  && x.gl_account_id === (a.gl_account_id ?? '') && num(x.amount) === num(a.amount) && x.description === (a.description ?? '');

function AllocationsPanel({ inv, allocations, editable, threshold, commitment }: { inv: Invoice; allocations: Allocation[]; editable: boolean; threshold: number; commitment: CommitmentSummary | null }) {
  const { lookups, orgId } = useOrg();
  const [rows, setRows] = useState<Draft[]>(() => allocations.map(toDraft));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const sig = JSON.stringify(allocations);
  useEffect(() => setRows(allocations.map(toDraft)), [sig]); // eslint-disable-line react-hooks/exhaustive-deps
  const total = num(inv.total_amount);
  const sum = round2(rows.reduce((s, r) => s + num(r.amount), 0));
  const diff = round2(total - sum);
  const removed = allocations.filter(a => !rows.some(r => r.id === a.id));
  const dirty = removed.length > 0 || rows.some(r => !r.id || !sameDraft(r, allocations.find(a => a.id === r.id)!));

  const set = (key: string, patch: Partial<Draft>) => setRows(rs => rs.map(r => r.key === key ? { ...r, ...patch } : r));
  const add = () => setRows(rs => [...rs, {
    key: crypto.randomUUID(), project_id: commitment?.project_id ?? rs[0]?.project_id ?? '', cost_code_id: '', cost_type_id: '', gl_account_id: '',
    amount: diff > 0 ? diff.toFixed(2) : '0', description: '', source: 'user', confidence: null, rationale: null,
  }]);

  const save = async () => {
    setSaving(true); setError('');
    try {
      for (const a of removed) await must(client.from('invoice_allocations').delete().eq('id', a.id).select('id'));
      for (const r of rows) {
        const values = {
          project_id: r.project_id || null, cost_code_id: r.cost_code_id || null, cost_type_id: r.cost_type_id || null, gl_account_id: r.gl_account_id || null,
          amount: round2(num(r.amount)), description: r.description.trim() || null,
        };
        if (!r.id) await must(client.from('invoice_allocations').insert({ ...values, org_id: orgId, invoice_id: inv.id, source: 'user' }).select('id'));
        else if (!sameDraft(r, allocations.find(a => a.id === r.id)!)) await must(client.from('invoice_allocations').update({ ...values, source: 'user', confidence: null }).eq('id', r.id).select('id'));
      }
      await rpc('run_invoice_checks', { p_invoice: inv.id });
    } catch (e) { setError(errorText(e)); } finally { setSaving(false); }
  };

  const codesFor = (projectId: string) => lookups.cost_codes.filter(c => c.project_id === null || c.project_id === projectId);

  return (
    <Card title="Job cost coding" actions={<>
      <span className={`text-xs tabular-nums ${Math.abs(diff) < 0.005 ? 'text-emerald-700' : 'text-red-700'}`}>
        Coded {fmtMoney(sum)} of {fmtMoney(total)}{Math.abs(diff) >= 0.005 ? ` · ${diff > 0 ? 'unallocated' : 'over by'} ${fmtMoney(Math.abs(diff))}` : ' · balanced'}
      </span>
      {editable && <Button size="sm" onClick={add}><Plus className="size-3.5" />Add split</Button>}
      {editable && dirty && <><Button size="sm" variant="ghost" onClick={() => setRows(allocations.map(toDraft))}>Discard</Button><Button size="sm" variant="primary" busy={saving} onClick={save}>Save coding</Button></>}
    </>} bodyClassName="p-0">
      {rows.length === 0 ? <p className="p-4 text-sm text-slate-500">No coding yet.{editable ? ' Add a split to code this invoice to a job, cost code and cost type.' : ''}</p> : (
        <div className="divide-y divide-slate-100">
          {rows.map((r, idx) => {
            const conf = r.confidence === null ? undefined : num(r.confidence);
            return (
              <div key={r.key} className="grid gap-2 p-3 sm:grid-cols-12">
                <div className="flex items-center gap-2 sm:col-span-12">
                  <span className="text-xs font-medium text-slate-500">Split {idx + 1}</span>
                  {r.source === 'ai' && <Badge tone="violet"><Bot className="size-3" />AI suggested</Badge>}
                  {r.source === 'rule' && <Badge tone="blue">From commitment</Badge>}
                  {r.source === 'user' && r.id && <Badge><User className="size-3" />Set by person</Badge>}
                  {conf !== undefined && r.source !== 'user' && <ConfidencePill value={conf} threshold={threshold} />}
                  {editable && <button type="button" aria-label={`Remove split ${idx + 1}`} className="ml-auto rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-red-600" onClick={() => setRows(rs => rs.filter(x => x.key !== r.key))}><Trash2 className="size-4" /></button>}
                </div>
                <Select aria-label={`Job for split ${idx + 1}`} disabled={!editable} value={r.project_id} onChange={e => set(r.key, { project_id: e.target.value, cost_code_id: '' })} className={`sm:col-span-4 ${!r.project_id ? 'border-amber-400' : ''}`}>
                  <option value="">Job…</option>
                  {lookups.projects.filter(p => p.status === 'active' || p.id === r.project_id).map(p => <option key={p.id} value={p.id}>{p.code} · {p.name}</option>)}
                </Select>
                <Select aria-label={`Cost code for split ${idx + 1}`} disabled={!editable} value={r.cost_code_id} onChange={e => set(r.key, { cost_code_id: e.target.value })} className={`sm:col-span-4 ${!r.cost_code_id ? 'border-amber-400' : ''}`}>
                  <option value="">Cost code…</option>
                  {codesFor(r.project_id).map(c => <option key={c.id} value={c.id}>{c.code} · {c.name}</option>)}
                </Select>
                <Select aria-label={`Cost type for split ${idx + 1}`} disabled={!editable} value={r.cost_type_id} onChange={e => set(r.key, { cost_type_id: e.target.value })} className={`sm:col-span-2 ${!r.cost_type_id ? 'border-amber-400' : ''}`}>
                  <option value="">Type…</option>
                  {lookups.cost_types.map(t => <option key={t.id} value={t.id}>{t.code} · {t.name}</option>)}
                </Select>
                <Input aria-label={`Amount for split ${idx + 1}`} disabled={!editable} inputMode="decimal" value={r.amount} onChange={e => set(r.key, { amount: e.target.value })} className="text-right tabular-nums sm:col-span-2" />
                <Select aria-label={`GL account for split ${idx + 1}`} disabled={!editable} value={r.gl_account_id} onChange={e => set(r.key, { gl_account_id: e.target.value })} className="sm:col-span-4">
                  <option value="">GL account (optional)…</option>
                  {lookups.gl_accounts.filter(g => g.active || g.id === r.gl_account_id).map(g => <option key={g.id} value={g.id}>{g.code} · {g.name}</option>)}
                </Select>
                <Input aria-label={`Description for split ${idx + 1}`} disabled={!editable} placeholder="Description" value={r.description} onChange={e => set(r.key, { description: e.target.value })} className="sm:col-span-8" />
                {r.rationale && <p className="text-xs text-slate-500 sm:col-span-12"><span className="font-medium">{r.source === 'ai' ? 'AI rationale' : 'Basis'}:</span> {r.rationale}</p>}
              </div>
            );
          })}
        </div>
      )}
      {error && <div className="p-3"><ErrorNote>{error}</ErrorNote></div>}
    </Card>
  );
}

function LinesPanel({ lines, currency }: { lines: Line[]; currency: string }) {
  return (
    <Card title={`Line items on the document (${lines.length})`} bodyClassName="p-0">
      <Table>
        <thead><tr><Th>#</Th><Th>Description</Th><Th className="text-right">Qty</Th><Th className="text-right">Unit price</Th><Th className="text-right">Amount</Th></tr></thead>
        <tbody>{lines.map(l => (
          <tr key={l.id}><Td>{l.line_no}</Td><Td>{l.description}</Td><Td className="text-right tabular-nums">{l.quantity !== null ? num(l.quantity) : '—'}</Td>
            <Td className="text-right tabular-nums">{l.unit_price !== null ? fmtMoney(l.unit_price, currency) : '—'}</Td><Td className="text-right tabular-nums">{fmtMoney(l.amount, currency)}</Td></tr>
        ))}</tbody>
      </Table>
    </Card>
  );
}

// ------------------------------------------------------------------ approvals
function ApprovalsPanel({ inv, steps }: { inv: Invoice; steps: ApprovalStep[] }) {
  const { memberName, can, lookups } = useOrg();
  const [reassign, setReassign] = useState<ApprovalStep | null>(null);
  const [to, setTo] = useState('');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  if (steps.length === 0) return (
    <Card title="Approvals"><p className="text-sm text-slate-500">{inv.status === 'needs_review' ? 'Approval routing is decided by your rules when the invoice is submitted.' : 'No approval steps.'}</p></Card>
  );
  const rounds = [...new Set(steps.map(s => s.round))].sort((a, b) => b - a);
  const approvers = lookups.members.filter(m => m.active && m.role !== 'viewer');
  return (
    <Card title="Approvals">
      {rounds.map(round => (
        <div key={round} className="mb-3 last:mb-0">
          <p className="mb-1 text-xs font-medium text-slate-500">{round === inv.approval_round ? `Current round (${round})` : `Earlier round ${round}`}</p>
          <ol className="flex flex-col gap-1.5">
            {steps.filter(s => s.round === round).map(s => (
              <li key={s.id} className="flex flex-wrap items-start justify-between gap-2 rounded-md border border-slate-200 p-2 text-sm">
                <div>
                  <span className="font-medium">Step {s.step_order}: {s.approver_user_id ? memberName(s.approver_user_id) : `Any ${s.approver_role === 'controller' ? 'controller or owner' : s.approver_role}`}</span>
                  <p className="text-xs text-slate-500">{s.reason}</p>
                  {s.decided_by && <p className="text-xs text-slate-600">{s.status === 'approved' ? 'Approved' : s.status === 'rejected' ? 'Rejected' : s.status} by {memberName(s.decided_by)} · {fmtDateTime(s.decided_at)}{s.comment ? ` — “${s.comment}”` : ''}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={s.status === 'approved' ? 'green' : s.status === 'rejected' ? 'red' : s.status === 'pending' ? 'amber' : 'gray'}>{s.status}</Badge>
                  {s.status === 'pending' && round === inv.approval_round && inv.status === 'pending_approval' && can('admin') && <Button size="sm" onClick={() => { setReassign(s); setTo(''); setReason(''); setError(''); }}>Reassign</Button>}
                </div>
              </li>
            ))}
          </ol>
        </div>
      ))}
      <Modal open={!!reassign} title="Reassign approval step" onClose={() => setReassign(null)} footer={<>
        <Button onClick={() => setReassign(null)}>Cancel</Button>
        <Button variant="primary" busy={busy} disabled={!to || reason.trim().length < 3} onClick={async () => {
          setBusy(true); setError('');
          try { await rpc('reassign_approval', { p_step: reassign!.id, p_user: to, p_reason: reason.trim() }); setReassign(null); } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
        }}>Reassign</Button>
      </>}>
        <Field label="New approver"><Select aria-label="New approver" value={to} onChange={e => setTo(e.target.value)}><option value="">Choose…</option>{approvers.map(m => <option key={m.user_id} value={m.user_id}>{m.display_name || m.email} · {m.role}</option>)}</Select></Field>
        <Field label="Reason"><Textarea aria-label="Reassign reason" rows={2} value={reason} onChange={e => setReason(e.target.value)} /></Field>
        <ErrorNote>{error}</ErrorNote>
      </Modal>
    </Card>
  );
}

function SyncPanel({ rows }: { rows: SyncRow[] }) {
  return (
    <Card title="Accounting sync history" bodyClassName="p-0">
      <Table>
        <thead><tr><Th>Attempt</Th><Th>Batch</Th><Th>Status</Th><Th>External ID / error</Th><Th>Updated</Th></tr></thead>
        <tbody>{rows.map(r => (
          <tr key={r.id}><Td>{r.attempt}</Td><Td>#{r.batch_number}</Td><Td><SyncBadge status={r.status} /></Td><Td className="text-xs">{r.external_id ?? r.error ?? <span className="text-slate-400">Awaiting results file</span>}<div className="text-slate-400">{r.idempotency_key}</div></Td><Td className="text-xs">{fmtDateTime(r.updated_at)}</Td></tr>
        ))}</tbody>
      </Table>
    </Card>
  );
}

export function AuditPanel({ events, memberName }: { events: AuditEvent[]; memberName: (id: string | null) => string }) {
  const [all, setAll] = useState(false);
  const shown = all ? events : events.slice(0, 12);
  return (
    <Card title="Audit trail" actions={events.length > 12 && <Button size="sm" variant="ghost" onClick={() => setAll(a => !a)}>{all ? 'Show recent' : `Show all ${events.length}`}</Button>}>
      {events.length === 0 ? <p className="text-sm text-slate-500">No events yet.</p> : (
        <ol className="flex flex-col gap-2">
          {shown.map(e => (
            <li key={e.id} className="flex gap-2 text-sm">
              <span className="mt-0.5 shrink-0">{e.actor_kind === 'agent' ? <Bot className="size-4 text-violet-600" /> : e.actor_kind === 'system' ? <RefreshCw className="size-4 text-slate-400" /> : <User className="size-4 text-slate-500" />}</span>
              <div className="min-w-0">
                <p className="text-slate-800">{e.summary}</p>
                <p className="text-xs text-slate-500">{e.actor_kind === 'agent' ? `AI agent (on behalf of ${memberName(e.actor_user_id)})` : e.actor_kind === 'system' ? 'Controls engine' : memberName(e.actor_user_id)} · {fmtDateTime(e.created_at)}</p>
                <AuditDetails details={e.details} />
              </div>
            </li>
          ))}
        </ol>
      )}
    </Card>
  );
}

function AuditDetails({ details }: { details: Record<string, unknown> }) {
  const changes = details?.changes as Record<string, { from: unknown; to: unknown; ai_value?: unknown }> | undefined;
  if (!changes) return null;
  const show = (v: unknown) => (v === null || v === undefined || v === '' ? '∅' : String(v));
  return (
    <ul className="text-xs text-slate-500">
      {Object.entries(changes).map(([k, c]) => (
        <li key={k}>{k.replace(/_/g, ' ')}: <span className="line-through">{show(c.from)}</span> → <span className="font-medium text-slate-700">{show(c.to)}</span></li>
      ))}
    </ul>
  );
}
