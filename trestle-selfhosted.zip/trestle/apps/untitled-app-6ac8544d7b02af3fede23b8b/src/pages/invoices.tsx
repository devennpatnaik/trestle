import { useEffect, useRef, useState } from 'react';
import { FilePlus2, Upload } from 'lucide-react';
import { client } from '../client';
import { useRows } from '../db';
import { INVOICE_FILTERS, invoiceListSql } from '@project/queries';
import { uploadFile } from '../uploads';
import { useOrg, go } from '../org';
import { downloadText, errorText, fmtDate, fmtMoney, must, toCsv, STATUS_LABELS } from '../lib/api';
import { Badge, Button, Card, Empty, ErrorNote, Input, Loading, Notice, PageHeader, Select, Table, Td, Th } from '../components/ui';
import { InvoiceStatusBadge, ExtractionBadge, SyncBadge } from './shared';

export type InvoiceRow = {
  id: string; invoice_number: string | null; vendor_name: string | null; vendor_name_extracted: string | null; invoice_date: string | null;
  due_date: string | null; total_amount: string | null; currency: string; status: string; extraction_status: string; sync_status: string;
  file_name: string | null; created_at: string; projects: string | null; blocking: number; warnings: number; po_number: string | null;
};

const FILTERS = INVOICE_FILTERS;
export { invoiceListSql };

function filterFromHash() {
  const id = new URLSearchParams(window.location.hash.split('?')[1] ?? '').get('filter') ?? 'open';
  return FILTERS.some(f => f.id === id) ? id : 'open';
}

export default function Invoices() {
  const { orgId, can, userId } = useOrg();
  const [filter, setFilter] = useState(filterFromHash);
  // Overview cards and links change the hash while this page may already be open.
  useEffect(() => {
    const sync = () => setFilter(filterFromHash());
    window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, []);
  const [search, setSearch] = useState('');
  const [q, setQ] = useState('');
  useEffect(() => { const t = setTimeout(() => setQ(search.trim()), 300); return () => clearTimeout(t); }, [search]);
  const where = FILTERS.find(f => f.id === filter)!.where;
  const { rows, loading, error } = useRows<InvoiceRow>(invoiceListSql(where), [orgId, q]);
  const [uploading, setUploading] = useState<string[]>([]);
  const [uploadError, setUploadError] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const upload = async (files: FileList | File[]) => {
    setUploadError('');
    const list = Array.from(files);
    for (const file of list) {
      if (!/pdf|image\//.test(file.type) && !/\.(pdf|png|jpe?g|heic|webp|tiff?)$/i.test(file.name)) {
        setUploadError(`${file.name}: only PDF and image files can be read as invoices.`); continue;
      }
      setUploading(u => [...u, file.name]);
      try {
        const row = await uploadFile(file);
        await must(client.from('invoices').insert({ org_id: orgId, source: 'upload', upload_id: row.id, file_name: file.name, created_by: userId }).select('id'));
      } catch (e) {
        setUploadError(`${file.name}: ${errorText(e)}`);
      } finally {
        setUploading(u => u.filter(n => n !== file.name));
      }
    }
  };

  const createManual = async () => {
    try {
      const data = await must(client.from('invoices').insert({ org_id: orgId, source: 'manual', extraction_status: 'manual', created_by: userId }).select('id'));
      go(`invoices/${(data as { id: string }[])[0].id}`);
    } catch (e) { setUploadError(errorText(e)); }
  };

  const exportCsv = () => {
    downloadText(`invoices-${filter}-${new Date().toISOString().slice(0, 10)}.csv`, toCsv(rows.map(r => ({
      invoice_number: r.invoice_number, vendor: r.vendor_name ?? r.vendor_name_extracted, projects: r.projects, invoice_date: r.invoice_date,
      due_date: r.due_date, total: r.total_amount, currency: r.currency, po_number: r.po_number, status: STATUS_LABELS[r.status] ?? r.status,
      sync_status: r.sync_status, open_blocking: r.blocking, open_warnings: r.warnings, invoice_id: r.id,
    }))));
  };

  return (
    <div>
      <PageHeader title="Invoices" subtitle="Upload vendor invoices; the AI reads and codes them, the controls engine checks them, people approve them."
        actions={<>
          <Button onClick={exportCsv} disabled={!rows.length}>Export CSV</Button>
          {can('ap') && <Button onClick={createManual}><FilePlus2 className="size-4" />Enter manually</Button>}
          {can('ap') && <Button variant="primary" onClick={() => fileRef.current?.click()}><Upload className="size-4" />Upload invoices</Button>}
        </>} />
      <input ref={fileRef} type="file" multiple accept="application/pdf,image/*" className="hidden" aria-label="Invoice files"
        onChange={e => { if (e.target.files) void upload(e.target.files); e.target.value = ''; }} />
      {can('ap') && (
        <div onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)}
          onDrop={e => { e.preventDefault(); setDragging(false); void upload(e.dataTransfer.files); }}
          className={`mb-4 rounded-lg border-2 border-dashed px-4 py-4 text-center text-sm ${dragging ? 'border-slate-600 bg-slate-100' : 'border-slate-300 text-slate-500'}`}>
          Drop invoice PDFs or photos here. Each file becomes one invoice; the original is kept with the record.
          {uploading.length > 0 && <p className="mt-1 text-slate-700">Uploading {uploading.join(', ')}…</p>}
        </div>
      )}
      <ErrorNote>{uploadError}</ErrorNote>
      <Card bodyClassName="p-0">
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 p-3">
          <Select aria-label="Filter" value={filter} onChange={e => setFilter(e.target.value)} className="w-auto">
            {FILTERS.map(f => <option key={f.id} value={f.id}>{f.label}</option>)}
          </Select>
          <Input aria-label="Search invoices" placeholder="Search number, vendor, PO, job…" value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs" />
          <span className="ml-auto text-xs text-slate-500">{rows.length === 500 ? 'Showing the newest 500' : `${rows.length} invoice${rows.length === 1 ? '' : 's'}`}</span>
        </div>
        {error && <div className="p-3"><Notice tone="amber">Live updates paused: {error}</Notice></div>}
        {loading ? <div className="px-4"><Loading /></div> : rows.length === 0 ? (
          <div className="p-4"><Empty title="No invoices here">{filter === 'open' ? 'Upload an invoice PDF or photo to start. Nothing is posted anywhere until it is approved and exported.' : 'Try another filter.'}</Empty></div>
        ) : <InvoiceTable rows={rows} />}
      </Card>
    </div>
  );
}

export function InvoiceTable({ rows }: { rows: InvoiceRow[] }) {
  return (
    <Table>
      <thead><tr><Th>Invoice</Th><Th>Vendor</Th><Th>Job</Th><Th>Date</Th><Th className="text-right">Total</Th><Th>Status</Th><Th>Exceptions</Th></tr></thead>
      <tbody>
        {rows.map(r => (
          <tr key={r.id} className="cursor-pointer hover:bg-slate-50" onClick={() => go(`invoices/${r.id}`)}>
            <Td>
              <a href={`#/invoices/${r.id}`} className="font-medium text-slate-900 hover:underline">{r.invoice_number ?? <span className="text-slate-400">No number yet</span>}</a>
              <div className="max-w-48 truncate text-xs text-slate-500">{r.file_name ?? 'Manual entry'}</div>
            </Td>
            <Td>{r.vendor_name ?? (r.vendor_name_extracted ? <span className="text-amber-700" title="Not matched to a vendor record">{r.vendor_name_extracted} (unmatched)</span> : '—')}</Td>
            <Td>{r.projects ?? '—'}</Td>
            <Td className="whitespace-nowrap">{fmtDate(r.invoice_date)}</Td>
            <Td className="whitespace-nowrap text-right tabular-nums">{fmtMoney(r.total_amount, r.currency)}</Td>
            <Td><div className="flex flex-col items-start gap-1"><InvoiceStatusBadge status={r.status} /><ExtractionBadge status={r.extraction_status} />{r.status === 'approved' && <SyncBadge status={r.sync_status} />}</div></Td>
            <Td>
              <div className="flex flex-wrap gap-1">
                {r.blocking > 0 && <Badge tone="red">{r.blocking} blocking</Badge>}
                {r.warnings > 0 && <Badge tone="amber">{r.warnings} to check</Badge>}
                {r.blocking === 0 && r.warnings === 0 && r.status === 'needs_review' && r.extraction_status !== 'pending' && r.extraction_status !== 'running' && <Badge tone="green">Clear</Badge>}
              </div>
            </Td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}
