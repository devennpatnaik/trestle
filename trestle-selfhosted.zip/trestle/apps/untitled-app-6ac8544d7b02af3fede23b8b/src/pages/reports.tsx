import { useState } from 'react';
import { useRows } from '../db';
import { exceptionReportSql, queries } from '@project/queries';
import { useOrg } from '../org';
import { downloadText, fmtMoney, num, round2, toCsv, STATUS_LABELS, SYNC_LABELS } from '../lib/api';
import { Button, Card, Field, Input, Loading, PageHeader, Select, Table, Tabs, Td, Th } from '../components/ui';

type Tab = 'register' | 'job_cost' | 'commitments' | 'exceptions' | 'processing';
const today = () => new Date().toISOString().slice(0, 10);
const daysAgo = (n: number) => new Date(Date.now() - n * 86400_000).toISOString().slice(0, 10);

export default function Reports() {
  const [tab, setTab] = useState<Tab>('register');
  const [from, setFrom] = useState(daysAgo(90));
  const [to, setTo] = useState(today());
  return (
    <div>
      <PageHeader title="Reports" subtitle="Computed live from your invoice records. Every report exports to CSV." />
      <Tabs value={tab} onChange={setTab} tabs={[
        { id: 'register', label: 'Invoice register' }, { id: 'job_cost', label: 'Job cost by cost code' }, { id: 'commitments', label: 'Commitments vs billed' },
        { id: 'exceptions', label: 'Exceptions' }, { id: 'processing', label: 'Processing time' },
      ]} />
      {tab !== 'commitments' && (
        <div className="mb-3 flex flex-wrap items-end gap-3">
          <Field label="From (received)"><Input aria-label="From date" type="date" value={from} onChange={e => setFrom(e.target.value)} /></Field>
          <Field label="To"><Input aria-label="To date" type="date" value={to} onChange={e => setTo(e.target.value)} /></Field>
        </div>
      )}
      {tab === 'register' && <Register from={from} to={to} />}
      {tab === 'job_cost' && <JobCost from={from} to={to} />}
      {tab === 'commitments' && <CommitmentReport />}
      {tab === 'exceptions' && <ExceptionsReport from={from} to={to} />}
      {tab === 'processing' && <Processing from={from} to={to} />}
    </div>
  );
}

function Register({ from, to }: { from: string; to: string }) {
  const { orgId } = useOrg();
  const [status, setStatus] = useState('all');
  const { rows, loading } = useRows<Record<string, string | number | null>>(queries.invoiceRegister, [orgId, from, to, status]);
  const total = round2(rows.reduce((s, r) => s + num(r.total_amount), 0));
  return (
    <Card bodyClassName="p-0" title={`${rows.length} invoices · ${fmtMoney(total)}`} actions={<>
      <Select aria-label="Status" className="w-44" value={status} onChange={e => setStatus(e.target.value)}><option value="all">All statuses</option>{Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
      <Button onClick={() => downloadText(`invoice-register-${from}-${to}.csv`, toCsv(rows))} disabled={!rows.length}>Export CSV</Button>
    </>}>
      {loading ? <div className="px-4"><Loading /></div> : (
        <Table>
          <thead><tr><Th>Invoice</Th><Th>Vendor</Th><Th>Jobs</Th><Th>Date</Th><Th className="text-right">Total</Th><Th>Status</Th><Th>Accounting</Th></tr></thead>
          <tbody>{rows.slice(0, 300).map(r => (
            <tr key={String(r.invoice_id)}><Td><a className="hover:underline" href={`#/invoices/${r.invoice_id}`}>{r.invoice_number ?? '—'}</a></Td><Td>{r.vendor}</Td><Td>{r.jobs}</Td><Td>{r.invoice_date}</Td>
              <Td className="text-right tabular-nums">{fmtMoney(r.total_amount as string)}</Td><Td>{STATUS_LABELS[String(r.status)]}</Td><Td className="text-xs">{r.status === 'approved' ? SYNC_LABELS[String(r.sync_status)] : '—'}</Td></tr>
          ))}</tbody>
        </Table>
      )}
      {rows.length > 300 && <p className="p-3 text-xs text-slate-500">Showing 300 rows on screen; the CSV contains all {rows.length}.</p>}
    </Card>
  );
}

function JobCost({ from, to }: { from: string; to: string }) {
  const { orgId } = useOrg();
  const [basis, setBasis] = useState<'approved' | 'all_open'>('approved');
  const { rows, loading } = useRows<{ job: string; job_name: string; cost_code: string | null; cost_code_name: string | null; cost_type: string | null; amount: string; invoices: number; budget: string | null }>(queries.jobCost, [orgId, from, to, basis]);
  return (
    <Card bodyClassName="p-0" title="Invoiced cost by job and cost code" actions={<>
      <Select aria-label="Basis" className="w-56" value={basis} onChange={e => setBasis(e.target.value as 'approved')}><option value="approved">Approved invoices only</option><option value="all_open">Approved + in process</option></Select>
      <Button onClick={() => downloadText(`job-cost-${from}-${to}.csv`, toCsv(rows))} disabled={!rows.length}>Export CSV</Button>
    </>}>
      <p className="px-4 pt-3 text-xs text-slate-500">AP invoices only; does not include payroll, card spend or costs entered directly in your ERP. Budget shows the cost code's budget when one was imported.</p>
      {loading ? <div className="px-4"><Loading /></div> : (
        <Table className="mt-2">
          <thead><tr><Th>Job</Th><Th>Cost code</Th><Th>Type</Th><Th className="text-right">Invoices</Th><Th className="text-right">Amount</Th><Th className="text-right">Budget</Th></tr></thead>
          <tbody>{rows.length === 0 ? <tr><Td colSpan={6} className="text-slate-500">No coded invoices in this period.</Td></tr> : rows.map((r, i) => (
            <tr key={i}><Td>{r.job ?? <span className="text-amber-700">Uncoded</span>} <span className="text-xs text-slate-500">{r.job_name}</span></Td><Td>{r.cost_code ?? '—'} <span className="text-xs text-slate-500">{r.cost_code_name}</span></Td><Td>{r.cost_type ?? '—'}</Td>
              <Td className="text-right">{r.invoices}</Td><Td className="text-right tabular-nums">{fmtMoney(r.amount)}</Td><Td className="text-right tabular-nums">{r.budget ? fmtMoney(r.budget) : '—'}</Td></tr>
          ))}</tbody>
        </Table>
      )}
    </Card>
  );
}

function CommitmentReport() {
  const { orgId } = useOrg();
  const { rows, loading } = useRows<{ number: string; kind: string; vendor: string; job: string; status: string; original: string; approved_cos: string; pending_cos: string; billed_approved: string; billed_pending: string; retainage_held: string }>(queries.commitmentStatus, [orgId]);
  const enriched = rows.map(r => {
    const revised = round2(num(r.original) + num(r.approved_cos));
    const billed = round2(num(r.billed_approved) + num(r.billed_pending));
    return { ...r, revised, billed_total: billed, remaining: round2(revised - billed), pct_billed: revised ? Math.round((billed / revised) * 1000) / 10 : null };
  });
  return (
    <Card bodyClassName="p-0" title="Commitments vs billed" actions={<Button onClick={() => downloadText('commitments-vs-billed.csv', toCsv(enriched))} disabled={!rows.length}>Export CSV</Button>}>
      {loading ? <div className="px-4"><Loading /></div> : (
        <Table>
          <thead><tr><Th>Commitment</Th><Th>Vendor</Th><Th>Job</Th><Th className="text-right">Revised</Th><Th className="text-right">Billed (approved)</Th><Th className="text-right">Awaiting approval</Th><Th className="text-right">Remaining</Th><Th className="text-right">% billed</Th><Th className="text-right">Retainage held</Th></tr></thead>
          <tbody>{enriched.length === 0 ? <tr><Td colSpan={9} className="text-slate-500">No commitments.</Td></tr> : enriched.map(r => (
            <tr key={r.number}><Td>{r.number}</Td><Td>{r.vendor}</Td><Td>{r.job}</Td><Td className="text-right tabular-nums">{fmtMoney(r.revised)}{num(r.pending_cos) !== 0 && <div className="text-xs text-amber-700">+{fmtMoney(r.pending_cos)} pending CO</div>}</Td>
              <Td className="text-right tabular-nums">{fmtMoney(r.billed_approved)}</Td><Td className="text-right tabular-nums">{fmtMoney(r.billed_pending)}</Td>
              <Td className={`text-right tabular-nums ${r.remaining < 0 ? 'font-semibold text-red-700' : ''}`}>{fmtMoney(r.remaining)}</Td><Td className="text-right">{r.pct_billed ?? '—'}%</Td><Td className="text-right tabular-nums">{fmtMoney(r.retainage_held)}</Td></tr>
          ))}</tbody>
        </Table>
      )}
    </Card>
  );
}

function ExceptionsReport({ from, to }: { from: string; to: string }) {
  const { orgId } = useOrg();
  const [group, setGroup] = useState<'code' | 'vendor' | 'job'>('code');
  const { rows, loading } = useRows<{ grp: string; total: number; open: number; overridden: number; acknowledged: number; resolved: number; blocking: number; amount: string }>(exceptionReportSql(group), [orgId, from, to]);
  return (
    <Card bodyClassName="p-0" title="Exceptions raised" actions={<>
      <Select aria-label="Group by" className="w-40" value={group} onChange={e => setGroup(e.target.value as 'code')}><option value="code">By type</option><option value="vendor">By vendor</option><option value="job">By job</option></Select>
      <Button onClick={() => downloadText(`exceptions-by-${group}-${from}-${to}.csv`, toCsv(rows))} disabled={!rows.length}>Export CSV</Button>
    </>}>
      {loading ? <div className="px-4"><Loading /></div> : (
        <Table>
          <thead><tr><Th>{group === 'code' ? 'Exception' : group === 'vendor' ? 'Vendor' : 'Job'}</Th><Th className="text-right">Total</Th><Th className="text-right">Blocking</Th><Th className="text-right">Open</Th><Th className="text-right">Overridden</Th><Th className="text-right">Acknowledged</Th><Th className="text-right">Cleared by fix</Th></tr></thead>
          <tbody>{rows.length === 0 ? <tr><Td colSpan={7} className="text-slate-500">No exceptions in this period.</Td></tr> : rows.map(r => (
            <tr key={r.grp}><Td>{r.grp}</Td><Td className="text-right">{r.total}</Td><Td className="text-right">{r.blocking}</Td><Td className="text-right">{r.open}</Td><Td className={`text-right ${r.overridden ? 'text-red-700' : ''}`}>{r.overridden}</Td><Td className="text-right">{r.acknowledged}</Td><Td className="text-right">{r.resolved}</Td></tr>
          ))}</tbody>
        </Table>
      )}
    </Card>
  );
}

function Processing({ from, to }: { from: string; to: string }) {
  const { orgId } = useOrg();
  const { rows, loading } = useRows<{ received: number; approved: number; median_receipt_to_submit_h: number | null; median_submit_to_approve_h: number | null; p90_receipt_to_approve_h: number | null; ai_extracted: number; ai_failed: number; manual: number; fields_extracted: number; fields_corrected: number; touchless: number }>(queries.cycleMetrics, [orgId, from, to]);
  const r = rows[0];
  if (loading || !r) return <Loading />;
  const metric = (label: string, value: string, hint?: string) => <div className="rounded-lg border border-slate-200 bg-white p-3"><p className="text-xs text-slate-500">{label}</p><p className="text-xl font-semibold tabular-nums">{value}</p>{hint && <p className="text-xs text-slate-500">{hint}</p>}</div>;
  const h = (v: number | null) => (v === null ? '—' : `${v}h`);
  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {metric('Invoices received', String(r.received))}
        {metric('Approved', String(r.approved))}
        {metric('Median receipt → submitted', h(r.median_receipt_to_submit_h))}
        {metric('Median submitted → approved', h(r.median_submit_to_approve_h))}
        {metric('90th percentile receipt → approved', h(r.p90_receipt_to_approve_h))}
        {metric('AI extracted / failed / manual', `${r.ai_extracted} / ${r.ai_failed} / ${r.manual}`)}
        {metric('AI fields corrected', r.fields_extracted ? `${Math.round((r.fields_corrected / r.fields_extracted) * 1000) / 10}%` : '—', `${r.fields_corrected} of ${r.fields_extracted} fields`)}
        {metric('Approved with no human edits', r.approved ? `${r.touchless} of ${r.approved}` : '—', 'No field corrections and no coding changes')}
      </div>
      <p className="text-xs text-slate-500">All figures are measured from timestamps and audit events in this period. No savings estimates are shown.</p>
    </div>
  );
}
