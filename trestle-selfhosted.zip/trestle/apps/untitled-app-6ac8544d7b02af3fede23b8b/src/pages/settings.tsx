import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { client } from '../client';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg } from '../org';
import { errorText, fmtDateTime, fmtMoney, must, rpc, ROLE_LABELS } from '../lib/api';
import { Badge, Button, Card, ErrorNote, Field, Input, Modal, Notice, PageHeader, Select, Table, Tabs, Td, Th } from '../components/ui';
import type { Member, Role } from '../types';

type Tab = 'team' | 'rules' | 'controls' | 'company';

export default function SettingsPage() {
  const [tab, setTab] = useState<Tab>('team');
  return (
    <div>
      <PageHeader title="Settings" />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'team', label: 'Team & roles' }, { id: 'rules', label: 'Approval rules' }, { id: 'controls', label: 'Controls' }, { id: 'company', label: 'Company' }]} />
      {tab === 'team' && <Team />}
      {tab === 'rules' && <Rules />}
      {tab === 'controls' && <Controls />}
      {tab === 'company' && <Company />}
    </div>
  );
}

const ROLE_HELP: Record<Role, string> = {
  owner: 'Everything, including inviting people, changing roles and company settings.',
  controller: 'Approval rules and controls, override blocking exceptions, approve any controller step, export to accounting.',
  ap_clerk: 'Upload, review, correct and code invoices; submit for approval; maintain vendors, jobs and cost codes.',
  project_manager: 'Sees and approves invoices routed to them or coded to their jobs.',
  viewer: 'Read-only access to invoices, master data and reports.',
};

function Team() {
  const { orgId, lookups, can, userId } = useOrg();
  const { rows: invites } = useRows<{ id: string; email: string; role: Role; approval_limit: string | null; accepted_at: string | null; created_at: string }>(
    queries.invites, [can('admin') ? orgId : '00000000-0000-0000-0000-000000000000']);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [editing, setEditing] = useState<Member | null>(null);
  const [error, setError] = useState('');
  return (
    <div className="flex flex-col gap-4">
      <Card title="Members" bodyClassName="p-0" actions={can('owner') && <Button variant="primary" onClick={() => setInviteOpen(true)}><Plus className="size-4" />Invite</Button>}>
        <Table>
          <thead><tr><Th>Person</Th><Th>Role</Th><Th className="text-right">Approval limit</Th><Th>Status</Th><Th /></tr></thead>
          <tbody>{lookups.members.map(m => (
            <tr key={m.user_id}>
              <Td><span className="font-medium">{m.display_name || m.email}</span><div className="text-xs text-slate-500">{m.email}{m.user_id === userId ? ' (you)' : ''}</div></Td>
              <Td>{ROLE_LABELS[m.role]}</Td>
              <Td className="text-right tabular-nums">{m.approval_limit ? fmtMoney(m.approval_limit) : 'No limit'}</Td>
              <Td>{m.active ? <Badge tone="green">Active</Badge> : <Badge>Deactivated</Badge>}</Td>
              <Td className="text-right">{can('owner') && <Button size="sm" variant="ghost" onClick={() => setEditing(m)}>Edit</Button>}</Td>
            </tr>
          ))}</tbody>
        </Table>
      </Card>
      {can('admin') && invites.length > 0 && (
        <Card title="Pending invitations" bodyClassName="p-0">
          <Table>
            <thead><tr><Th>Email</Th><Th>Role</Th><Th>Sent</Th><Th /></tr></thead>
            <tbody>{invites.map(i => (
              <tr key={i.id}><Td>{i.email}</Td><Td>{ROLE_LABELS[i.role]}</Td><Td className="text-xs">{fmtDateTime(i.created_at)}</Td>
                <Td className="text-right">{can('owner') && <Button size="sm" variant="ghost" onClick={async () => { setError(''); try { await rpc('revoke_invite', { p_invite: i.id }); } catch (e) { setError(errorText(e)); } }}>Revoke</Button>}</Td></tr>
            ))}</tbody>
          </Table>
          <p className="p-3 text-xs text-slate-500">Invitations are not emailed automatically. Tell the person to sign up at this app's address with that email; they join after verifying it.</p>
        </Card>
      )}
      <ErrorNote>{error}</ErrorNote>
      <Card title="What each role can do">
        <dl className="grid gap-2 text-sm sm:grid-cols-2">{(Object.keys(ROLE_HELP) as Role[]).map(r => <div key={r}><dt className="font-medium">{ROLE_LABELS[r]}</dt><dd className="text-slate-600">{ROLE_HELP[r]}</dd></div>)}</dl>
        <p className="mt-3 text-xs text-slate-500">Nobody, including the AI agent, can approve an invoice outside the approval steps. Approval limits apply to named approvers; invoices above a person's limit route to controllers.</p>
      </Card>
      <InviteDialog open={inviteOpen} onClose={() => setInviteOpen(false)} orgId={orgId} />
      <MemberDialog member={editing} onClose={() => setEditing(null)} orgId={orgId} />
    </div>
  );
}

function InviteDialog({ open, onClose, orgId }: { open: boolean; onClose: () => void; orgId: string }) {
  const [f, setF] = useState({ email: '', role: 'ap_clerk', limit: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { if (open) { setF({ email: '', role: 'ap_clerk', limit: '' }); setError(''); } }, [open]);
  return (
    <Modal open={open} title="Invite a person" onClose={onClose} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" busy={busy} disabled={!f.email.trim()} onClick={async () => {
      setBusy(true); setError('');
      try { await rpc('invite_member', { p_org: orgId, p_email: f.email, p_role: f.role, p_approval_limit: f.limit ? Number(f.limit) : null }); onClose(); } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
    }}>Invite</Button></>}>
      <Field label="Email"><Input aria-label="Invite email" type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} /></Field>
      <Field label="Role" hint={ROLE_HELP[f.role as Role]}><Select aria-label="Invite role" value={f.role} onChange={e => setF({ ...f, role: e.target.value })}>{Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
      <Field label="Approval limit (optional)" hint="Invoices above this total route to controllers instead."><Input aria-label="Approval limit" inputMode="decimal" value={f.limit} onChange={e => setF({ ...f, limit: e.target.value })} /></Field>
      <ErrorNote>{error}</ErrorNote>
    </Modal>
  );
}

function MemberDialog({ member, onClose, orgId }: { member: Member | null; onClose: () => void; orgId: string }) {
  const [f, setF] = useState({ role: 'viewer', limit: '', active: true });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { if (member) { setF({ role: member.role, limit: member.approval_limit ?? '', active: member.active }); setError(''); } }, [member]);
  return (
    <Modal open={!!member} title={`Edit ${member?.email ?? ''}`} onClose={onClose} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" busy={busy} onClick={async () => {
      setBusy(true); setError('');
      try { await rpc('update_member', { p_org: orgId, p_user: member!.user_id, p_role: f.role, p_approval_limit: f.limit === '' ? null : Number(f.limit), p_active: f.active }); onClose(); } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
    }}>Save</Button></>}>
      <Field label="Role"><Select aria-label="Member role" value={f.role} onChange={e => setF({ ...f, role: e.target.value })}>{Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select></Field>
      <Field label="Approval limit"><Input aria-label="Member approval limit" inputMode="decimal" placeholder="No limit" value={f.limit} onChange={e => setF({ ...f, limit: e.target.value })} /></Field>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.active} onChange={e => setF({ ...f, active: e.target.checked })} />Active</label>
      <ErrorNote>{error}</ErrorNote>
    </Modal>
  );
}

type Rule = { id: string; name: string; active: boolean; step_order: number; min_amount: string; approver_kind: 'project_manager' | 'user' | 'role'; approver_user_id: string | null; approver_role: string | null; vendor_id: string | null; project_id: string | null };

function Rules() {
  const { orgId, lookups, can, memberName } = useOrg();
  const { rows } = useRows<Rule>(queries.approvalRules, [orgId]);
  const [editing, setEditing] = useState<Partial<Rule> | null>(null);
  const describe = (r: Rule) => r.approver_kind === 'project_manager' ? "Each job's project manager" : r.approver_kind === 'user' ? memberName(r.approver_user_id) : `Any ${ROLE_LABELS[r.approver_role ?? ''] ?? r.approver_role}`;
  return (
    <div className="flex flex-col gap-4">
      <Notice>When an invoice is submitted, every active rule whose conditions match adds an approval step. Steps are approved in order. If a step has no eligible person (no PM on the job, the approver submitted the invoice, or the total exceeds their limit) it routes to controllers. If no rule matches, a controller must approve.</Notice>
      <Card title="Approval rules" bodyClassName="p-0" actions={can('admin') && <Button variant="primary" onClick={() => setEditing({ name: '', active: true, step_order: 1, min_amount: '0', approver_kind: 'project_manager' })}><Plus className="size-4" />Add rule</Button>}>
        <Table>
          <thead><tr><Th>Step</Th><Th>Rule</Th><Th>Applies when</Th><Th>Approver</Th><Th>Status</Th><Th /></tr></thead>
          <tbody>{rows.map(r => (
            <tr key={r.id}>
              <Td>{r.step_order}</Td><Td className="font-medium">{r.name}</Td>
              <Td className="text-xs">Total ≥ {fmtMoney(r.min_amount)}{r.vendor_id && ` · vendor ${lookups.vendors.find(v => v.id === r.vendor_id)?.name}`}{r.project_id && ` · job ${lookups.projects.find(p => p.id === r.project_id)?.code}`}</Td>
              <Td>{describe(r)}</Td>
              <Td>{r.active ? <Badge tone="green">Active</Badge> : <Badge>Off</Badge>}</Td>
              <Td className="text-right">{can('admin') && <Button size="sm" variant="ghost" onClick={() => setEditing(r)}>Edit</Button>}</Td>
            </tr>
          ))}</tbody>
        </Table>
      </Card>
      <RuleDialog rule={editing} onClose={() => setEditing(null)} orgId={orgId} />
    </div>
  );
}

function RuleDialog({ rule, onClose, orgId }: { rule: Partial<Rule> | null; onClose: () => void; orgId: string }) {
  const { lookups } = useOrg();
  const [f, setF] = useState<Partial<Rule>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { if (rule) { setF(rule); setError(''); } }, [rule]);
  const save = async () => {
    setBusy(true); setError('');
    try {
      if (!f.name?.trim()) throw new Error('Name is required');
      const v = {
        name: f.name.trim(), active: f.active ?? true, step_order: Number(f.step_order ?? 1), min_amount: Number(f.min_amount ?? 0), approver_kind: f.approver_kind,
        approver_user_id: f.approver_kind === 'user' ? f.approver_user_id || null : null, approver_role: f.approver_kind === 'role' ? f.approver_role || null : null,
        vendor_id: f.vendor_id || null, project_id: f.project_id || null,
      };
      if (f.id) await must(client.from('approval_rules').update(v).eq('id', f.id).select('id'));
      else await must(client.from('approval_rules').insert({ ...v, org_id: orgId }).select('id'));
      onClose();
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  return (
    <Modal open={!!rule} title={f.id ? 'Edit approval rule' : 'Add approval rule'} onClose={onClose} footer={<>
      {f.id && <Button variant="ghost" className="mr-auto text-red-700" onClick={async () => { try { await must(client.from('approval_rules').delete().eq('id', f.id!).select('id')); onClose(); } catch (e) { setError(errorText(e)); } }}>Delete</Button>}
      <Button onClick={onClose}>Cancel</Button><Button variant="primary" busy={busy} onClick={save}>Save</Button>
    </>}>
      <Field label="Name"><Input aria-label="Rule name" value={f.name ?? ''} onChange={e => setF({ ...f, name: e.target.value })} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Step order" hint="Lower steps approve first."><Input aria-label="Step order" inputMode="numeric" value={String(f.step_order ?? 1)} onChange={e => setF({ ...f, step_order: Number(e.target.value) || 1 })} /></Field>
        <Field label="Minimum invoice total"><Input aria-label="Minimum total" inputMode="decimal" value={String(f.min_amount ?? '0')} onChange={e => setF({ ...f, min_amount: e.target.value })} /></Field>
      </div>
      <Field label="Approver">
        <Select aria-label="Approver kind" value={f.approver_kind} onChange={e => setF({ ...f, approver_kind: e.target.value as Rule['approver_kind'] })}>
          <option value="project_manager">Project manager of each coded job</option><option value="role">Anyone with a role</option><option value="user">A named person</option>
        </Select>
      </Field>
      {f.approver_kind === 'role' && <Field label="Role"><Select aria-label="Approver role" value={f.approver_role ?? ''} onChange={e => setF({ ...f, approver_role: e.target.value })}><option value="">Choose…</option><option value="controller">Controller (or owner)</option><option value="owner">Owner</option><option value="ap_clerk">AP specialist</option><option value="project_manager">Any project manager</option></Select></Field>}
      {f.approver_kind === 'user' && <Field label="Person"><Select aria-label="Approver person" value={f.approver_user_id ?? ''} onChange={e => setF({ ...f, approver_user_id: e.target.value })}><option value="">Choose…</option>{lookups.members.filter(m => m.active && m.role !== 'viewer').map(m => <option key={m.user_id} value={m.user_id}>{m.display_name || m.email}</option>)}</Select></Field>}
      <div className="grid grid-cols-2 gap-3">
        <Field label="Only for vendor (optional)"><Select aria-label="Rule vendor" value={f.vendor_id ?? ''} onChange={e => setF({ ...f, vendor_id: e.target.value })}><option value="">Any vendor</option>{lookups.vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</Select></Field>
        <Field label="Only for job (optional)"><Select aria-label="Rule job" value={f.project_id ?? ''} onChange={e => setF({ ...f, project_id: e.target.value })}><option value="">Any job</option>{lookups.projects.map(p => <option key={p.id} value={p.id}>{p.code}</option>)}</Select></Field>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.active ?? true} onChange={e => setF({ ...f, active: e.target.checked })} />Active</label>
      <ErrorNote>{error}</ErrorNote>
    </Modal>
  );
}

function Controls() {
  const { lookups, can, orgId } = useOrg();
  const s = lookups.settings;
  const [f, setF] = useState<Record<string, string | boolean>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  useEffect(() => { if (s) setF({ ...Object.fromEntries(Object.entries(s).map(([k, v]) => [k, typeof v === 'boolean' ? v : String(v ?? '')])) }); }, [s]);
  if (!s) return null;
  const dis = !can('admin');
  const numField = (key: string, label: string, hint: string) => (
    <Field label={label} hint={hint}><Input aria-label={label} disabled={dis} inputMode="decimal" value={String(f[key] ?? '')} onChange={e => { setSaved(false); setF({ ...f, [key]: e.target.value }); }} /></Field>
  );
  const boolField = (key: string, label: string, hint: string) => (
    <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" disabled={dis} checked={Boolean(f[key])} onChange={e => { setSaved(false); setF({ ...f, [key]: e.target.checked }); }} /><span><span className="font-medium">{label}</span><span className="block text-xs text-slate-500">{hint}</span></span></label>
  );
  return (
    <Card title="Invoice controls" actions={!dis && <Button variant="primary" busy={busy} onClick={async () => {
      setBusy(true); setError('');
      try {
        await must(client.from('org_settings').update({
          variance_pct: Number(f.variance_pct), variance_amount: Number(f.variance_amount), require_po: Boolean(f.require_po), require_po_over_amount: Number(f.require_po_over_amount),
          possible_duplicate_days: Number(f.possible_duplicate_days), allow_self_approval: Boolean(f.allow_self_approval), low_confidence_threshold: Number(f.low_confidence_threshold),
          export_target: String(f.export_target || 'generic_csv'), ap_can_sync: Boolean(f.ap_can_sync), approval_reminder_hours: Number(f.approval_reminder_hours), updated_at: new Date().toISOString(),
        }).eq('org_id', orgId).select('org_id'));
        setSaved(true);
      } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
    }}>Save controls</Button>}>
      {dis && <p className="mb-3 text-xs text-slate-500">Only controllers and owners can change controls.</p>}
      <div className="grid gap-4 sm:grid-cols-2">
        {numField('variance_pct', 'Overbilling tolerance (%)', 'Billing above the revised commitment by more than this blocks the invoice.')}
        {numField('variance_amount', 'Overbilling tolerance ($)', 'The smaller of the % and $ tolerance applies.')}
        {numField('require_po_over_amount', 'Require a commitment above ($)', 'Used when “Require commitment” is on.')}
        {numField('possible_duplicate_days', 'Possible duplicate window (days)', 'Same vendor and amount within this many days is flagged for review.')}
        {numField('low_confidence_threshold', 'Low-confidence threshold (0–1)', 'AI fields below this confidence must be confirmed by a person before submitting.')}
        {numField('approval_reminder_hours', 'Approval overdue after (hours)', 'Highlights slow approvals on the Overview. Reminder emails are not sent yet.')}
        <Field label="Export target label" hint="Written on every export batch, e.g. sage300_cre, vista, qbo."><Input aria-label="Export target" disabled={dis} value={String(f.export_target ?? '')} onChange={e => setF({ ...f, export_target: e.target.value })} /></Field>
        <div className="flex flex-col gap-3">
          {boolField('require_po', 'Require commitment', 'Invoices above the amount without a PO or subcontract are blocked.')}
          {boolField('allow_self_approval', 'Allow people to approve invoices they submitted', 'Off by default to keep separation of duties.')}
          {boolField('ap_can_sync', 'Allow AP specialists to export to accounting', 'Off: only controllers and owners export.')}
        </div>
      </div>
      <ErrorNote>{error}</ErrorNote>
      {saved && <p className="mt-2 text-sm text-emerald-700">Saved. New checks use these values; re-run checks on open invoices to apply them.</p>}
    </Card>
  );
}

function Company() {
  const { lookups, can, orgId } = useOrg();
  const [name, setName] = useState(lookups.org?.name ?? '');
  const [entity, setEntity] = useState(lookups.org?.legal_entity ?? '');
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  return (
    <Card title="Company">
      <div className="grid max-w-lg gap-3">
        <Field label="Company name"><Input aria-label="Company name" disabled={!can('owner')} value={name} onChange={e => setName(e.target.value)} /></Field>
        <Field label="Legal entity"><Input aria-label="Legal entity" disabled={!can('owner')} value={entity} onChange={e => setEntity(e.target.value)} /></Field>
        {can('owner') && <Button variant="primary" className="w-fit" onClick={async () => {
          setError(''); setSaved(false);
          try { await must(client.from('orgs').update({ name: name.trim(), legal_entity: entity.trim() || null }).eq('id', orgId).select('id')); setSaved(true); } catch (e) { setError(errorText(e)); }
        }}>Save</Button>}
        <ErrorNote>{error}</ErrorNote>
        {saved && <p className="text-sm text-emerald-700">Saved.</p>}
        <div className="mt-4 text-xs text-slate-500">
          <p className="font-medium text-slate-700">Data and security</p>
          <p>Each company's records are isolated by database row-level security; members only see companies they belong to. The app holds no accounting-system credentials. No security certification (e.g. SOC 2) has been obtained for this application.</p>
        </div>
      </div>
    </Card>
  );
}
