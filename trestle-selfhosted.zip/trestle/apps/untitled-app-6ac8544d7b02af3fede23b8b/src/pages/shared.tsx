import { Component, lazy, Suspense, useEffect, useState, type ReactNode } from 'react';
import { ExternalLink } from 'lucide-react';
import { uploadUrl } from '../uploads';
import { Badge, Loading } from '../components/ui';
import { STATUS_LABELS, SYNC_LABELS, errorText } from '../lib/api';

export function InvoiceStatusBadge({ status }: { status: string }) {
  const tone = ({ needs_review: 'blue', pending_approval: 'amber', approved: 'green', rejected: 'red', void: 'gray' } as const)[status as 'void'] ?? 'gray';
  return <Badge tone={tone}>{STATUS_LABELS[status] ?? status}</Badge>;
}

export function ExtractionBadge({ status }: { status: string }) {
  if (status === 'pending') return <Badge tone="violet">AI queued</Badge>;
  if (status === 'running') return <Badge tone="violet">AI reading…</Badge>;
  if (status === 'failed') return <Badge tone="red">AI could not read</Badge>;
  return null;
}

export function SyncBadge({ status }: { status: string }) {
  const tone = ({ not_ready: 'gray', ready: 'blue', exported: 'amber', synced: 'green', failed: 'red' } as const)[status as 'ready'] ?? 'gray';
  return <Badge tone={tone}>{SYNC_LABELS[status] ?? status}</Badge>;
}

export function SeverityBadge({ severity }: { severity: string }) {
  if (severity === 'blocking') return <Badge tone="red">Blocking</Badge>;
  if (severity === 'warning') return <Badge tone="amber">Check</Badge>;
  return <Badge>Info</Badge>;
}

export function ConfidencePill({ value, threshold }: { value: number | undefined; threshold: number }) {
  if (value === undefined || value === null) return null;
  if (value >= 0.999) return <Badge tone="green" title="Confirmed or entered by a person">Verified</Badge>;
  const pct = Math.round(value * 100);
  return <Badge tone={value < threshold ? 'amber' : 'gray'} title="AI extraction confidence">AI {pct}%</Badge>;
}

const PdfViewer = lazy(() => import('../components/pdf-viewer'));
class PdfBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? <p className="p-4 text-sm text-amber-800">Preview unavailable. Use Open original above to view or download this file.</p> : this.props.children; }
}

/** Shows the original invoice file next to the extracted data. */
export function DocumentViewer({ uploadId, fileName }: { uploadId: string | null; fileName: string | null }) {
  const [url, setUrl] = useState<string | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    setUrl(null); setError('');
    if (!uploadId) return;
    let active = true;
    uploadUrl(uploadId).then(value => { if (active) setUrl(value); }).catch(e => { if (active) setError(errorText(e)); });
    return () => { active = false; };
  }, [uploadId]);
  if (!uploadId) return <div className="flex h-full min-h-60 items-center justify-center rounded-lg border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">Manual entry: no source document attached.</div>;
  if (error) return <p className="text-sm text-red-700">Could not load the document: {error}</p>;
  if (!url) return <Loading label="Loading document…" />;
  const isImage = /\.(png|jpe?g|gif|webp|bmp|heic)$/i.test(fileName ?? '');
  return (
    <div className="flex h-full flex-col gap-2">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span className="truncate">{fileName}</span>
        <a href={url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-slate-800">Open original <ExternalLink className="size-3" /></a>
      </div>
      {isImage
        ? <div className="flex-1 overflow-auto rounded border border-slate-200 bg-slate-100"><img src={url} alt={fileName ?? 'Invoice'} className="w-full" /></div>
        : <PdfBoundary key={uploadId}><Suspense fallback={<Loading label="Loading PDF viewer…" />}><PdfViewer url={url} /></Suspense></PdfBoundary>}
    </div>
  );
}

export function Phase3({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-6">
      <div className="flex items-center gap-2"><Badge tone="violet">Planned · not built yet</Badge><h2 className="font-semibold text-slate-900">{title}</h2></div>
      <div className="mt-3 max-w-2xl space-y-2 text-sm text-slate-600">{children}</div>
    </div>
  );
}
