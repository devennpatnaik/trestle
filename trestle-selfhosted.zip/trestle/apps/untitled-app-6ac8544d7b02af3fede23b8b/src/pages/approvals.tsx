import { useState } from 'react';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg, go } from '../org';
import { ago, errorText, fmtMoney, rpc } from '../lib/api';
import { Badge, Button, Card, Empty, ErrorNote, Loading, PageHeader, Table, Tabs, Td, Th } from '../components/ui';

type Row = {
  step_id: string; invoice_id: string; invoice_number: string | null; vendor: string | null; total_amount: string | null; currency: string;
  step_order: number; approver_user_id: string | null; approver_role: string | null; reason: string; submitted_at: string; submitted_by: string | null;
  projects: string | null; warnings: number; overridden: number; is_next: boolean;
};

const SQL = queries.approvalQueue;

export default function Approvals() {
  const { orgId, userId, role, memberName, lookups } = useOrg();
  const { rows, loading } = useRows<Row>(SQL, [orgId]);
  const [tab, setTab] = useState<'mine' | 'all'>('mine');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const mine = rows.filter(r => r.is_next && (r.approver_user_id === userId || (!r.approver_user_id && (r.approver_role === role || (r.approver_role === 'controller' && role === 'owner')))));
  const shown = tab === 'mine' ? mine : rows;
  const selfBlocked = (r: Row) => !lookups.settings?.allow_self_approval && r.submitted_by === userId;
  const approve = async (r: Row) => {
    setBusy(r.step_id); setError('');
    try { await rpc('decide_invoice', { p_invoice: r.invoice_id, p_decision: 'approve', p_comment: null }); } catch (e) { setError(errorText(e)); } finally { setBusy(''); }
  };
  return (
    <div>
      <PageHeader title="Approvals" subtitle="Invoices routed to you by your approval rules. Approving records your name, time and the exact coding approved." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'mine', label: `Waiting on me (${mine.length})` }, ...(role !== 'project_manager' ? [{ id: 'all' as const, label: `All pending (${rows.length})` }] : [])]} />
      <ErrorNote>{error}</ErrorNote>
      <Card bodyClassName="p-0">
        {loading ? <div className="px-4"><Loading /></div> : shown.length === 0 ? <div className="p-4"><Empty title={tab === 'mine' ? 'Nothing waiting on you' : 'No invoices awaiting approval'} /></div> : (
          <Table>
            <thead><tr><Th>Invoice</Th><Th>Vendor</Th><Th>Job</Th><Th className="text-right">Total</Th><Th>Step</Th><Th>Waiting</Th><Th /></tr></thead>
            <tbody>{shown.map(r => {
              const isMine = mine.includes(r);
              return (
                <tr key={r.step_id} className="hover:bg-slate-50">
                  <Td><a href={`#/invoices/${r.invoice_id}`} className="font-medium hover:underline">{r.invoice_number ?? '—'}</a>
                    <div className="mt-1 flex gap-1">{r.overridden > 0 && <Badge tone="red">{r.overridden} overridden</Badge>}{r.warnings > 0 && <Badge tone="amber">{r.warnings} warning{r.warnings > 1 ? 's' : ''}</Badge>}</div></Td>
                  <Td>{r.vendor}</Td><Td>{r.projects ?? '—'}</Td>
                  <Td className="text-right tabular-nums">{fmtMoney(r.total_amount, r.currency)}</Td>
                  <Td className="text-xs"><span className="font-medium">{r.approver_user_id ? memberName(r.approver_user_id) : `Any ${r.approver_role}`}</span>{!r.is_next && <Badge className="ml-1">later step</Badge>}<div className="text-slate-500">{r.reason}</div></Td>
                  <Td className="whitespace-nowrap text-xs">{ago(r.submitted_at)}</Td>
                  <Td className="whitespace-nowrap text-right">
                    <Button size="sm" onClick={() => go(`invoices/${r.invoice_id}`)}>Review</Button>{' '}
                    {isMine && <Button size="sm" variant="success" busy={busy === r.step_id} disabled={selfBlocked(r)} title={selfBlocked(r) ? 'You submitted this invoice' : undefined} onClick={() => approve(r)}>Approve</Button>}
                  </Td>
                </tr>
              );
            })}</tbody>
          </Table>
        )}
      </Card>
      <p className="mt-3 text-xs text-slate-500">To reject, open the invoice: a reason is required and goes back to AP. Reminder emails for overdue approvals are not sent yet; the Overview shows how long the oldest invoice has waited.</p>
    </div>
  );
}
