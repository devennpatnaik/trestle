import { useState } from 'react';
import { client } from '../client';
import { useRows } from '../db';
import { queries } from '@project/queries';
import { useOrg } from '../org';
import { downloadText, must, toCsv } from '../lib/api';
import { Badge, Button, Card, PageHeader, Table, Tabs, Td, Th } from '../components/ui';
import { CsvImport, req, type Mapped } from '../components/csv-import';
import { EntityManager } from '../components/entity';
import { Phase3 } from './shared';

type VendorRow = { code: string; name: string; tax_id: string | null; email: string | null; phone: string | null; address: string | null; payment_terms: string | null; status: string; external_id: string | null };

export default function Vendors() {
  const { lookups, orgId, can } = useOrg();
  const [tab, setTab] = useState<'vendors' | 'aliases' | 'compliance'>('vendors');
  const ctOptions = lookups.cost_types.map(t => ({ value: t.id, label: `${t.code} · ${t.name}` }));
  const glOptions = lookups.gl_accounts.map(g => ({ value: g.id, label: `${g.code} · ${g.name}` }));

  const mapRow = (r: Record<string, string>): Mapped<VendorRow> => {
    const code = req(r, 'code') ?? req(r, 'vendor_code') ?? req(r, 'vendor_id');
    const name = req(r, 'name') ?? req(r, 'vendor_name');
    if (!code) return { ok: false, error: 'code is empty' };
    if (!name) return { ok: false, error: 'name is empty' };
    const status = (req(r, 'status') ?? 'active').toLowerCase();
    if (!['active', 'inactive'].includes(status)) return { ok: false, error: `status must be active or inactive, got "${status}"` };
    return { ok: true, value: { code, name, tax_id: req(r, 'tax_id'), email: req(r, 'email'), phone: req(r, 'phone'), address: req(r, 'address'), payment_terms: req(r, 'payment_terms'), status, external_id: req(r, 'external_id') } };
  };

  return (
    <div>
      <PageHeader title="Vendors & compliance" subtitle="The vendor list the AI matches invoices against. Keep codes identical to your accounting system so exports post cleanly." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'vendors', label: 'Vendors' }, { id: 'aliases', label: 'Learned name variants' }, { id: 'compliance', label: 'Compliance' }]} />
      {tab === 'vendors' && (
        <EntityManager title="Vendors" table="vendors" orgId={orgId} rows={lookups.vendors} canEdit={can('ap')} searchKeys={['code', 'name', 'tax_id', 'email']}
          defaults={{ status: 'active' }}
          emptyHint="Import your vendor list from your accounting system as CSV, or add vendors one by one."
          toolbar={<>
            <Button onClick={() => downloadText('vendors.csv', toCsv(lookups.vendors.map(v => ({ code: v.code, name: v.name, tax_id: v.tax_id, email: v.email, phone: v.phone, address: v.address, payment_terms: v.payment_terms, status: v.status, external_id: v.external_id }))))} disabled={!lookups.vendors.length}>Export CSV</Button>
            <CsvImport title="Import vendors" disabled={!can('ap')} mapRow={mapRow}
              columns={[{ name: 'code', required: true, example: 'V-1001', hint: 'Vendor ID in your accounting system' }, { name: 'name', required: true, example: 'Ready Mix Supply Co' }, { name: 'tax_id', example: '12-3456789' }, { name: 'email' }, { name: 'phone' }, { name: 'address' }, { name: 'payment_terms', example: 'Net 30' }, { name: 'status', example: 'active' }, { name: 'external_id' }]}
              onImport={async rows => {
                for (let i = 0; i < rows.length; i += 200) await must(client.from('vendors').upsert(rows.slice(i, i + 200).map(r => ({ ...r, org_id: orgId })), { onConflict: 'org_id,code' }).select('id'));
                return `Imported ${rows.length} vendors (new codes added, existing codes updated).`;
              }} />
          </>}
          fields={[
            { key: 'code', label: 'Code', required: true },
            { key: 'name', label: 'Name', required: true },
            { key: 'status', label: 'Status', kind: 'select', required: true, options: [{ value: 'active', label: 'Active' }, { value: 'inactive', label: 'Inactive' }], render: r => <Badge tone={r.status === 'active' ? 'green' : 'gray'}>{String(r.status)}</Badge> },
            { key: 'tax_id', label: 'Tax ID', inList: false },
            { key: 'payment_terms', label: 'Terms' },
            { key: 'email', label: 'Email', inList: false },
            { key: 'phone', label: 'Phone', inList: false },
            { key: 'address', label: 'Address', inList: false, wide: true },
            { key: 'default_cost_type_id', label: 'Default cost type', kind: 'select', options: ctOptions, inList: false, hint: 'Used by the AI as a coding hint.' },
            { key: 'default_gl_account_id', label: 'Default GL account', kind: 'select', options: glOptions, inList: false },
            { key: 'external_id', label: 'External ID', inList: false, hint: 'ID in your ERP, if different from the code.' },
          ]} />
      )}
      {tab === 'aliases' && <Aliases />}
      {tab === 'compliance' && (
        <Phase3 title="Vendor compliance (COIs, W-9s, lien waivers)">
          <p>Tracking certificates of insurance, W-9s, licenses and conditional/unconditional lien waivers, and blocking payment when they are missing or expired, is planned for a later phase. It is not built, so nothing here checks compliance today.</p>
          <p>Until then, keep compliance in your current system. Setting a vendor to <strong>inactive</strong> makes every new invoice from it raise a blocking exception.</p>
        </Phase3>
      )}
    </div>
  );
}

function Aliases() {
  const { orgId, lookups, can } = useOrg();
  const { rows } = useRows<{ id: string; alias: string; vendor_id: string; learned_from_invoice_id: string | null; created_at: string }>(
    queries.vendorAliases, [orgId]);
  return (
    <Card title="Learned vendor name variants" bodyClassName="p-0">
      <p className="px-4 pt-3 text-sm text-slate-500">When a person matches an invoice's printed vendor name to a vendor, the name is remembered so the next invoice matches automatically.</p>
      <Table className="mt-2">
        <thead><tr><Th>Name on invoices</Th><Th>Vendor</Th><Th>Learned from</Th><Th /></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><Td colSpan={4} className="text-slate-500">None yet.</Td></tr>}
          {rows.map(a => (
            <tr key={a.id}>
              <Td>{a.alias}</Td><Td>{lookups.vendors.find(v => v.id === a.vendor_id)?.name ?? '—'}</Td>
              <Td>{a.learned_from_invoice_id ? <a className="underline" href={`#/invoices/${a.learned_from_invoice_id}`}>invoice</a> : 'manual'}</Td>
              <Td className="text-right">{can('ap') && <Button size="sm" variant="ghost" onClick={() => void client.from('vendor_aliases').delete().eq('id', a.id)}>Forget</Button>}</Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Card>
  );
}
