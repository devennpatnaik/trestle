import { client } from '../client';

/** Calls a database workflow function; throws with the database's own message on refusal. */
export async function rpc<T = unknown>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await client.rpc(fn, args);
  if (error) throw new Error(cleanError(error.message));
  return data as T;
}

/** Runs a table write and throws a readable error. */
export async function must<T>(promise: PromiseLike<{ data: T; error: { message: string } | null }>): Promise<T> {
  const { data, error } = await promise;
  if (error) throw new Error(cleanError(error.message));
  return data;
}

export function cleanError(message: string): string {
  if (/^No record was changed/i.test(message)) return message;
  if (/row-level security/i.test(message)) return 'Your role does not allow this change.';
  if (/duplicate key value.*_org_id_code_key|_org_id_number_key/i.test(message)) return 'That code or number is already in use.';
  if (/duplicate key/i.test(message)) return 'A record with the same key already exists.';
  if (/violates foreign key/i.test(message)) return 'This record is referenced elsewhere, or refers to a record that does not exist.';
  return message;
}

export function errorText(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

const money = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
export function fmtMoney(v: number | string | null | undefined, currency = 'USD'): string {
  if (v === null || v === undefined || v === '') return '—';
  const n = Number(v);
  if (Number.isNaN(n)) return '—';
  if (currency !== 'USD') return `${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${currency}`;
  return money.format(n);
}

export function fmtDate(v: string | null | undefined): string {
  if (!v) return '—';
  const d = v.length === 10 ? new Date(`${v}T00:00:00`) : new Date(v);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function fmtDateTime(v: string | null | undefined): string {
  if (!v) return '—';
  const d = new Date(v);
  return d.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

export function ago(v: string | null | undefined): string {
  if (!v) return '—';
  const s = (Date.now() - new Date(v).getTime()) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export const num = (v: unknown): number => (v === null || v === undefined || v === '' ? 0 : Number(v));
export const round2 = (n: number): number => Math.round(n * 100) / 100;

// ------------------------------------------------------------------ CSV
export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  const src = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (quoted) {
      if (c === '"' && src[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') quoted = false;
      else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some(x => x.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some(x => x.trim() !== '')) rows.push(row);
  if (rows.length === 0) return [];
  const header = rows[0].map(h => h.trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, ''));
  return rows.slice(1).map(r => Object.fromEntries(header.map((h, i) => [h, (r[i] ?? '').trim()])));
}

function csvCell(v: unknown): string {
  if (v === null || v === undefined) return '';
  const raw = String(v);
  const s = typeof v === 'string' && /^[=+@\t\r]|^-(?!\d+(?:\.\d+)?$)/.test(raw) ? `'${raw}` : raw;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function toCsv(rows: Record<string, unknown>[], columns?: string[]): string {
  const cols = columns ?? (rows[0] ? Object.keys(rows[0]) : []);
  return [cols.join(','), ...rows.map(r => cols.map(c => csvCell(r[c])).join(','))].join('\r\n') + '\r\n';
}

export function downloadText(filename: string, text: string, mime = 'text/csv') {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function readFileText(file: File): Promise<string> {
  return await file.text();
}

export const ROLE_LABELS: Record<string, string> = {
  owner: 'Owner',
  controller: 'Controller',
  ap_clerk: 'AP specialist',
  project_manager: 'Project manager',
  viewer: 'Viewer',
};

export const STATUS_LABELS: Record<string, string> = {
  needs_review: 'In review',
  pending_approval: 'Awaiting approval',
  approved: 'Approved',
  rejected: 'Rejected',
  void: 'Void',
};

export const SYNC_LABELS: Record<string, string> = {
  not_ready: 'Not ready',
  ready: 'Ready to export',
  exported: 'Exported, awaiting confirmation',
  synced: 'Posted in accounting',
  failed: 'Sync failed',
};
