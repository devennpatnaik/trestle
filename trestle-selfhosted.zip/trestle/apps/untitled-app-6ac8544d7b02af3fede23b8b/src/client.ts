import { useEffect, useRef } from 'react';
import { createClient } from '@neondatabase/neon-js';
import { BetterAuthReactAdapter } from '@neondatabase/neon-js/auth/react/adapters';
import { SELFHOST, createSelfhostClient } from './selfhost';

const hostedClient = () => createClient({
  // Sign-in is served by the project backend's Better Auth (backend/routes/auth.ts).
  auth: { url: `${String(import.meta.env.VITE_BOURNE_BACKEND_URL ?? '').replace(/\/$/, '')}/api/auth`, adapter: BetterAuthReactAdapter() },
  // Writes and workflow RPCs go through the project backend, which forwards them to the Neon Data API with the
  // user's own token (backend/routes/data-api.ts).
  dataApi: { url: `${String(import.meta.env.VITE_BOURNE_BACKEND_URL ?? '').replace(/\/$/, '')}/data/api` },
});

/** Hosted builds use Neon Auth and the Data API; the self-hosted package swaps in its local server (selfhost.ts). */
export const client: ReturnType<typeof hostedClient> = SELFHOST
  ? (createSelfhostClient() as unknown as ReturnType<typeof hostedClient>)
  : hostedClient();

/**
 * The signed-in session, pending only until its first read resolves. The
 * client.auth.useSession underneath turns isPending back on for every refetch
 * while there is no session — a window refocus, a reconnect, a sign-in in
 * another tab — so a screen gated on it unmounts and loses its state on each
 * one. Gate session-dependent renders on this hook instead.
 */
export function useSession() {
  const session = client.auth.useSession();
  const resolved = useRef(false);

  useEffect(() => {
    if (!session.isPending) resolved.current = true;
  }, [session.isPending]);

  return { ...session, isPending: session.isPending && !resolved.current };
}
