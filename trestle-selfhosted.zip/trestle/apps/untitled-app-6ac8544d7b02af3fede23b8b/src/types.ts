import type { Database } from '@project/database';

export type Role = 'owner' | 'controller' | 'ap_clerk' | 'project_manager' | 'viewer';

export type Membership = { org_id: string; role: Role; approval_limit: string | null; name: string; is_demo: boolean };

export type Vendor = Pick<Database['public']['Tables']['vendors']['Row'], 'id' | 'code' | 'name' | 'status' | 'tax_id' | 'email' | 'phone' | 'address' | 'payment_terms' | 'default_gl_account_id' | 'default_cost_type_id' | 'external_id'>;
export type Project = { id: string; code: string; name: string; status: string; project_manager_user_id: string | null; legal_entity: string | null; address: string | null; external_id: string | null };
export type CostCode = { id: string; code: string; name: string; project_id: string | null; budget_amount: string | null };
export type CostType = { id: string; code: string; name: string };
export type GlAccount = { id: string; code: string; name: string; account_type: string; active: boolean };
export type Member = { user_id: string; email: string; display_name: string; role: Role; approval_limit: string | null; active: boolean };
export type Commitment = { id: string; kind: 'purchase_order' | 'subcontract'; number: string; vendor_id: string; project_id: string; description: string | null; status: string; original_amount: string; retainage_pct: string; external_id: string | null };
export type Settings = {
  org_id: string; variance_pct: string; variance_amount: string; require_po: boolean; require_po_over_amount: string;
  possible_duplicate_days: number; allow_self_approval: boolean; low_confidence_threshold: string; export_target: string;
  ap_can_sync: boolean; approval_reminder_hours: number;
};

export type Lookups = {
  vendors: Vendor[];
  projects: Project[];
  cost_codes: CostCode[];
  cost_types: CostType[];
  gl_accounts: GlAccount[];
  members: Member[];
  commitments: Commitment[];
  settings: Settings | null;
  org: { id: string; name: string; legal_entity: string | null; is_demo: boolean } | null;
};

export type Invoice = {
  id: string; org_id: string; source: string; upload_id: string | null; file_name: string | null;
  status: 'needs_review' | 'pending_approval' | 'approved' | 'rejected' | 'void';
  extraction_status: 'pending' | 'running' | 'succeeded' | 'failed' | 'manual';
  sync_status: 'not_ready' | 'ready' | 'exported' | 'synced' | 'failed';
  vendor_id: string | null; vendor_name_extracted: string | null; invoice_number: string | null;
  invoice_date: string | null; due_date: string | null; payment_terms: string | null; currency: string;
  subtotal: string | null; tax_amount: string | null; retainage_amount: string | null; total_amount: string | null;
  po_number: string | null; commitment_id: string | null; project_reference: string | null; description: string | null;
  field_confidence: Record<string, number>; ai_extraction: Record<string, unknown> | null; ai_summary: string | null;
  extraction_error: string | null; extraction_started_at: string | null; agent_session_id: string | null;
  approval_round: number; submitted_by: string | null; submitted_at: string | null; approved_at: string | null;
  rejected_reason: string | null; created_by: string; created_at: string; updated_at: string;
};

export type Allocation = {
  id: string; invoice_id: string; project_id: string | null; cost_code_id: string | null; cost_type_id: string | null;
  gl_account_id: string | null; commitment_line_id: string | null; amount: string; description: string | null;
  source: 'ai' | 'user' | 'rule'; confidence: string | null; rationale: string | null; created_at: string;
};

export type InvoiceException = {
  id: string; invoice_id: string; code: string; severity: 'blocking' | 'warning' | 'info'; overridable: boolean;
  title: string; detail: string; evidence: Record<string, unknown>; resolver: string;
  status: 'open' | 'resolved' | 'overridden' | 'acknowledged'; resolution_note: string | null; resolved_by: string | null; resolved_at: string | null;
};

export type ApprovalStep = {
  id: string; invoice_id: string; round: number; step_order: number; approver_user_id: string | null; approver_role: string | null;
  reason: string; status: 'pending' | 'approved' | 'rejected' | 'skipped'; decided_by: string | null; decided_at: string | null; comment: string | null; created_at: string;
};

export type AuditEvent = { id: number; entity_type: string; entity_id: string | null; invoice_id: string | null; action: string; actor_user_id: string | null; actor_kind: 'user' | 'agent' | 'system'; summary: string; details: Record<string, unknown>; created_at: string };

export type AgentRun = { id: string; agent: string; kind: 'ai' | 'rules'; invoice_id: string | null; status: string; summary: string | null; input: Record<string, unknown>; output: Record<string, unknown>; error: string | null; triggered_by: string | null; started_at: string; finished_at: string | null };
