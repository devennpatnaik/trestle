import { useEffect, useState, useSyncExternalStore } from 'react';
import { authHeaders, backendUrl, sleep } from './runtime';
import { client } from './client';

/**
 * App reads. Every SELECT lives in @project/queries; the backend's /data/query runs it as the signed-in user, so
 * row level security decides the rows. One WebSocket on the backend's /live says which tables changed; each live
 * read reloads when a table its SQL names changes, after every reconnect, and on a slow poll while the socket is down.
 */

const RECONNECT_MIN_MS = 1000;
const RECONNECT_MAX_MS = 30_000;
const POLL_WHILE_DOWN_MS = 15_000;

/** Runs one approved read and returns its rows. */
export async function query<T = Record<string, unknown>>(sql: string, params: unknown[] = []): Promise<T[]> {
  const response = await fetch(backendUrl('/data/query'), {
    method: 'POST',
    headers: { ...(await authHeaders()), 'Content-Type': 'application/json' },
    body: JSON.stringify({ sql, params }),
  });
  const body = (await response.json().catch(() => null)) as { rows?: T[]; error?: string } | null;
  if (!response.ok) throw new Error(body?.error ?? `The read failed (status ${response.status})`);
  return body?.rows ?? [];
}

type Subscriber = { words: Set<string>; reload: () => void };
const subscribers = new Set<Subscriber>();
const failures = new Map<Subscriber, string>();
const healthListeners = new Set<() => void>();
let connectionNotice = '';
const notifyHealth = () => healthListeners.forEach(fn => fn());
const healthSnapshot = () => failures.values().next().value ? `Could not refresh data: ${failures.values().next().value}` : connectionNotice;
export const useDataHealth = () => useSyncExternalStore(fn => { healthListeners.add(fn); return () => { healthListeners.delete(fn); }; }, healthSnapshot);
export const refreshData = () => { reloadAll(); void connect(); };
let socket: WebSocket | null = null;
let socketUp = false;
let connecting = false;
let reconnectMs = RECONNECT_MIN_MS;
let pollTimer: ReturnType<typeof setInterval> | null = null;

const reloadAll = () => subscribers.forEach(s => s.reload());

function startPolling() {
  pollTimer ??= setInterval(reloadAll, POLL_WHILE_DOWN_MS);
}
function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

async function connect() {
  if (socket || connecting || !subscribers.size) return;
  connecting = true;
  try {
    const { data } = await client.auth.getSession();
    const token = data?.session?.token;
    if (!token) throw new Error('Sign in first');
    const url = new URL(backendUrl('/live'));
    url.protocol = url.protocol === 'http:' ? 'ws:' : 'wss:';
    url.searchParams.set('token', token);
    if (!subscribers.size || socket) return;
    const ws = new WebSocket(url);
    socket = ws;
    let lastFrame = Date.now();
    const watchdog = setInterval(() => { if (Date.now() - lastFrame > 60_000) ws.close(); }, 15_000);
    ws.onmessage = event => {
      lastFrame = Date.now();
      let message: { type?: string; tables?: string[] };
      try {
        message = JSON.parse(String(event.data));
      } catch {
        return;
      }
      if (message.type === 'ready') {
        const wasDown = !socketUp;
        socketUp = true;
        reconnectMs = RECONNECT_MIN_MS;
        stopPolling();
        connectionNotice = ''; notifyHealth();
        if (wasDown) reloadAll();
      } else if (message.type === 'changes' && message.tables) {
        const changed = message.tables.map(t => t.toLowerCase());
        subscribers.forEach(s => {
          if (changed.some(t => s.words.has(t))) s.reload();
        });
      }
    };
    ws.onclose = () => {
      clearInterval(watchdog);
      if (socket !== ws) return;
      socket = null;
      socketUp = false;
      scheduleReconnect();
    };
  } catch {
    socket = null;
    scheduleReconnect();
  } finally {
    connecting = false;
  }
}

function scheduleReconnect() {
  if (!subscribers.size) return;
  startPolling();
  connectionNotice = 'Live updates are reconnecting. Data refreshes every 15 seconds meanwhile.'; notifyHealth();
  const delay = reconnectMs;
  reconnectMs = Math.min(reconnectMs * 2, RECONNECT_MAX_MS);
  void sleep(delay).then(connect);
}

function disconnectIfIdle() {
  if (subscribers.size) return;
  stopPolling();
  const ws = socket;
  socket = null;
  socketUp = false;
  ws?.close();
}

/**
 * Keeps one approved SELECT live: onRows gets the current rows, then fresh rows whenever a table named in the SQL
 * changes. A burst of changes runs at most one more load after the one in flight. Returns an unsubscribe function.
 */
export function subscribe<T = Record<string, unknown>>(
  sql: string,
  params: unknown[],
  onRows: (rows: T[]) => void,
  onError?: (message: string) => void,
): () => void {
  let closed = false;
  let running = false;
  let again = false;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;

  const load = async () => {
    if (closed) return;
    if (running) {
      again = true;
      return;
    }
    running = true;
    try {
      do {
        again = false;
        try {
          const rows = await query<T>(sql, params);
          if (!closed) { failures.delete(subscriber); notifyHealth(); onRows(rows); }
        } catch (cause) {
          if (!closed) {
            const message = cause instanceof Error ? cause.message : String(cause);
            failures.set(subscriber, message); notifyHealth(); onError?.(message);
            if (!retryTimer) retryTimer = setTimeout(() => { retryTimer = null; void load(); }, 5000);
          }
        }
      } while (again && !closed);
    } finally {
      running = false;
    }
  };

  const subscriber: Subscriber = { words: new Set(sql.toLowerCase().match(/[a-z_][a-z0-9_]*/g) ?? []), reload: () => void load() };
  subscribers.add(subscriber);
  if (!socketUp) startPolling();
  void load();
  void connect();

  return () => {
    closed = true;
    subscribers.delete(subscriber);
    if (retryTimer) clearTimeout(retryTimer);
    failures.delete(subscriber); notifyHealth();
    disconnectIfIdle();
  };
}

export type LiveRows<T> = { rows: T[]; loading: boolean; error: string | null };

/**
 * One approved SELECT kept live for a component: the rows the signed-in user may see, refreshed whenever a table
 * it reads changes, whoever wrote it. Changing sql or params re-subscribes, and unmounting unsubscribes. The error
 * is set while the read fails and clears when rows arrive again.
 */
export function useRows<T = Record<string, unknown>>(sql: string, params: unknown[] = []): LiveRows<T> {
  const [state, setState] = useState<LiveRows<T>>({ rows: [], loading: true, error: null });
  const paramsKey = JSON.stringify(params);

  useEffect(() => {
    setState({ rows: [], loading: true, error: null });
    return subscribe<T>(
      sql,
      JSON.parse(paramsKey) as unknown[],
      rows => setState({ rows, loading: false, error: null }),
      error => setState(prev => ({ ...prev, loading: false, error })),
    );
  }, [sql, paramsKey]);

  return state;
}

if (typeof window !== 'undefined') {
  window.addEventListener('online', refreshData);
  window.addEventListener('focus', refreshData);
}
