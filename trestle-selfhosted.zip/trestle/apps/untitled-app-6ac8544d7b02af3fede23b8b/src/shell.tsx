import { lazy, Suspense, useState, type ReactNode } from 'react';
import { BarChart3, Bot, Building2, CheckSquare, FileText, FolderKanban, HardHat, LayoutDashboard, LogOut, Menu, Plug, Receipt, Settings, Sparkles, X } from 'lucide-react';
import { client } from './client';
import { useRows } from './db';
import { DataHealth } from './components/data-health';
import { AiStatus } from './components/ai-status';
import { CompanyActions } from './components/company-actions';
import { queries } from '@project/queries';
import { useOrg, useRoute } from './org';
import { cn } from './lib/utils';
import { Badge, Loading, LiveError } from './components/ui';
import { IntakeDispatcher } from './intake';
import { ROLE_LABELS } from './lib/api';

const Overview = lazy(() => import('./pages/overview'));
const Invoices = lazy(() => import('./pages/invoices'));
const InvoiceReview = lazy(() => import('./pages/invoice-review'));
const Approvals = lazy(() => import('./pages/approvals'));
const Expenses = lazy(() => import('./pages/expenses'));
const Vendors = lazy(() => import('./pages/vendors'));
const Projects = lazy(() => import('./pages/projects'));
const Integrations = lazy(() => import('./pages/integrations'));
const Reports = lazy(() => import('./pages/reports'));
const Activity = lazy(() => import('./pages/activity'));
const Assistant = lazy(() => import('./pages/assistant'));
const SettingsPage = lazy(() => import('./pages/settings'));

const NAV = [
  { id: '', label: 'Overview', icon: LayoutDashboard },
  { id: 'invoices', label: 'Invoices', icon: FileText },
  { id: 'approvals', label: 'Approvals', icon: CheckSquare, badge: true },
  { id: 'expenses', label: 'Expenses', icon: Receipt },
  { id: 'vendors', label: 'Vendors', icon: Building2 },
  { id: 'projects', label: 'Projects & cost codes', icon: FolderKanban },
  { id: 'integrations', label: 'Accounting exports', icon: Plug },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'activity', label: 'Agent activity', icon: Bot },
  { id: 'assistant', label: 'AI assistant', icon: Sparkles },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Shell() {
  const { memberships, orgId, setOrgId, role, email, liveError, lookups, lookupsLoading, userId } = useOrg();
  const [route] = useRoute();
  const [open, setOpen] = useState(false);
  const section = route[0] ?? '';
  const { rows: waiting } = useRows<{ n: number }>(
    queries.waitingApprovals,
    [orgId, userId, role]);
  const myQueue = waiting[0]?.n ?? 0;

  let page: ReactNode;
  switch (section) {
    case '': page = <Overview />; break;
    case 'invoices': page = route[1] ? <InvoiceReview id={route[1]} /> : <Invoices />; break;
    case 'approvals': page = <Approvals />; break;
    case 'expenses': page = <Expenses />; break;
    case 'vendors': page = <Vendors />; break;
    case 'projects': page = <Projects />; break;
    case 'integrations': page = <Integrations />; break;
    case 'reports': page = <Reports />; break;
    case 'activity': page = <Activity />; break;
    case 'assistant': page = <Assistant />; break;
    case 'settings': page = <SettingsPage />; break;
    default: page = <p className="text-sm text-slate-500">Page not found.</p>;
  }

  const nav = (
    <nav className="flex flex-col gap-0.5">
      {NAV.map(item => {
        const active = section === item.id;
        return (
          <a key={item.id} href={`#/${item.id}`} onClick={() => setOpen(false)}
            className={cn('flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm', active ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white')}>
            <item.icon className="size-4 shrink-0" />
            <span className="flex-1">{item.label}</span>{item.id === 'expenses' && <span className="text-[10px] text-slate-400">Planned</span>}
            {item.badge && myQueue > 0 && <span className="rounded bg-amber-500 px-1.5 text-xs font-semibold text-slate-900">{myQueue}</span>}
          </a>
        );
      })}
    </nav>
  );

  const sidebar = (
    <div className="flex h-full flex-col gap-4 bg-slate-900 p-3">
      <div className="flex items-center gap-2 px-1">
        <div className="flex size-8 items-center justify-center rounded-md bg-amber-500 text-slate-900"><HardHat className="size-4" /></div>
        <span className="font-semibold text-white">Trestle</span>
      </div>
      <div className="px-1">
        <label className="sr-only" htmlFor="org-switch">Company</label>
        <select id="org-switch" value={orgId} onChange={e => setOrgId(e.target.value)}
          className="w-full rounded-md border border-slate-700 bg-slate-800 px-2 py-1.5 text-sm text-white">
          {memberships.map(m => <option key={m.org_id} value={m.org_id}>{m.name}</option>)}
        </select>
        <p className="mt-1 text-xs text-slate-400">{ROLE_LABELS[role]}</p>
      </div>
      {nav}
      <CompanyActions />
      <div className="mt-auto flex items-center justify-between gap-2 border-t border-slate-800 px-1 pt-3 text-xs text-slate-400">
        <span className="truncate" title={email}>{email}</span>
        <button type="button" aria-label="Sign out" title="Sign out" onClick={() => client.auth.signOut()} className="rounded p-1 hover:bg-slate-800 hover:text-white"><LogOut className="size-4" /></button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 md:pl-60">
      <aside className="fixed inset-y-0 left-0 hidden w-60 md:block">{sidebar}</aside>
      <header className="sticky top-0 z-30 flex items-center gap-2 border-b border-slate-200 bg-white px-3 py-2 md:hidden">
        <button type="button" aria-label="Open menu" onClick={() => setOpen(true)} className="rounded p-1.5 hover:bg-slate-100"><Menu className="size-5" /></button>
        <span className="font-semibold">Trestle</span>
        <span className="truncate text-sm text-slate-500">{lookups.org?.name}</span>
      </header>
      {open && (
        <div className="fixed inset-0 z-40 md:hidden" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-slate-900/40" />
          <div className="absolute inset-y-0 left-0 w-64" onClick={e => e.stopPropagation()}>
            <button type="button" aria-label="Close menu" onClick={() => setOpen(false)} className="absolute right-2 top-2 z-10 rounded p-1 text-slate-300"><X className="size-4" /></button>
            {sidebar}
          </div>
        </div>
      )}
      <main className="mx-auto max-w-7xl p-4 md:p-6">
        {lookups.org?.is_demo && <div className="mb-3"><Badge tone="violet">Demo workspace · synthetic data, not real financial records</Badge></div>}
        <LiveError error={liveError} />
        <DataHealth />
        <AiStatus />
        <Suspense key={orgId} fallback={<Loading />}>{lookupsLoading ? <Loading label="Loading company…" /> : page}</Suspense>
      </main>
      <IntakeDispatcher />
    </div>
  );
}
