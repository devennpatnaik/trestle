import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useRows } from './db';
import { queries } from '@project/queries';
import type { Lookups, Membership, Role } from './types';

type OrgState = {
  userId: string;
  email: string;
  memberships: Membership[];
  orgId: string;
  role: Role;
  lookups: Lookups;
  lookupsLoading: boolean;
  liveError: string | null;
  setOrgId: (id: string) => void;
  can: (perm: 'ap' | 'admin' | 'owner' | 'approve') => boolean;
  memberName: (userId: string | null | undefined) => string;
};

const OrgContext = createContext<OrgState | null>(null);

export function useOrg(): OrgState {
  const ctx = useContext(OrgContext);
  if (!ctx) throw new Error('useOrg outside OrgProvider');
  return ctx;
}

const EMPTY: Lookups = { vendors: [], projects: [], cost_codes: [], cost_types: [], gl_accounts: [], members: [], commitments: [], settings: null, org: null };

// One live query for every lookup list a screen needs, so the app holds few connections.
const LOOKUPS_SQL = queries.lookups;

export function OrgProvider({ userId, email, memberships, children }: { userId: string; email: string; memberships: Membership[]; children: ReactNode }) {
  const storageKey = `finops:org:${userId}`;
  const [orgId, setOrgIdState] = useState<string>(() => {
    const saved = localStorage.getItem(storageKey);
    return memberships.some(m => m.org_id === saved) ? saved! : memberships[0].org_id;
  });
  useEffect(() => {
    if (!memberships.some(m => m.org_id === orgId)) setOrgIdState(memberships[0].org_id);
  }, [memberships, orgId]);
  const setOrgId = useCallback((id: string) => { localStorage.setItem(storageKey, id); window.location.hash = '#/'; setOrgIdState(id); }, [storageKey]);

  const { rows, loading, error } = useRows<Lookups>(LOOKUPS_SQL, [orgId]);
  const lookups = rows[0] ?? EMPTY;
  const role = (memberships.find(m => m.org_id === orgId)?.role ?? 'viewer') as Role;

  const value = useMemo<OrgState>(() => ({
    userId, email, memberships, orgId, role, lookups, lookupsLoading: loading, liveError: error, setOrgId,
    can: perm => {
      if (perm === 'ap') return ['owner', 'controller', 'ap_clerk'].includes(role);
      if (perm === 'admin') return ['owner', 'controller'].includes(role);
      if (perm === 'owner') return role === 'owner';
      return role !== 'viewer';
    },
    memberName: id => {
      if (!id) return '—';
      const m = lookups.members.find(x => x.user_id === id);
      return m ? (m.display_name && m.display_name !== m.email ? m.display_name : m.email) : 'Former member';
    },
  }), [userId, email, memberships, orgId, role, lookups, loading, error, setOrgId]);

  return <OrgContext.Provider value={value}>{children}</OrgContext.Provider>;
}

export function lookupLabel<T extends { id: string; code: string; name: string }>(list: T[], id: string | null | undefined): string {
  if (!id) return '—';
  const x = list.find(i => i.id === id);
  return x ? `${x.code} · ${x.name}` : '—';
}

// ------------------------------------------------------------------ hash router
export function useRoute(): [string[], (path: string) => void] {
  const read = () => window.location.hash.replace(/^#\/?/, '').split('?')[0].split('/').filter(Boolean);
  const [parts, setParts] = useState<string[]>(read);
  useEffect(() => {
    const onHash = () => { setParts(read()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const go = useCallback((path: string) => { window.location.hash = `#/${path.replace(/^\//, '')}`; }, []);
  return [parts, go];
}

export function go(path: string) {
  window.location.hash = `#/${path.replace(/^\//, '')}`;
}
