import { useEffect, useRef, useState } from 'react';
import { useRows } from './db';
import { queries } from '@project/queries';
import { authHeaders, backendUrl } from './runtime';
import { errorText } from './lib/api';
import { useOrg } from './org';

type Pending = { id: string };
async function intake(path: string, body: object) {
  const response = await fetch(backendUrl(`/intake/${path}`), {
    method: 'POST', headers: { ...(await authHeaders()), 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  const data = await response.json() as { error?: string };
  if (!response.ok) throw new Error(data.error ?? 'AI intake is temporarily unavailable');
}

/** Only discovers pending rows. Dispatch and recovery happen on the server with the user's permissions. */
export function IntakeDispatcher() {
  const { orgId, userId, can } = useOrg();
  const enabled = can('ap');
  const { rows } = useRows<Pending>(queries.intakePending, [enabled ? orgId : '00000000-0000-0000-0000-000000000000', userId]);
  const inFlight = useRef(new Set<string>());
  const [error, setError] = useState('');
  useEffect(() => {
    if (!enabled) return;
    for (const invoice of rows) {
      if (inFlight.current.has(invoice.id)) continue;
      inFlight.current.add(invoice.id);
      void intake('start', { invoiceId: invoice.id }).then(() => setError('')).catch(e => setError(errorText(e)))
        .finally(() => inFlight.current.delete(invoice.id));
    }
  }, [rows, enabled]);
  useEffect(() => {
    if (!enabled) return;
    let active = true; let checking = false;
    const check = async () => {
      if (checking) return;
      checking = true;
      try { await intake('reconcile', { orgId }); if (active) setError(previous => previous.startsWith('Could not check AI progress:') ? '' : previous); }
      catch (e) { if (active) setError(`Could not check AI progress: ${errorText(e)}`); }
      finally { checking = false; }
    };
    void check(); const timer = window.setInterval(() => void check(), 20000);
    return () => { active = false; window.clearInterval(timer); };
  }, [orgId, enabled]);
  return error ? <div role="alert" className="fixed bottom-4 right-4 z-50 max-w-sm rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 shadow-md">
    <p>{error}. Your files remain saved. Retry from the invoice or refresh the page.</p>
    <button className="mt-1 font-medium underline" onClick={() => setError('')}>Dismiss</button>
  </div> : null;
}
