import { useSyncExternalStore } from 'react';
import { NeonPostgrestClient, fetchWithToken } from '@neondatabase/postgrest-js';

/**
 * Self-hosted mode (the downloadable package, see SELF_HOSTING.md). The same app runs against a local server that
 * provides email and password accounts, PostgREST for writes and workflow functions, uploads, live updates and AI
 * extraction with the operator's own model key. Built with VITE_TRESTLE_SELFHOST=1; the hosted build never sets it.
 */
export const SELFHOST = import.meta.env.VITE_TRESTLE_SELFHOST === '1';

/** In self-hosted mode the server and the app share one origin, with the API under /api. */
export const selfhostApi = (path: string) => `${window.location.origin}/api${path}`;

type LocalUser = { id: string; email: string; name: string; emailVerified: boolean };
type Stored = { token: string; user: LocalUser; expiresAt: number };
type AuthResult = { data: Stored | null; error: { message: string } | null };

const STORAGE_KEY = 'trestle:selfhost:session';
const listeners = new Set<() => void>();
let current: Stored | null = load();

function load(): Stored | null {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? 'null') as Stored | null;
    return value && value.expiresAt > Date.now() ? value : null;
  } catch {
    return null;
  }
}

function set(value: Stored | null) {
  current = value;
  if (value) localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
  else localStorage.removeItem(STORAGE_KEY);
  listeners.forEach(fn => fn());
}

window.addEventListener('storage', event => {
  if (event.key === STORAGE_KEY) { current = load(); listeners.forEach(fn => fn()); }
});

async function post(path: string, body: object): Promise<AuthResult> {
  try {
    const response = await fetch(selfhostApi(`/auth/${path}`), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const value = (await response.json().catch(() => null)) as (Stored & { error?: string }) | null;
    if (!response.ok || !value?.token) return { data: null, error: { message: value?.error ?? `Sign in failed (status ${response.status})` } };
    set({ token: value.token, user: value.user, expiresAt: value.expiresAt });
    return { data: current, error: null };
  } catch (cause) {
    return { data: null, error: { message: cause instanceof Error ? cause.message : 'The server could not be reached' } };
  }
}

const sessionView = () => (current && current.expiresAt > Date.now() ? { session: { token: current.token }, user: current.user } : null);
let snapshot = sessionView();
const subscribe = (fn: () => void) => { listeners.add(fn); return () => { listeners.delete(fn); }; };
listeners.add(() => { snapshot = sessionView(); });

const auth = {
  useSession() {
    const data = useSyncExternalStore(subscribe, () => snapshot);
    return { data, isPending: false, error: null };
  },
  async getSession() {
    if (current && current.expiresAt <= Date.now()) set(null);
    return { data: sessionView(), error: null };
  },
  signIn: { email: (a: { email: string; password: string }) => post('sign-in', a) },
  signUp: { email: (a: { email: string; password: string; name: string }) => post('sign-up', a) },
  async signOut() { set(null); return { data: null, error: null }; },
  emailOtp: {
    sendVerificationOtp: async () => ({ error: { message: 'Email codes are not available in the self-hosted edition. Accounts are verified when created.' } }),
    verifyEmail: async () => ({ error: { message: 'Email codes are not available in the self-hosted edition.' } }),
  },
};

/** The client the app uses, with the same surface as the hosted Neon client: auth, from() and rpc(). */
export function createSelfhostClient() {
  const data = new NeonPostgrestClient({
    dataApiUrl: selfhostApi('/data/api'),
    options: { global: { fetch: fetchWithToken(async () => (await auth.getSession()).data?.session.token ?? null) } },
  });
  return {
    auth,
    from: (table: string) => data.from(table),
    rpc: (fn: string, args?: Record<string, unknown>) => data.rpc(fn, args),
  };
}
