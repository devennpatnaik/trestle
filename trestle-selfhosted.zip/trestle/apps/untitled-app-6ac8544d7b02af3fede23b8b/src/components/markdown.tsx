import type { ReactNode } from 'react';

/** Small, safe Markdown renderer for assistant replies: headings, lists, tables, bold, italics, code, links. No HTML passthrough. */
export function Markdown({ text }: { text: string }) {
  const lines = text.replace(/\r/g, '').split('\n');
  const out: ReactNode[] = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (/^\s*```/.test(line)) {
      const buf: string[] = []; i++;
      while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
      i++; out.push(<pre key={out.length} className="overflow-x-auto rounded bg-slate-100 p-2 text-xs">{buf.join('\n')}</pre>); continue;
    }
    if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1])) {
      const cells = (l: string) => l.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const head = cells(line); i += 2;
      const body: string[][] = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) body.push(cells(lines[i++]));
      out.push(
        <div key={out.length} className="my-2 overflow-x-auto"><table className="w-full border-collapse text-xs">
          <thead><tr>{head.map((h, j) => <th key={j} className="border-b border-slate-300 px-2 py-1 text-left font-semibold">{inline(h)}</th>)}</tr></thead>
          <tbody>{body.map((r, k) => <tr key={k}>{r.map((c, j) => <td key={j} className="border-b border-slate-100 px-2 py-1">{inline(c)}</td>)}</tr>)}</tbody>
        </table></div>);
      continue;
    }
    const h = /^(#{1,4})\s+(.*)$/.exec(line);
    if (h) { out.push(<p key={out.length} className="mt-2 font-semibold">{inline(h[2])}</p>); i++; continue; }
    if (/^\s*([-*]|\d+\.)\s+/.test(line)) {
      const ordered = /^\s*\d+\./.test(line);
      const items: string[] = [];
      while (i < lines.length && /^\s*([-*]|\d+\.)\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*([-*]|\d+\.)\s+/, ''));
      const cls = 'my-1 ml-5 space-y-0.5';
      out.push(ordered ? <ol key={out.length} className={`${cls} list-decimal`}>{items.map((t, j) => <li key={j}>{inline(t)}</li>)}</ol> : <ul key={out.length} className={`${cls} list-disc`}>{items.map((t, j) => <li key={j}>{inline(t)}</li>)}</ul>);
      continue;
    }
    if (!line.trim()) { i++; continue; }
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() && !/^\s*([-*]|\d+\.)\s+|^#{1,4}\s|^\s*```|^\s*\|/.test(lines[i])) para.push(lines[i++]);
    if (para.length === 0) { para.push(lines[i++]); }
    out.push(<p key={out.length} className="my-1">{inline(para.join(' '))}</p>);
  }
  return <div className="leading-relaxed">{out}</div>;
}

function inline(s: string): ReactNode[] {
  const parts: ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\)|\*[^*]+\*)/g;
  let last = 0; let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    if (m.index > last) parts.push(s.slice(last, m.index));
    const t = m[0];
    if (t.startsWith('**')) parts.push(<strong key={parts.length}>{t.slice(2, -2)}</strong>);
    else if (t.startsWith('`')) parts.push(<code key={parts.length} className="rounded bg-slate-100 px-1 text-xs">{t.slice(1, -1)}</code>);
    else if (t.startsWith('[')) {
      const lm = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(t)!;
      const href = /^(https?:|#\/)/.test(lm[2]) ? lm[2] : '#';
      parts.push(<a key={parts.length} className="underline" href={href} target={href.startsWith('http') ? '_blank' : undefined} rel="noreferrer">{lm[1]}</a>);
    } else parts.push(<em key={parts.length}>{t.slice(1, -1)}</em>);
    last = m.index + t.length;
  }
  if (last < s.length) parts.push(s.slice(last));
  return parts;
}
