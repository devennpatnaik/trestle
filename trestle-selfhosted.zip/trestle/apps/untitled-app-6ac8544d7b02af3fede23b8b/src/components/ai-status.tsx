import { useEffect, useState } from 'react';
import { SELFHOST, selfhostApi } from '../selfhost';
import { Notice } from './ui';

/** Self-hosted only: says plainly when the server has no Anthropic API key, and how to add one. */
export function AiStatus() {
  const [aiOff, setAiOff] = useState(false);
  useEffect(() => {
    if (!SELFHOST) return;
    fetch(selfhostApi('/health')).then(r => r.json()).then((h: { ai?: boolean }) => setAiOff(h.ai === false)).catch(() => {});
  }, []);
  if (!aiOff) return null;
  return (
    <div className="mb-3">
      <Notice tone="amber">
        AI is off because no Anthropic API key is set. You can still enter bills by hand and use everything else.
        To turn AI on, run <code>./setup.sh</code> again (Windows: <code>setup.ps1</code>) and paste your key when it asks.
      </Notice>
    </div>
  );
}
