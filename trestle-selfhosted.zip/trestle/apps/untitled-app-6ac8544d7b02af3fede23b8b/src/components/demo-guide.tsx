import { useOrg, go } from '../org';
import { Button, Card } from './ui';

/** A short, honest path through real workflows, not a simulated button tour. */
export function DemoGuide() {
  const { lookups } = useOrg();
  if (!lookups.org?.is_demo) return null;
  return <Card title="Try the complete workflow" actions={<a href="/demo/sample-invoice.pdf" download className="text-sm font-medium underline">Download a sample invoice</a>}>
    <p className="mb-3 text-sm text-slate-600">Summit Ridge is a fictional general contractor with 3 jobs, 6 suppliers, purchase orders, subcontracts and change orders. Changes here never affect your real company.</p>
    <div className="grid gap-3 lg:grid-cols-3">
      {[
        ['1 · Review', 'Start with GSR-88214 ($650). Compare the source, check the coding, then submit it. GSR-88219 shows overbilling; GSR-88120 shows a duplicate.', 'invoices?filter=needs_review', 'Review invoices'],
        ['2 · Approve', 'Open AE-2410-03 to see progress billing and $3,000 retainage. BS-6021 shows costs split across two jobs. Both are waiting for you.', 'approvals', 'Open approvals'],
        ['3 · Export', 'NR-7102 is ready to export. NR-7097 shows a failed import you can retry. Download the CSV, then record a simulated result with a SIMULATED- reference.', 'integrations', 'Open accounting exports'],
      ].map(([title, text, path, label]) => <div key={title} className="flex flex-col items-start rounded-md border border-slate-200 p-3">
        <h3 className="text-sm font-semibold">{title}</h3><p className="mb-3 mt-1 flex-1 text-sm text-slate-600">{text}</p>
        <Button size="sm" onClick={() => go(path)}>{label}</Button>
      </div>)}
    </div>
    <p className="mt-3 text-xs text-slate-500">Demo-only setting: you may submit and approve your own invoices with one approval step. Real companies default to separation of duties. Seeded history and source previews are fictional; no payment or external accounting posting has occurred. Reopening the demo preserves your work.</p>
  </Card>;
}
