import { refreshData, useDataHealth } from '../db';
import { Button } from './ui';

export function DataHealth() {
  const message = useDataHealth();
  if (!message) return null;
  return <div role="status" className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
    <span>{message} Your saved data has not been removed.</span><Button size="sm" onClick={refreshData}>Refresh now</Button>
  </div>;
}
