import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Pencil, Plus } from 'lucide-react';
import { client } from '../client';
import { errorText, must } from '../lib/api';
import { Button, Card, Empty, ErrorNote, Field, Input, Modal, Select, Table, Td, Th } from './ui';

export type EntityField = {
  key: string; label: string; kind?: 'text' | 'money' | 'select' | 'bool'; required?: boolean; hint?: string;
  options?: { value: string; label: string }[]; inList?: boolean; render?: (row: Record<string, unknown>) => ReactNode; wide?: boolean;
};

/** List + create/edit modal for a simple master-data table. Writes go straight to the table under row level security. */
export function EntityManager({ title, table, orgId, rows, fields, canEdit, toolbar, searchKeys, emptyHint, defaults }: {
  title: string; table: string; orgId: string; rows: Record<string, unknown>[]; fields: EntityField[]; canEdit: boolean;
  toolbar?: ReactNode; searchKeys: string[]; emptyHint?: ReactNode; defaults?: Record<string, unknown>;
}) {
  const [editing, setEditing] = useState<Record<string, unknown> | null>(null);
  const [q, setQ] = useState('');
  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    return s ? rows.filter(r => searchKeys.some(k => String(r[k] ?? '').toLowerCase().includes(s))) : rows;
  }, [rows, q, searchKeys]);
  const listFields = fields.filter(f => f.inList !== false);
  return (
    <Card bodyClassName="p-0" title={`${title} (${rows.length})`} actions={<>
      {toolbar}
      {canEdit && <Button variant="primary" onClick={() => setEditing({ ...(defaults ?? {}) })}><Plus className="size-4" />Add</Button>}
    </>}>
      <div className="border-b border-slate-100 p-3"><Input aria-label={`Search ${title}`} placeholder="Search…" value={q} onChange={e => setQ(e.target.value)} className="max-w-xs" /></div>
      {rows.length === 0 ? <div className="p-4"><Empty title={`No ${title.toLowerCase()} yet`}>{emptyHint}</Empty></div> : (
        <Table>
          <thead><tr>{listFields.map(f => <Th key={f.key}>{f.label}</Th>)}{canEdit && <Th />}</tr></thead>
          <tbody>
            {shown.slice(0, 500).map(r => (
              <tr key={String(r.id)} className="hover:bg-slate-50">
                {listFields.map(f => <Td key={f.key}>{f.render ? f.render(r) : f.kind === 'select' ? (f.options?.find(o => o.value === r[f.key])?.label ?? '—') : f.kind === 'bool' ? (r[f.key] ? 'Yes' : 'No') : String(r[f.key] ?? '—')}</Td>)}
                {canEdit && <Td className="text-right"><button type="button" aria-label={`Edit ${String(r.code ?? r.name ?? '')}`} onClick={() => setEditing(r)} className="rounded p-1 text-slate-500 hover:bg-slate-100"><Pencil className="size-4" /></button></Td>}
              </tr>
            ))}
          </tbody>
        </Table>
      )}
      {shown.length > 500 && <p className="p-3 text-xs text-slate-500">Showing 500 of {shown.length}. Narrow with search.</p>}
      <EntityForm open={!!editing} row={editing} onClose={() => setEditing(null)} title={title} table={table} orgId={orgId} fields={fields} />
    </Card>
  );
}

function EntityForm({ open, row, onClose, title, table, orgId, fields }: { open: boolean; row: Record<string, unknown> | null; onClose: () => void; title: string; table: string; orgId: string; fields: EntityField[] }) {
  const [form, setForm] = useState<Record<string, string | boolean>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!row) return;
    setError('');
    setForm(Object.fromEntries(fields.map(f => [f.key, f.kind === 'bool' ? Boolean(row[f.key] ?? true) : row[f.key] === null || row[f.key] === undefined ? '' : String(row[f.key])])));
  }, [row, fields]);
  const isNew = !row?.id;
  const save = async () => {
    setBusy(true); setError('');
    try {
      const values: Record<string, unknown> = {};
      for (const f of fields) {
        const v = form[f.key];
        if (f.kind === 'bool') values[f.key] = Boolean(v);
        else if (typeof v === 'string') {
          const t = v.trim();
          if (f.required && !t) throw new Error(`${f.label} is required`);
          if (f.kind === 'money' && t && !Number.isFinite(Number(t.replace(/[$,]/g, '')))) throw new Error(`${f.label} must be a number`);
          values[f.key] = t === '' ? null : f.kind === 'money' ? Number(t.replace(/[$,]/g, '')) : t;
        }
      }
      if (isNew) await must(client.from(table).insert({ ...values, org_id: orgId }).select('id'));
      else await must(client.from(table).update(values).eq('id', row!.id as string).select('id'));
      onClose();
    } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  const remove = async () => {
    if (!confirm(`Delete this record? Records already used on invoices cannot be deleted; set them inactive instead.`)) return;
    setBusy(true); setError('');
    try { await must(client.from(table).delete().eq('id', row!.id as string).select('id')); onClose(); } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} title={`${isNew ? 'Add' : 'Edit'} ${title.replace(/s$/, '').toLowerCase()}`} onClose={onClose} footer={<>
      {!isNew && <Button variant="ghost" className="mr-auto text-red-700" onClick={remove} disabled={busy}>Delete</Button>}
      <Button onClick={onClose}>Cancel</Button>
      <Button variant="primary" busy={busy} onClick={save}>Save</Button>
    </>}>
      <div className="grid gap-3 sm:grid-cols-2">
        {fields.map(f => (
          <Field key={f.key} label={`${f.label}${f.required ? ' *' : ''}`} hint={f.hint} className={f.wide ? 'sm:col-span-2' : ''}>
            {f.kind === 'select' ? (
              <Select aria-label={f.label} value={String(form[f.key] ?? '')} onChange={e => setForm({ ...form, [f.key]: e.target.value })}>
                {!f.required && <option value="">—</option>}
                {f.options?.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </Select>
            ) : f.kind === 'bool' ? (
              <input type="checkbox" aria-label={f.label} className="size-4" checked={Boolean(form[f.key])} onChange={e => setForm({ ...form, [f.key]: e.target.checked })} />
            ) : (
              <Input aria-label={f.label} value={String(form[f.key] ?? '')} inputMode={f.kind === 'money' ? 'decimal' : undefined} onChange={e => setForm({ ...form, [f.key]: e.target.value })} />
            )}
          </Field>
        ))}
      </div>
      <ErrorNote>{error}</ErrorNote>
    </Modal>
  );
}
