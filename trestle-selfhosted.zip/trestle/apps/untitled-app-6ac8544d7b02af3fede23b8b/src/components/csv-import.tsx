import { useRef, useState } from 'react';
import { Upload } from 'lucide-react';
import { downloadText, errorText, parseCsv, toCsv } from '../lib/api';
import { Badge, Button, ErrorNote, Modal, Notice, Table, Td, Th } from './ui';

export type CsvColumn = { name: string; required?: boolean; hint?: string; example?: string };
export type Mapped<T> = { ok: true; value: T } | { ok: false; error: string };

/**
 * Generic CSV import: shows the expected columns and a template, validates
 * every row before anything is written, then calls onImport with only valid
 * rows. Nothing is written when validation finds errors unless the user chooses
 * to import the valid rows.
 */
export function CsvImport<T>({ title, columns, mapRow, onImport, buttonLabel = 'Import CSV', disabled, note }: {
  title: string; columns: CsvColumn[]; buttonLabel?: string; disabled?: boolean; note?: string;
  mapRow: (row: Record<string, string>, index: number) => Mapped<T>;
  onImport: (rows: T[]) => Promise<string>;
}) {
  const [open, setOpen] = useState(false);
  const [parsed, setParsed] = useState<{ raw: Record<string, string>; result: Mapped<T> }[] | null>(null);
  const [fileName, setFileName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');
  const ref = useRef<HTMLInputElement>(null);

  const reset = () => { setParsed(null); setError(''); setDone(''); setFileName(''); };
  const onFile = async (file: File) => {
    reset(); setFileName(file.name);
    try {
      const rows = parseCsv(await file.text());
      if (!rows.length) { setError('The file has no data rows.'); return; }
      const missing = columns.filter(c => c.required && !(c.name in rows[0]));
      if (missing.length) { setError(`Missing required column(s): ${missing.map(c => c.name).join(', ')}. Column names are matched case-insensitively.`); return; }
      setParsed(rows.map((raw, i) => ({ raw, result: mapRow(raw, i) })));
    } catch (e) { setError(errorText(e)); }
  };
  const valid = parsed?.filter(p => p.result.ok).map(p => (p.result as { ok: true; value: T }).value) ?? [];
  const invalid = parsed?.filter(p => !p.result.ok) ?? [];

  return (
    <>
      <Button disabled={disabled} onClick={() => { reset(); setOpen(true); }}><Upload className="size-4" />{buttonLabel}</Button>
      <Modal open={open} title={title} onClose={() => setOpen(false)} wide footer={<>
        <Button onClick={() => setOpen(false)}>{done ? 'Close' : 'Cancel'}</Button>
        {!done && parsed && <Button variant="primary" busy={busy} disabled={!valid.length} onClick={async () => {
          setBusy(true); setError('');
          try { setDone(await onImport(valid)); } catch (e) { setError(errorText(e)); } finally { setBusy(false); }
        }}>Import {valid.length} row{valid.length === 1 ? '' : 's'}{invalid.length ? ` (skip ${invalid.length} with errors)` : ''}</Button>}
      </>}>
        {note && <Notice>{note}</Notice>}
        <div className="text-sm text-slate-600">
          <p>Columns (header row required; extra columns are ignored). Existing records with the same code are updated.</p>
          <div className="mt-2 flex flex-wrap gap-1.5">{columns.map(c => <Badge key={c.name} tone={c.required ? 'blue' : 'gray'} title={c.hint}>{c.name}{c.required ? ' *' : ''}</Badge>)}</div>
          <button type="button" className="mt-2 text-xs underline" onClick={() => downloadText(`${title.toLowerCase().replace(/\W+/g, '-')}-template.csv`, toCsv([Object.fromEntries(columns.map(c => [c.name, c.example ?? '']))], columns.map(c => c.name)))}>Download template</button>
        </div>
        <input ref={ref} type="file" accept=".csv,text/csv" className="hidden" aria-label="CSV file" onChange={e => { const f = e.target.files?.[0]; if (f) void onFile(f); e.target.value = ''; }} />
        <Button onClick={() => ref.current?.click()}>{fileName ? `Choose another file (${fileName})` : 'Choose CSV file'}</Button>
        <ErrorNote>{error}</ErrorNote>
        {parsed && !done && (
          <div className="text-sm">
            <p className="mb-2">{parsed.length} rows read · <span className="text-emerald-700">{valid.length} valid</span>{invalid.length > 0 && <> · <span className="text-red-700">{invalid.length} with errors</span></>}</p>
            {invalid.length > 0 && (
              <Table className="max-h-60 overflow-y-auto">
                <thead><tr><Th>Row</Th><Th>Problem</Th></tr></thead>
                <tbody>{invalid.slice(0, 50).map(p => <tr key={parsed.indexOf(p)}><Td>{parsed.indexOf(p) + 2}</Td><Td className="text-red-700">{(p.result as { error: string }).error}</Td></tr>)}</tbody>
              </Table>
            )}
          </div>
        )}
        {done && <Notice tone="green">{done}</Notice>}
      </Modal>
    </>
  );
}

export const req = (row: Record<string, string>, key: string): string | null => {
  const v = (row[key] ?? '').trim();
  return v === '' ? null : v;
};

export function parseMoney(v: string | null | undefined): number | null | 'invalid' {
  if (v === null || v === undefined || v.trim() === '') return null;
  const s = v.trim().replace(/[$,\s]/g, '').replace(/^\((.*)\)$/, '-$1');
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 'invalid';
}
