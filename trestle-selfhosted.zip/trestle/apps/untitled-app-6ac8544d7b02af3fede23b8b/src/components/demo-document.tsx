import { fmtDate, fmtMoney, num } from '../lib/api';

type DemoSource = { vendor_name?: string; invoice_number?: string; invoice_date?: string; due_date?: string; payment_terms?: string;
  commitment_number?: string; description?: string; subtotal?: string; tax_amount?: string; total_amount?: string; retainage_amount?: string;
  lines?: { description: string; quantity: string; unit_price: string; amount: string }[] };

export function DemoDocument({ source }: { source: unknown }) {
  const d = source as DemoSource;
  return <article aria-label="Synthetic invoice source" className="rounded-md border border-slate-200 bg-white p-5 text-sm">
    <p className="mb-5 border-b border-amber-200 pb-2 text-xs font-semibold uppercase tracking-wider text-amber-800">Fictional invoice · demo only · do not pay</p>
    <h2 className="text-lg font-semibold">{d.vendor_name ?? 'Supplier'}</h2>
    <p className="mt-1 text-slate-500">Invoice {d.invoice_number}</p>
    <div className="my-5 grid grid-cols-2 gap-3 text-xs">
      <div><span className="text-slate-500">Bill to</span><p>Summit Ridge Builders LLC</p></div>
      <div><span className="text-slate-500">Invoice date</span><p>{fmtDate(d.invoice_date)}</p></div>
      <div><span className="text-slate-500">Commitment</span><p>{d.commitment_number ?? 'Not provided'}</p></div>
      <div><span className="text-slate-500">Due date · {d.payment_terms}</span><p>{fmtDate(d.due_date)}</p></div>
    </div>
    <div className="border-y border-slate-200 py-3">
      {d.lines?.map((l,i) => <div key={i} className="mb-2 flex items-start gap-4"><p className="flex-1">{l.description}</p><strong className="whitespace-nowrap">{fmtMoney(l.amount)}</strong></div>)}
    </div>
    <dl className="ml-auto mt-4 max-w-64 space-y-2">
      {[
        ['Subtotal',d.subtotal],['Tax',d.tax_amount],['Total billed',d.total_amount],['Retainage withheld',d.retainage_amount],
        ['Amount payable',num(d.total_amount)-num(d.retainage_amount)],
      ].map(([label,value]) => <div key={label} className="flex justify-between gap-4"><dt className="text-slate-500">{label}</dt><dd className="font-medium">{fmtMoney(value)}</dd></div>)}
    </dl>
    <p className="mt-6 text-xs text-slate-500">This source preview was saved when the demo was created. It does not change when you edit invoice fields. It is not an uploaded supplier document or evidence of an AI run.</p>
  </article>;
}
