import { useEffect, useRef, useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import workerUrl from 'pdfjs-dist/legacy/build/pdf.worker.min.mjs?url';
import 'react-pdf/dist/Page/TextLayer.css';
import { Button, Loading } from './ui';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

export default function PdfViewer({ url }: { url: string }) {
  const container = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(480);
  const [pages, setPages] = useState(0);
  const [page, setPage] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!container.current) return;
    const observer = new ResizeObserver(entries => setWidth(Math.max(200, entries[0].contentRect.width - 2)));
    observer.observe(container.current);
    return () => observer.disconnect();
  }, []);
  return <div ref={container} className="min-w-0 overflow-hidden rounded border border-slate-200 bg-slate-100">
    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-white p-2 text-xs">
      <div className="flex items-center gap-2">
        <Button size="sm" aria-label="Previous PDF page" disabled={page <= 1} onClick={() => setPage(n => n - 1)}>Previous</Button>
        <span aria-live="polite">{pages ? `Page ${page} of ${pages}` : 'PDF'}</span>
        <Button size="sm" aria-label="Next PDF page" disabled={!pages || page >= pages} onClick={() => setPage(n => n + 1)}>Next</Button>
      </div>
      <div className="flex items-center gap-1">
        <Button size="sm" aria-label="Zoom out" disabled={zoom <= 0.75} onClick={() => setZoom(z => Math.max(0.75, z - 0.25))}>−</Button>
        <Button size="sm" aria-label="Fit PDF to width" onClick={() => setZoom(1)}>{Math.round(zoom * 100)}%</Button>
        <Button size="sm" aria-label="Zoom in" disabled={zoom >= 2} onClick={() => setZoom(z => Math.min(2, z + 0.25))}>+</Button>
      </div>
    </div>
    <div className="max-h-[80vh] overflow-auto" aria-label="PDF source preview">
      {error ? <p className="p-4 text-sm text-amber-800">{error} Use Open original above to view or download it.</p> : <Document file={url}
        loading={<Loading label="Rendering PDF…" />} onLoadSuccess={({ numPages }) => setPages(numPages)}
        onLoadError={() => setError('This PDF could not be rendered here.')}
        onPassword={() => setError('This PDF is password protected.')}>
        <Page pageNumber={page} width={Math.floor(width * zoom)} renderAnnotationLayer={false} renderTextLayer
          loading={<Loading label="Rendering page…" />} onRenderError={() => setError('This page could not be rendered here.')} />
      </Document>}
    </div>
  </div>;
}
