import { useState } from 'react';
import { useOrg } from '../org';
import { rpc, errorText } from '../lib/api';
import { Button, ErrorNote, Field, Input, Modal } from './ui';

export function CompanyActions() {
  const { userId } = useOrg();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const create = async (demo: boolean) => {
    setBusy(true); setError('');
    try {
      const id = await rpc<string>(demo ? 'create_demo_organization' : 'create_organization', demo ? {} : { p_name: name.trim(), p_legal_entity: null });
      localStorage.setItem(`finops:org:${userId}`, id);
      window.location.hash = '#/'; window.location.reload();
    } catch (e) { setError(errorText(e)); setBusy(false); }
  };
  return <div className="border-t border-slate-800 pt-3">
    <button className="w-full rounded px-2.5 py-2 text-left text-sm text-amber-300 hover:bg-slate-800 disabled:opacity-50" disabled={busy} onClick={() => create(true)}>{busy ? 'Opening workspace…' : 'Open demo company'}</button>
    <button className="w-full rounded px-2.5 py-2 text-left text-xs text-slate-300 hover:bg-slate-800" disabled={busy} onClick={() => { setError(''); setOpen(true); }}>Add a real company</button>
    {!open && error && <p role="alert" className="mt-2 px-2 text-xs text-red-300">{error}</p>}
    <Modal open={open} onClose={() => !busy && setOpen(false)} title="Add a company" footer={<><Button disabled={busy} onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" busy={busy} disabled={!name.trim()} onClick={() => create(false)}>Create company</Button></>}>
      <p className="mb-3 text-sm text-slate-600">Start with an empty company. Demo data will not be copied into it.</p>
      <Field label="Company name"><Input aria-label="New company name" value={name} onChange={e => setName(e.target.value)} /></Field><ErrorNote>{error}</ErrorNote>
    </Modal>
  </div>;
}
