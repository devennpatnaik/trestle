# Trestle: construction AP automation (Phase 1)

## Workflow
1. **Upload**: an AP user uploads a PDF or photo (Invoices). The browser claims the invoice once (`agent_session_id`) and starts the `invoice-intake` agent with the file attached.
2. **Extract**: the agent calls `agent_begin_extraction` (context: vendors, jobs, cost codes, commitments, coding history), reads the document, then calls `agent_submit_extraction` with the fields, per-field confidence, line items and proposed allocations. It cannot submit, approve or export.
3. **Check**: `_invoice_checks` (deterministic SQL) matches vendor/commitment and raises exceptions: missing fields, low confidence, totals, dates, duplicate / possible duplicate, inactive vendor, PO required / not found / vendor mismatch / closed, overbilling beyond tolerance, pending change orders, retainage, coding outside the commitment, unbalanced or incomplete allocations, closed job.
4. **Review**: AP corrects fields (each correction is audited and marks the field verified), codes splits, confirms low-confidence values, and submits. Blocking exceptions must be fixed or overridden by a controller/owner with a written justification.
5. **Approve**: `submit_invoice` builds approval steps from rules (PM of each job, named person, role, amount thresholds). Self-approval is off by default; approval limits and missing PMs route to controllers. Rejection requires a reason.
6. **Export**: `create_export_batch` takes approved, not-yet-exported invoices using the coding snapshot taken at approval, refuses if totals do not reconcile, and records one `sync_records` row per invoice (idempotency key `INV-<invoice id>`).
7. **Confirm**: upload a results file (or record per invoice) to mark each invoice `synced` (external ID required, unique) or `failed`. Failed invoices are retried in the next batch as a new attempt; a stale batch cannot overwrite a newer attempt.

## CSV formats
| Import | Required columns | Optional |
|---|---|---|
| Vendors | code, name | tax_id, email, phone, address, payment_terms, status, external_id |
| Jobs | code, name | status, pm_email, legal_entity, address, external_id |
| Cost codes | code, name | project_code (blank = all jobs), budget_amount |
| GL accounts | code, name | account_type, active |
| Commitments | number, vendor_code, project_code, original_amount | kind, description, retainage_pct, status, external_id, line_no, line_description, cost_code, cost_type, line_amount |
| Change orders | commitment_number, number, amount | description, status, approved_date |
| Sync results | idempotency_key, status (synced/failed) | external_id (required when synced), error |

Export batch CSV: one row per allocation with `idempotency_key, batch_number, attempt, vendor_code, vendor_external_id, vendor_name, invoice_number, invoice_date, due_date, payment_terms, currency, invoice_subtotal, invoice_tax, invoice_retainage, invoice_total, commitment_number, commitment_external_id, line_no, job, job_external_id, cost_code, cost_type, gl_account, line_amount, line_description`.

## Roles
owner, controller, ap_clerk, project_manager, viewer. Enforced by row level security and SECURITY DEFINER workflow functions; status, approval and sync columns cannot be written directly by any client.

## Not built (later phases)
Expenses/cards, vendor compliance (COIs, lien waivers), payments, native ERP connectors, email-in invoice capture, approval reminder emails.

## How the app reaches its data

The browser never talks to the database directly. Everything goes through the project backend (`backend/`, one Cloudflare Worker per branch):

- **Reads** go to `POST /data/query`. It maps the approved reads in `packages/queries` to fixed IDs and calls the `trestle_read` SECURITY INVOKER RPC through the Neon Data API with the user’s bearer token. No owner database connection is used for user reads. Row level security applies to every query. Add reads to the package and generate a NEW migration using `scripts/generate-read-migration.ts`; never rewrite an applied migration.
- **Live updates** use one WebSocket at `/live`. Database triggers publish which table changed (never row data), and each screen reloads the reads that mention that table. While the socket is down, screens poll every 15 seconds.
- **Writes and workflow actions** (submit, approve, void, settings, CSV imports) go to `/data/api/*`. The backend forwards them to the Neon Data API with the user's own token, so the database policies and workflow functions still decide everything. The forwarder retries a write only when the database refused it because the user's identity was missing on a fresh connection (a known intermittent Data API behavior). Those refusals mean nothing changed, so the retry is safe.
- **Uploads, documents and agent sessions** go to `/bourne/*`, which forwards them to the Bourne runtime with the user's token.

## Demo company

Choose **Open demo company** in the sidebar (or **Create demo workspace** during onboarding). It creates or reopens your isolated Summit Ridge Builders demo, preserving your edits on repeat visits. It starts with 15 fictional invoices, 6 suppliers, 3 jobs, 6 commitments, 3 change orders, coding, approval history and 3 simulated export batches. The overview provides a three-step walkthrough. Download the sample PDF there to test real AI extraction.

The demo enables self-approval with a single owner step so one person can finish the workflow. This does not change real-company settings. Source previews and seeded accounting confirmations are explicitly synthetic; they are not actual uploaded documents or external postings. Never import demo invoices into a real ledger.

**Retainage convention:** invoice total and coding represent the gross billed cost (including tax); retainage is tracked separately. The illustrative source shows amount payable as total less retainage. Map both fields according to your ERP’s AP/retainage import rules.

## Regression checks

- `bun test tests/read-contract.test.ts`
- `psql "$DATABASE_URL" -v test_user=<draft-test-user-id> -f tests/demo-invariants.sql` (draft only; rolls back all changes; use an account that has not already changed its demo).
- `/home/user/bin/check-isolation`
- App and backend `bun run typecheck` and `bun run build`, plus `bun run typecheck:agents`.

### Identity and intake recovery

`app_uid()` uses an explicit PL/pgSQL branch: verified request claims for Data API calls, and the restricted `auth.user_id()` helper for agent SQL calls. This avoids lazily initializing the JWT extension on a Data API call. The helper does not accept an identity argument.

`/intake/start` claims an uploader’s pending invoice atomically, starts the saved action on the server, and keeps dispatch alive with `waitUntil`. `/intake/reconcile` inspects completed sessions while the uploader has the app open. It marks an incomplete extraction failed only if its saved session and active status still match; a finished extraction, manual takeover, or newer retry wins the race. No failed model run invents invoice values.

## Final usability verification (October 12, 2026 UTC)

Verified on the draft, using QA users and their isolated fictional demo; no production or real-company records were changed.

- 15 browser acceptance checks: creation, 15-invoice seed, source view, submit/reload/approve, balanced 3-invoice $4,850 export including retry, saved confirmation, duplicate block, five reports, navigation, company-state reset, idempotent demo reopening, visible read-error recovery, 390px mobile layout/navigation, and no JavaScript errors.
- All 36 approved reads returned successfully. All 60 concurrent identity requests matched the signed-in test user.
- A second real test user could neither read, edit, approve, nor recover an invoice in the first user’s demo.
- A stopped AI session was automatically shown as a retryable failure. The saved PDF was retried with the dispatching tab closed; one successful extraction run completed. NR-DEMO-7115 yielded the correct Northline Equipment Rentals vendor, $975 total, invoice/due dates, PO, full job reference, and one line item. The uploaded PDF preview and live second-tab result were checked.
- The assistant identified the demo’s duplicate, overbilling, uncoded, and unmatched invoices from live records.
- Rollback SQL tests cover seed relationships, coding/export balances, source previews, approval, export, idempotent confirmation, and recovery guards against a stale session or completed extraction.
- Six backend/read-contract tests (45 expectations), app/backend typechecks and builds, agent typecheck, and the platform isolation checker pass.

Limits remain explicit: generic CSV mapping must be tested with the target ERP; no native ERP posting or payments; expenses/compliance are planned; intake discovery/recovery resumes when the uploader opens the app; completed server dispatch and model work continue without the tab. Synthetic histories are not real accounting evidence.
