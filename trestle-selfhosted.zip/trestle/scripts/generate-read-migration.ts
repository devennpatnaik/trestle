// Run once for each new migration when approved reads change; never rewrite an applied migration.
import { ALLOWED_QUERIES } from '../packages/queries';
const target = process.argv[2];
if (!target) throw new Error('Pass a new migration.sql path');
const cases = ALLOWED_QUERIES.map((q, i) => {
  const text = q.replace(/%/g, '%%').replace(/\$(\d+)/g, '%$1$L');
  return `WHEN 'q${i}' THEN $query$${text}$query$`;
}).join('\n');
const sql = `-- Approved reads through the user's Data API identity, never an owner connection.\nCREATE OR REPLACE FUNCTION public.trestle_read(p_key text, p_params jsonb DEFAULT '[]') RETURNS jsonb\nLANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path = public AS $fn$\nDECLARE template text; result jsonb;\nBEGIN\n  IF app_uid() IS NULL THEN RAISE EXCEPTION 'Sign in first' USING ERRCODE = '42501'; END IF;\n  IF jsonb_typeof(p_params) <> 'array' OR jsonb_array_length(p_params) > 4 THEN\n    RAISE EXCEPTION 'Invalid query parameters';\n  END IF;\n  template := CASE p_key\n${cases}\nELSE NULL END;\n  IF template IS NULL THEN RAISE EXCEPTION 'Unknown read'; END IF;\n  -- format %L quotes values as literals, never as identifiers or executable SQL.\n  -- SECURITY INVOKER means the Data API's authenticated role and RLS apply throughout.\n  EXECUTE 'SELECT coalesce(jsonb_agg(to_jsonb(r)), ''[]''::jsonb) FROM (' ||\n    format(template, p_params->>0, p_params->>1, p_params->>2, p_params->>3) || ') r' INTO result;\n  RETURN result;\nEND $fn$;\nREVOKE ALL ON FUNCTION public.trestle_read(text,jsonb) FROM PUBLIC;\nGRANT EXECUTE ON FUNCTION public.trestle_read(text,jsonb) TO authenticated;\n`;
await Bun.write(target, sql);
console.log(`Generated ${ALLOWED_QUERIES.length} approved reads`);
