#!/bin/sh
# Builds the self-hosted download: the committed project plus the Docker files and README at its root.
# Usage: scripts/package-selfhost.sh [output.zip]
set -e
ROOT=$(git rev-parse --show-toplevel)
OUT=$(realpath -m "${1:-trestle-selfhosted.zip}")
STAGE=$(mktemp -d)
mkdir "$STAGE/trestle"
git -C "$ROOT" archive HEAD | tar -x -C "$STAGE/trestle"
cp -R "$ROOT/backend/selfhost/package/." "$STAGE/trestle/"
rm -f "$OUT"
(cd "$STAGE" && python3 -m zipfile -c "$OUT" trestle)
rm -rf "$STAGE"
echo "$OUT"
