from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path
import subprocess
D=Document();sec=D.sections[0];sec.top_margin=sec.bottom_margin=Inches(.75)
style=D.styles['Normal'];style.font.name='Liberation Sans';style.font.size=Pt(11);style.paragraph_format.space_after=Pt(9)
p=D.add_paragraph();r=p.add_run('FICTIONAL TRAINING INVOICE — DO NOT PAY');r.bold=True;r.font.size=Pt(10);r.font.color.rgb=RGBColor.from_string('9A6500')
D.add_heading('Northline Equipment Rentals',0)
D.add_paragraph('Fictional supplier · V-1003 · equipment@example.com')
D.add_heading('INVOICE  NR-DEMO-7115',1)
t=D.add_table(rows=0, cols=2)
for a,b in [('Bill to: Summit Ridge Builders LLC','Invoice date: October 11, 2026'),('Job: 24-117 · Oakwood Elementary Renovation','Due date: November 10, 2026'),('Purchase order: PO-24117-002','Payment terms: Net 30')]:
 c=t.add_row().cells;c[0].text=a;c[1].text=b
D.add_paragraph();t=D.add_table(rows=1,cols=4)
for c,s in zip(t.rows[0].cells,['Description','Quantity','Rate','Amount']):
 c.text=s;sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E2E8F0');c._tc.get_or_add_tcPr().append(sh)
for c,s in zip(t.add_row().cells,['Electric scissor lift rental, Oct 5–9','5 days','$195.00','$975.00']): c.text=s
D.add_paragraph()
for s in ['Subtotal: $975.00','Tax: $0.00','Total billed: $975.00','Retainage: $0.00','Amount payable: $975.00 USD']:
 p=D.add_paragraph(s);p.alignment=2
 if s.startswith('Amount payable'):p.runs[0].bold=True
D.add_paragraph('Job cost reference: 01-540 · Equipment Rental\nCost type: E · Equipment\nExpense account: 5030 · Job Cost – Equipment Rental')
D.add_paragraph('Demo exercise: upload this PDF inside Summit Ridge Builders · Demo. Review the extracted vendor, PO, dates, amount and job coding, then submit and approve it. No payment instructions are included because this is fictional training data. Re-uploading the same invoice should trigger a duplicate check.')
p=D.sections[0].footer.paragraphs[0];p.text='Trestle demo material · Do not import into a real accounting ledger';p.runs[0].font.size=Pt(9)
D.save('/tmp/sample-invoice.docx')
out=Path('apps/untitled-app-6ac8544d7b02af3fede23b8b/public/demo')
r=subprocess.run(['soffice','-env:UserInstallation=file:///tmp/trestle-lo','--headless','--convert-to','pdf','--outdir',str(out),'/tmp/sample-invoice.docx'],capture_output=True,text=True);print(r.stdout);r.check_returncode()
subprocess.run(['pdftoppm','-scale-to','1100','-png','-singlefile',str(out/'sample-invoice.pdf'),'/tmp/sample-invoice'],check=True)
